// Sets required env vars BEFORE requiring server.js, so the app can be
// imported and tested without needing a real .env file or a live MongoDB
// connection (server.js only auto-connects when run directly, not when
// require()'d — see the `require.main === module` guard in server.js).
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test_secret_for_smoke_tests_only';
process.env.NODE_ENV = 'test';

const assert = require('assert');
const request = require('supertest');
const app = require('../server');

let passed = 0;
let failed = 0;
const skipped = [];

async function test(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log(`PASS: ${name}`);
  } catch (err) {
    failed += 1;
    console.log(`FAIL: ${name}`);
    console.log(`      ${err.message}`);
  }
}

function skip(name, reason) {
  skipped.push({ name, reason });
  console.log(`SKIP: ${name} (${reason})`);
}

(async () => {
  console.log('--- Running backend smoke tests (no live MongoDB required) ---\n');

  // 1. Health check
  await test('GET /api/health returns success', async () => {
    const res = await request(app).get('/api/health');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.success, true);
    assert.strictEqual(res.body.database, 'disconnected'); // no DB connected in this test run
  });

  // 2. Unknown route -> 404 via notFound middleware
  await test('GET /api/does-not-exist returns 404', async () => {
    const res = await request(app).get('/api/does-not-exist');
    assert.strictEqual(res.status, 404);
    assert.strictEqual(res.body.success, false);
  });

  // 3. Register validation — bad email, short password, missing name
  await test('POST /api/auth/register rejects invalid email', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: 'Test User', email: 'not-an-email', password: 'password123' });
    assert.strictEqual(res.status, 400);
    assert.strictEqual(res.body.success, false);
  });

  await test('POST /api/auth/register rejects short password', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: 'Test User', email: 'test@example.com', password: '123' });
    assert.strictEqual(res.status, 400);
  });

  await test('POST /api/auth/register rejects missing name', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ email: 'test@example.com', password: 'password123' });
    assert.strictEqual(res.status, 400);
  });

  // 4. Login validation
  await test('POST /api/auth/login rejects missing password', async () => {
    const res = await request(app).post('/api/auth/login').send({ email: 'test@example.com' });
    assert.strictEqual(res.status, 400);
  });

  await test('POST /api/auth/login rejects invalid email format', async () => {
    const res = await request(app).post('/api/auth/login').send({ email: 'nope', password: 'password123' });
    assert.strictEqual(res.status, 400);
  });

  // 5. Protected routes without a token -> 401, before ever touching the DB
  await test('GET /api/auth/me without token returns 401', async () => {
    const res = await request(app).get('/api/auth/me');
    assert.strictEqual(res.status, 401);
  });

  await test('GET /api/users/me without token returns 401', async () => {
    const res = await request(app).get('/api/users/me');
    assert.strictEqual(res.status, 401);
  });

  await test('GET /api/progress without token returns 401', async () => {
    const res = await request(app).get('/api/progress');
    assert.strictEqual(res.status, 401);
  });

  await test('GET /api/achievements/me without token returns 401', async () => {
    const res = await request(app).get('/api/achievements/me');
    assert.strictEqual(res.status, 401);
  });

  // 6. Malformed/invalid JWT -> 401 (jwt.verify fails before any DB lookup)
  await test('GET /api/auth/me with garbage token returns 401', async () => {
    const res = await request(app).get('/api/auth/me').set('Authorization', 'Bearer not-a-real-jwt');
    assert.strictEqual(res.status, 401);
  });

  // 7. Admin routes without a token -> 401 (authenticate runs before requireAdmin)
  await test('POST /api/admin/languages without token returns 401', async () => {
    const res = await request(app).post('/api/admin/languages').send({ name: 'Test Lang' });
    assert.strictEqual(res.status, 401);
  });

  await test('DELETE /api/admin/lessons/:id without token returns 401', async () => {
    const res = await request(app).delete('/api/admin/lessons/64b64b64b64b64b64b64b64b');
    assert.strictEqual(res.status, 401);
  });

  await test('GET /api/admin/questions without token returns 401', async () => {
    const res = await request(app).get('/api/admin/questions');
    assert.strictEqual(res.status, 401);
  });

  await test('GET /api/admin/users without token returns 401', async () => {
    const res = await request(app).get('/api/admin/users');
    assert.strictEqual(res.status, 401);
  });

  // 8. Invalid ObjectId in route params -> 400, before touching the DB
  await test('GET /api/languages/:id with invalid id returns 400', async () => {
    const res = await request(app).get('/api/languages/not-a-valid-id');
    assert.strictEqual(res.status, 400);
  });

  await test('GET /api/lessons/:id with invalid id returns 400', async () => {
    const res = await request(app).get('/api/lessons/12345');
    assert.strictEqual(res.status, 400);
  });

  await test('GET /api/quizzes/:lessonId with invalid id returns 400', async () => {
    const res = await request(app).get('/api/quizzes/xyz');
    assert.strictEqual(res.status, 400);
  });

  // 9. Query param validation (level/difficulty enums)
  await test('GET /api/lessons rejects invalid level query param', async () => {
    const res = await request(app).get('/api/lessons?level=expert');
    assert.strictEqual(res.status, 400);
  });

  await test('GET /api/vocabulary rejects invalid difficulty query param', async () => {
    const res = await request(app).get('/api/vocabulary?difficulty=extreme');
    assert.strictEqual(res.status, 400);
  });

  // 10. Quiz submit body validation (runs before optionalAuthenticate, so no DB needed)
  await test('POST /api/quizzes/submit rejects missing lessonId', async () => {
    const res = await request(app).post('/api/quizzes/submit').send({ answers: [] });
    assert.strictEqual(res.status, 400);
  });

  await test('POST /api/quizzes/submit rejects empty answers array', async () => {
    const res = await request(app)
      .post('/api/quizzes/submit')
      .send({ lessonId: '64b64b64b64b64b64b64b64b', answers: [] });
    assert.strictEqual(res.status, 400);
  });

  console.log('\n--- Scenarios requiring a live MongoDB connection (not run here) ---');
  [
    'Register a real user + duplicate registration conflict (409)',
    'Login with correct/incorrect credentials against a real user',
    'GET /api/auth/me and /api/users/me with a real valid token',
    'GET /api/languages, /api/lessons, /api/vocabulary returning real seeded data',
    'GET /api/quizzes/:lessonId returning sanitized questions (no correctAnswer field)',
    'POST /api/quizzes/submit grading real answers, awarding XP/streak/achievements',
    'GET /api/progress and /api/progress/:userId (admin) with real data',
    'PUT /api/users/me updating a real profile, confirming xp/role/password are ignored',
    'Admin CRUD create/update/delete for languages, lessons, vocabulary, questions',
    'A non-admin authenticated user hitting an admin route (expect 403)',
  ].forEach((name) => skip(name, 'requires live MongoDB'));

  console.log('\n--- Results ---');
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`Skipped (need live DB): ${skipped.length}`);

  process.exit(failed > 0 ? 1 : 0);
})();
