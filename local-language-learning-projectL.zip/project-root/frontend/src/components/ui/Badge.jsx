const TONE_CLASSES = {
  primary: 'bg-primary/10 text-primary-dark',
  secondary: 'bg-secondary/15 text-secondary-dark',
  success: 'bg-success/10 text-success',
  muted: 'bg-black/5 text-text-muted',
};

export default function Badge({ children, tone = 'primary', icon: Icon, className = '' }) {
  return (
    <span
      className={[
        'inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold',
        TONE_CLASSES[tone],
        className,
      ].join(' ')}
    >
      {Icon && <Icon className="h-3.5 w-3.5" aria-hidden="true" />}
      {children}
    </span>
  );
}
