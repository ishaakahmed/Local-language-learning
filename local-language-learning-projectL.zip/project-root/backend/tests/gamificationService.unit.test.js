const assert = require('assert');
const { calculateLevel, updateStreakForToday } = require('../services/gamificationService');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`PASS: ${name}`);
  } catch (err) {
    failed += 1;
    console.log(`FAIL: ${name}`);
    console.log(`      ${err.message}`);
  }
}

console.log('--- Gamification service unit tests ---\n');

test('calculateLevel: 0 XP is level 1', () => {
  assert.strictEqual(calculateLevel(0), 1);
});

test('calculateLevel: 99 XP is still level 1', () => {
  assert.strictEqual(calculateLevel(99), 1);
});

test('calculateLevel: 100 XP is level 2', () => {
  assert.strictEqual(calculateLevel(100), 2);
});

test('calculateLevel: 250 XP is level 3', () => {
  assert.strictEqual(calculateLevel(250), 3);
});

test('streak: first-ever activity sets streak to 1', () => {
  const user = { streak: 0, lastActiveDate: null };
  updateStreakForToday(user);
  assert.strictEqual(user.streak, 1);
  assert.ok(user.lastActiveDate instanceof Date);
});

test('streak: second activity on the SAME day does not change streak', () => {
  const now = new Date();
  const user = { streak: 3, lastActiveDate: now };
  updateStreakForToday(user);
  assert.strictEqual(user.streak, 3);
});

test('streak: activity on the very next calendar day increments streak', () => {
  const yesterday = new Date();
  yesterday.setUTCDate(yesterday.getUTCDate() - 1);
  const user = { streak: 3, lastActiveDate: yesterday };
  updateStreakForToday(user);
  assert.strictEqual(user.streak, 4);
});

test('streak: a gap of 2+ days resets streak to 1', () => {
  const threeDaysAgo = new Date();
  threeDaysAgo.setUTCDate(threeDaysAgo.getUTCDate() - 3);
  const user = { streak: 10, lastActiveDate: threeDaysAgo };
  updateStreakForToday(user);
  assert.strictEqual(user.streak, 1);
});

console.log('\n--- Results ---');
console.log(`Passed: ${passed}`);
console.log(`Failed: ${failed}`);
process.exit(failed > 0 ? 1 : 0);
