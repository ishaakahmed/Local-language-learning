// requirement.type is evaluated generically by gamificationService in Phase 3
// (streak/wordsLearned/lessonsCompleted are compared against the user's
// running totals; quizScore is compared against a single quiz's accuracy%).
module.exports = [
  {
    name: 'First Lesson',
    description: 'Complete your very first lesson.',
    icon: '🏆',
    requirement: { type: 'lessonsCompleted', value: 1 },
  },
  {
    name: '3 Day Streak',
    description: 'Practice for 3 days in a row.',
    icon: '🔥',
    requirement: { type: 'streak', value: 3 },
  },
  {
    name: '50 Words Learned',
    description: 'Learn 50 vocabulary words.',
    icon: '📚',
    requirement: { type: 'wordsLearned', value: 50 },
  },
  {
    name: 'Quiz Master',
    description: 'Score 90% or higher on a quiz.',
    icon: '🎯',
    requirement: { type: 'quizScore', value: 90 },
  },
  {
    name: 'Course Beginner',
    description: 'Complete all 5 beginner lessons in a language.',
    icon: '🌟',
    requirement: { type: 'lessonsCompleted', value: 5 },
  },
  {
    name: 'Perfect Score',
    description: 'Score 100% on a quiz.',
    icon: '💯',
    requirement: { type: 'quizScore', value: 100 },
  },
];
