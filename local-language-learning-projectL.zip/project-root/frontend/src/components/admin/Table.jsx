export default function Table({ columns, data, renderActions, emptyMessage = 'No records found.' }) {
  if (data.length === 0) {
    return <p className="text-sm text-text-muted text-center py-10">{emptyMessage}</p>;
  }

  return (
    <div className="overflow-x-auto -mx-6 px-6">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-black/10 text-left text-text-muted">
            {columns.map((col) => (
              <th key={col.key} className="py-2.5 pr-4 font-medium whitespace-nowrap">
                {col.label}
              </th>
            ))}
            {renderActions && <th className="py-2.5 pl-4 font-medium text-right">Actions</th>}
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
            <tr key={row._id} className="border-b border-black/5 last:border-0">
              {columns.map((col) => (
                <td key={col.key} className="py-3 pr-4 text-text align-top">
                  {col.render ? col.render(row) : row[col.key]}
                </td>
              ))}
              {renderActions && <td className="py-3 pl-4 text-right whitespace-nowrap">{renderActions(row)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
