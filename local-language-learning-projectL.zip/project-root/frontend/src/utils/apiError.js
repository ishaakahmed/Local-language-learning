/**
 * Pulls a user-facing message out of an axios error. Backend errors always
 * arrive as { success: false, message, details? } (see errorHandler.js) —
 * this falls back gracefully for network errors or unexpected shapes.
 */
export function getApiErrorMessage(error, fallback = 'Something went wrong. Please try again.') {
  if (!error) return fallback;

  const data = error.response?.data;
  if (data?.details?.length) {
    return data.details.join(' ');
  }
  if (data?.message) {
    return data.message;
  }
  if (error.message === 'Network Error') {
    return 'Could not reach the server. Please check your connection and try again.';
  }
  return fallback;
}
