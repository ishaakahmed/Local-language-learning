import Modal from './Modal';
import Button from '../ui/Button';

export default function ConfirmDialog({ open, onClose, onConfirm, title = 'Are you sure?', message, loading, confirmLabel = 'Delete' }) {
  return (
    <Modal open={open} onClose={onClose} title={title} maxWidth="max-w-sm">
      <p className="text-sm text-text-muted">{message}</p>
      <div className="flex gap-3 mt-6">
        <Button variant="ghost" fullWidth onClick={onClose} disabled={loading}>
          Cancel
        </Button>
        <Button variant="danger" fullWidth onClick={onConfirm} loading={loading}>
          {confirmLabel}
        </Button>
      </div>
    </Modal>
  );
}
