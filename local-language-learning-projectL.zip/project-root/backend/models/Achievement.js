const mongoose = require('mongoose');

const REQUIREMENT_TYPES = ['streak', 'wordsLearned', 'lessonsCompleted', 'quizScore'];

const achievementSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Achievement name is required'],
      trim: true,
    },
    description: {
      type: String,
      required: [true, 'Achievement description is required'],
      trim: true,
    },
    icon: {
      type: String,
      default: '🏆',
    },
    requirement: {
      type: {
        type: String,
        enum: {
          values: REQUIREMENT_TYPES,
          message: 'requirement.type must be one of: ' + REQUIREMENT_TYPES.join(', '),
        },
        required: [true, 'requirement.type is required'],
      },
      value: {
        type: Number,
        required: [true, 'requirement.value is required'],
        min: 1,
      },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Achievement', achievementSchema);
module.exports.REQUIREMENT_TYPES = REQUIREMENT_TYPES;
