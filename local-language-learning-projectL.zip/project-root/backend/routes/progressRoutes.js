const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { getMyProgress, getUserProgressById, upsertProgress } = require('../controllers/progressController');
const { authenticate, requireAdmin } = require('../middleware/auth');
const validateObjectIdParam = require('../middleware/validateObjectIdParam');
const validateRequest = require('../middleware/validateRequest');

router.use(authenticate);

router.get('/', getMyProgress);

router.post(
  '/',
  [
    body('lessonId').isMongoId().withMessage('lessonId must be a valid id'),
    body('completed').optional().isBoolean().withMessage('completed must be true/false'),
  ],
  validateRequest,
  upsertProgress
);

// Admin-only: view another specific user's progress
router.get('/:userId', validateObjectIdParam('userId'), requireAdmin, getUserProgressById);

module.exports = router;
