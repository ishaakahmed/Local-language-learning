import api from './api';

// GET /api/progress -> { summary: {xp, level, streak, dailyGoal, wordsLearnedCount, lessonsCompletedCount}, lessons: [...] }
export async function fetchMyProgress() {
  const res = await api.get('/progress');
  return res.data.data;
}

// POST /api/progress — manually mark a lesson complete (vocabulary-only completion path)
export async function markLessonProgress({ lessonId, completed = true }) {
  const res = await api.post('/progress', { lessonId, completed });
  return res.data.data.progress;
}
