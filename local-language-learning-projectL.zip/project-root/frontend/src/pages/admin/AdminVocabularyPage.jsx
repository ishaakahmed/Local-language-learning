import { useCallback, useEffect, useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import Badge from '../../components/ui/Badge';
import Spinner from '../../components/ui/Spinner';
import ErrorState from '../../components/ui/ErrorState';
import Table from '../../components/admin/Table';
import Modal from '../../components/admin/Modal';
import ConfirmDialog from '../../components/admin/ConfirmDialog';
import { fetchLanguages } from '../../services/languageService';
import { fetchVocabulary } from '../../services/vocabularyService';
import { createVocabulary, updateVocabulary, deleteVocabulary } from '../../services/adminService';
import { getApiErrorMessage } from '../../utils/apiError';

const CATEGORIES = [
  'greetings', 'family', 'food', 'travel', 'numbers', 'colors',
  'animals', 'places', 'daily-conversation', 'education', 'shopping',
];
const DIFFICULTIES = ['easy', 'medium', 'hard'];

const EMPTY_FORM = {
  languageId: '', word: '', translation: '', transliteration: '', category: 'greetings',
  exampleSentence: '', exampleSentenceTranslation: '', difficulty: 'easy',
};

function VocabForm({ initial, languages, onSubmit, onCancel, saving, submitError }) {
  const [form, setForm] = useState(
    initial ? { ...EMPTY_FORM, ...initial, languageId: initial.languageId?._id || initial.languageId } : EMPTY_FORM
  );

  const handleChange = (e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Select id="languageId" name="languageId" label="Language" value={form.languageId} onChange={handleChange} required>
        <option value="">Select a language…</option>
        {languages.map((l) => (
          <option key={l._id} value={l._id}>
            {l.name}
          </option>
        ))}
      </Select>

      <div className="grid grid-cols-2 gap-4">
        <Input id="word" name="word" label="Word (local script)" value={form.word} onChange={handleChange} required />
        <Input id="transliteration" name="transliteration" label="Transliteration" value={form.transliteration} onChange={handleChange} required />
      </div>
      <Input id="translation" name="translation" label="English translation" value={form.translation} onChange={handleChange} required />

      <div className="grid grid-cols-2 gap-4">
        <Select id="category" name="category" label="Category" value={form.category} onChange={handleChange}>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </Select>
        <Select id="difficulty" name="difficulty" label="Difficulty" value={form.difficulty} onChange={handleChange}>
          {DIFFICULTIES.map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </Select>
      </div>

      <Input
        id="exampleSentence"
        name="exampleSentence"
        label="Example sentence (local script)"
        value={form.exampleSentence}
        onChange={handleChange}
      />
      <Input
        id="exampleSentenceTranslation"
        name="exampleSentenceTranslation"
        label="Example sentence (English)"
        value={form.exampleSentenceTranslation}
        onChange={handleChange}
      />

      {submitError && <p className="text-sm text-error">{submitError}</p>}

      <div className="flex gap-3 pt-2">
        <Button type="button" variant="ghost" fullWidth onClick={onCancel} disabled={saving}>
          Cancel
        </Button>
        <Button type="submit" fullWidth loading={saving}>
          Save
        </Button>
      </div>
    </form>
  );
}

export default function AdminVocabularyPage() {
  const [languages, setLanguages] = useState([]);
  const [languageFilter, setLanguageFilter] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1 });
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');

  const [modalMode, setModalMode] = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchLanguages().then(setLanguages).catch(() => {});
  }, []);

  const load = useCallback(async () => {
    setStatus('loading');
    try {
      const params = { page, limit: 10 };
      if (languageFilter) params.languageId = languageFilter;
      if (search.trim()) params.search = search.trim();
      const data = await fetchVocabulary(params);
      setItems(data.vocabulary);
      setPagination(data.pagination);
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load vocabulary.'));
      setStatus('error');
    }
  }, [page, languageFilter, search]);

  useEffect(() => {
    load();
  }, [load]);

  const openCreate = () => {
    setEditingItem(null);
    setSubmitError('');
    setModalMode('create');
  };
  const openEdit = (item) => {
    setEditingItem(item);
    setSubmitError('');
    setModalMode('edit');
  };
  const closeModal = () => setModalMode(null);

  const handleSubmit = async (form) => {
    setSaving(true);
    setSubmitError('');
    try {
      if (modalMode === 'edit') {
        await updateVocabulary(editingItem._id, form);
      } else {
        await createVocabulary(form);
      }
      closeModal();
      await load();
    } catch (err) {
      setSubmitError(getApiErrorMessage(err, 'Could not save this word.'));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteVocabulary(deleteTarget._id);
      setDeleteTarget(null);
      await load();
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not delete this word.'));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-text">Vocabulary</h1>
          <p className="text-text-muted mt-1">Manage vocabulary words across all languages.</p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add word
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <Input
          id="vocab-admin-search"
          placeholder="Search…"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          containerClassName="flex-1"
        />
        <select
          value={languageFilter}
          onChange={(e) => {
            setLanguageFilter(e.target.value);
            setPage(1);
          }}
          className="rounded-xl border border-black/10 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
        >
          <option value="">All languages</option>
          {languages.map((l) => (
            <option key={l._id} value={l._id}>
              {l.name}
            </option>
          ))}
        </select>
      </div>

      {status === 'loading' && <Spinner className="py-16" label="Loading vocabulary…" />}
      {status === 'error' && <ErrorState message={errorMessage} onRetry={load} />}

      {status === 'ready' && (
        <>
          <Card padded={false} className="p-4 sm:p-6">
            <Table
              columns={[
                { key: 'word', label: 'Word' },
                { key: 'transliteration', label: 'Transliteration' },
                { key: 'translation', label: 'Translation' },
                { key: 'category', label: 'Category', render: (row) => <Badge tone="muted">{row.category}</Badge> },
                { key: 'difficulty', label: 'Difficulty' },
              ]}
              data={items}
              renderActions={(row) => (
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => openEdit(row)}
                    className="p-1.5 rounded-lg text-text-muted hover:bg-black/5 hover:text-primary"
                    aria-label={`Edit ${row.word}`}
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(row)}
                    className="p-1.5 rounded-lg text-text-muted hover:bg-black/5 hover:text-error"
                    aria-label={`Delete ${row.word}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              )}
              emptyMessage="No vocabulary found."
            />
          </Card>

          {pagination.totalPages > 1 && (
            <div className="flex items-center justify-center gap-3">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <span className="text-sm text-text-muted">
                Page {pagination.page} of {pagination.totalPages}
              </span>
              <Button variant="outline" size="sm" disabled={page >= pagination.totalPages} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          )}
        </>
      )}

      <Modal open={Boolean(modalMode)} onClose={closeModal} title={modalMode === 'edit' ? 'Edit word' : 'Add word'}>
        <VocabForm
          initial={editingItem}
          languages={languages}
          onSubmit={handleSubmit}
          onCancel={closeModal}
          saving={saving}
          submitError={submitError}
        />
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete word?"
        message={`This will permanently delete "${deleteTarget?.word}" and remove it from any lessons that reference it.`}
      />
    </div>
  );
}
