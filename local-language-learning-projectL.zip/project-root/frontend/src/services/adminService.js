import api from './api';

// --- Languages ---
export async function createLanguage(payload) {
  const res = await api.post('/admin/languages', payload);
  return res.data.data.language;
}
export async function updateLanguage(id, payload) {
  const res = await api.put(`/admin/languages/${id}`, payload);
  return res.data.data.language;
}
export async function deleteLanguage(id, { force = false } = {}) {
  await api.delete(`/admin/languages/${id}`, { params: force ? { force: true } : {} });
}

// --- Lessons ---
export async function createLesson(payload) {
  const res = await api.post('/admin/lessons', payload);
  return res.data.data.lesson;
}
export async function updateLesson(id, payload) {
  const res = await api.put(`/admin/lessons/${id}`, payload);
  return res.data.data.lesson;
}
export async function deleteLesson(id) {
  await api.delete(`/admin/lessons/${id}`);
}

// --- Vocabulary ---
export async function createVocabulary(payload) {
  const res = await api.post('/admin/vocabulary', payload);
  return res.data.data.vocabulary;
}
export async function updateVocabulary(id, payload) {
  const res = await api.put(`/admin/vocabulary/${id}`, payload);
  return res.data.data.vocabulary;
}
export async function deleteVocabulary(id) {
  await api.delete(`/admin/vocabulary/${id}`);
}

// --- Questions (admin sees real correctAnswer data; students never do) ---
export async function fetchQuestionsForAdmin(lessonId) {
  const res = await api.get('/admin/questions', { params: lessonId ? { lessonId } : {} });
  return res.data.data.questions;
}
export async function createQuestion(payload) {
  const res = await api.post('/admin/questions', payload);
  return res.data.data.question;
}
export async function updateQuestion(id, payload) {
  const res = await api.put(`/admin/questions/${id}`, payload);
  return res.data.data.question;
}
export async function deleteQuestion(id) {
  await api.delete(`/admin/questions/${id}`);
}

// --- Users (read-only overview) ---
export async function fetchUsersForAdmin(params = {}) {
  const res = await api.get('/admin/users', { params });
  return res.data.data; // { users, pagination }
}
