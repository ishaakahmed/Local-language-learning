const { Language, Lesson, Vocabulary, Question } = require('../models');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');

// GET /api/languages
const getLanguages = asyncHandler(async (req, res) => {
  const languages = await Language.find({ isActive: true }).sort({ name: 1 });
  res.status(200).json({ success: true, data: { languages } });
});

// GET /api/languages/:id
const getLanguageById = asyncHandler(async (req, res) => {
  const language = await Language.findById(req.params.id);
  if (!language) throw new ApiError(404, 'Language not found.');
  res.status(200).json({ success: true, data: { language } });
});

// POST /api/admin/languages
const createLanguage = asyncHandler(async (req, res) => {
  const language = await Language.create(req.body);
  res.status(201).json({ success: true, data: { language } });
});

// PUT /api/admin/languages/:id
const updateLanguage = asyncHandler(async (req, res) => {
  const language = await Language.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!language) throw new ApiError(404, 'Language not found.');
  res.status(200).json({ success: true, data: { language } });
});

// DELETE /api/admin/languages/:id
// Refuses to delete a language that still has lessons/vocabulary attached,
// unless ?force=true is passed — prevents accidentally orphaning content.
const deleteLanguage = asyncHandler(async (req, res) => {
  const language = await Language.findById(req.params.id);
  if (!language) throw new ApiError(404, 'Language not found.');

  const [lessonCount, vocabCount] = await Promise.all([
    Lesson.countDocuments({ languageId: language._id }),
    Vocabulary.countDocuments({ languageId: language._id }),
  ]);

  const force = req.query.force === 'true';
  if ((lessonCount > 0 || vocabCount > 0) && !force) {
    throw new ApiError(
      409,
      `Cannot delete: this language still has ${lessonCount} lesson(s) and ${vocabCount} vocabulary word(s). Pass ?force=true to delete them as well.`
    );
  }

  if (force) {
    const lessons = await Lesson.find({ languageId: language._id }).select('_id');
    const lessonIds = lessons.map((l) => l._id);
    await Promise.all([
      Vocabulary.deleteMany({ languageId: language._id }),
      Lesson.deleteMany({ languageId: language._id }),
      Question.deleteMany({ lessonId: { $in: lessonIds } }),
    ]);
  }

  await language.deleteOne();
  res.status(200).json({ success: true, data: {} });
});

module.exports = { getLanguages, getLanguageById, createLanguage, updateLanguage, deleteLanguage };
