import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, CheckCircle2, XCircle, RotateCcw, Trophy } from 'lucide-react';
import Spinner from '../components/ui/Spinner';
import ErrorState from '../components/ui/ErrorState';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import QuizQuestionRenderer from '../components/QuizQuestionRenderer';
import { fetchQuiz, submitQuiz } from '../services/quizService';
import { fetchLessonById } from '../services/lessonService';
import useAuth from '../hooks/useAuth';
import { getApiErrorMessage } from '../utils/apiError';

function isAnswered(question, value) {
  if (value === undefined || value === null) return false;
  if (question.type === 'reorder') return value.length === question.payload.words.length;
  if (question.type === 'match') return value.length === question.payload.lefts.length;
  if (typeof value === 'string') return value.trim().length > 0;
  return true;
}

export default function QuizPage() {
  const { lessonId } = useParams();
  const { updateUser } = useAuth();

  const [lesson, setLesson] = useState(null);
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [currentIndex, setCurrentIndex] = useState(0);
  const [status, setStatus] = useState('loading'); // loading | error | ready | submitting | results
  const [errorMessage, setErrorMessage] = useState('');
  const [result, setResult] = useState(null);

  const load = useCallback(async () => {
    setStatus('loading');
    setAnswers({});
    setCurrentIndex(0);
    setResult(null);
    try {
      const [quizData, lessonData] = await Promise.all([fetchQuiz(lessonId), fetchLessonById(lessonId)]);
      setQuiz(quizData);
      setLesson(lessonData);
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load this quiz.'));
      setStatus('error');
    }
  }, [lessonId]);

  useEffect(() => {
    load();
  }, [load]);

  if (status === 'loading') return <Spinner className="py-16" label="Loading quiz…" />;
  if (status === 'error') return <ErrorState message={errorMessage} onRetry={load} />;
  if (!quiz) return null;

  const questions = quiz.questions;
  const currentQuestion = questions[currentIndex];
  const speechLocale = lesson?.languageId?.speechLocale;

  const handleAnswerChange = (value) => {
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: value }));
  };

  const handleSubmit = async () => {
    setStatus('submitting');
    setErrorMessage('');
    try {
      const payload = {
        lessonId,
        answers: questions.map((q) => ({ questionId: q.id, answer: answers[q.id] })),
      };
      const data = await submitQuiz(payload);
      setResult(data);
      if (data.user) updateUser(data.user); // keep XP/level/streak in sync everywhere (e.g. Topbar)
      setStatus('results');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not submit your quiz.'));
      setStatus('ready');
    }
  };

  // --- Results screen ---
  if (status === 'results' && result) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <Card className="text-center">
          <div className="h-16 w-16 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4">
            <Trophy className="h-8 w-8" aria-hidden="true" />
          </div>
          <h1 className="text-2xl font-bold text-text">Quiz complete!</h1>
          <p className="text-text-muted mt-1">{quiz.lessonTitle}</p>

          <div className="grid grid-cols-3 gap-4 mt-6">
            <div>
              <p className="text-2xl font-bold text-text">
                {result.correctCount}/{result.totalQuestions}
              </p>
              <p className="text-xs text-text-muted mt-1">Correct</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-text">{result.accuracy}%</p>
              <p className="text-xs text-text-muted mt-1">Accuracy</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary">+{result.xpEarned}</p>
              <p className="text-xs text-text-muted mt-1">XP earned</p>
            </div>
          </div>

          {result.newAchievements?.length > 0 && (
            <div className="mt-6 pt-6 border-t border-black/5">
              <p className="text-sm font-semibold text-text mb-3">New achievement unlocked!</p>
              <div className="flex justify-center gap-3 flex-wrap">
                {result.newAchievements.map((a) => (
                  <Badge key={a._id} tone="secondary">
                    {a.icon} {a.name}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </Card>

        <div className="space-y-3">
          <h2 className="font-semibold text-text">Review your answers</h2>
          {result.results.map((r, i) => (
            <Card key={r.questionId} className={r.correct ? 'border-success/30' : 'border-error/30'}>
              <div className="flex items-start gap-3">
                {r.correct ? (
                  <CheckCircle2 className="h-5 w-5 text-success shrink-0 mt-0.5" aria-hidden="true" />
                ) : (
                  <XCircle className="h-5 w-5 text-error shrink-0 mt-0.5" aria-hidden="true" />
                )}
                <div className="min-w-0">
                  <p className="text-sm font-medium text-text">{questions[i]?.prompt}</p>
                  {!r.correct && (
                    <p className="text-sm text-text-muted mt-1">
                      Correct answer: <span className="font-medium text-success">{JSON.stringify(r.correctAnswer)}</span>
                    </p>
                  )}
                  {r.explanation && <p className="text-sm text-text-muted mt-1">{r.explanation}</p>}
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Button variant="outline" onClick={load} fullWidth>
            <RotateCcw className="h-4 w-4" /> Retry quiz
          </Button>
          <Link to={`/lessons/${lessonId}`} className="w-full">
            <Button fullWidth>Back to lesson</Button>
          </Link>
        </div>
      </div>
    );
  }

  // --- Quiz-taking screen ---
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <div className="flex items-center justify-between text-sm text-text-muted mb-2">
          <span>{quiz.lessonTitle}</span>
          <span>
            Question {currentIndex + 1} of {questions.length}
          </span>
        </div>
        <div className="h-2 rounded-full bg-black/5 overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all"
            style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <Card>
        <h2 className="text-lg font-semibold text-text mb-5">{currentQuestion.prompt}</h2>
        <QuizQuestionRenderer
          question={currentQuestion}
          value={answers[currentQuestion.id]}
          onChange={handleAnswerChange}
          speechLocale={speechLocale}
        />
      </Card>

      {errorMessage && <p className="text-sm text-error text-center">{errorMessage}</p>}

      <div className="flex items-center justify-between gap-3">
        <Button variant="ghost" disabled={currentIndex === 0} onClick={() => setCurrentIndex((i) => i - 1)}>
          <ArrowLeft className="h-4 w-4" /> Previous
        </Button>

        {currentIndex < questions.length - 1 ? (
          <Button onClick={() => setCurrentIndex((i) => i + 1)} disabled={!isAnswered(currentQuestion, answers[currentQuestion.id])}>
            Next <ArrowRight className="h-4 w-4" />
          </Button>
        ) : (
          <Button
            onClick={handleSubmit}
            loading={status === 'submitting'}
            disabled={!questions.every((q) => isAnswered(q, answers[q.id]))}
          >
            Submit quiz
          </Button>
        )}
      </div>
    </div>
  );
}
