module.exports = {
  User: require('./User'),
  Language: require('./Language'),
  Lesson: require('./Lesson'),
  Vocabulary: require('./Vocabulary'),
  Question: require('./Question'),
  UserProgress: require('./UserProgress'),
  UserVocabProgress: require('./UserVocabProgress'),
  Achievement: require('./Achievement'),
  UserAchievement: require('./UserAchievement'),
};
