import Card from './ui/Card';
import Badge from './ui/Badge';
import PronounceButton from './PronounceButton';
import { CheckCircle2 } from 'lucide-react';

const DIFFICULTY_TONE = { easy: 'success', medium: 'secondary', hard: 'primary' };

export default function VocabularyCard({ vocab, speechLocale, learned = false }) {
  return (
    <Card className="relative">
      {learned && (
        <span className="absolute top-4 right-4 text-success" title="Learned">
          <CheckCircle2 className="h-5 w-5" aria-hidden="true" />
        </span>
      )}
      <div className="flex items-start justify-between gap-3 pr-6">
        <div>
          <p className="text-2xl font-semibold text-text" lang="und">
            {vocab.word}
          </p>
          <p className="text-sm text-text-muted italic mt-0.5">{vocab.transliteration}</p>
        </div>
        <PronounceButton text={vocab.pronunciation || vocab.word} locale={speechLocale} size="sm" />
      </div>

      <p className="mt-3 text-lg font-medium text-primary">{vocab.translation}</p>

      {vocab.exampleSentence && (
        <div className="mt-3 pt-3 border-t border-black/5 text-sm text-text-muted space-y-0.5">
          <p lang="und">{vocab.exampleSentence}</p>
          {vocab.exampleSentenceTranslation && <p>{vocab.exampleSentenceTranslation}</p>}
        </div>
      )}

      <div className="mt-3 flex items-center gap-2">
        <Badge tone="muted">{vocab.category}</Badge>
        {vocab.difficulty && <Badge tone={DIFFICULTY_TONE[vocab.difficulty] || 'muted'}>{vocab.difficulty}</Badge>}
      </div>
    </Card>
  );
}
