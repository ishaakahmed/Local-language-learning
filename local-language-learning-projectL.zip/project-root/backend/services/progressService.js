const { User, UserProgress, UserVocabProgress } = require('../models');

/**
 * Builds the aggregated progress/dashboard view for a single user:
 * their gamification stats plus their per-lesson progress records.
 */
async function getDashboardSummary(userId) {
  const [user, lessonProgress] = await Promise.all([
    User.findById(userId),
    UserProgress.find({ userId })
      .populate({ path: 'lessonId', select: 'title category level order languageId' })
      .sort({ updatedAt: -1 }),
  ]);

  const lessonsCompletedCount = lessonProgress.filter((p) => p.completed).length;

  return {
    summary: {
      xp: user.xp,
      level: user.level,
      streak: user.streak,
      dailyGoal: user.dailyGoal,
      wordsLearnedCount: user.wordsLearned.length,
      lessonsCompletedCount,
    },
    lessons: lessonProgress,
  };
}

/**
 * Marks every vocabulary word belonging to a lesson as "learned" for a user:
 * upserts a UserVocabProgress record per word and adds it to the user's
 * wordsLearned set (deduplicated via $addToSet, so repeat lesson attempts
 * never inflate the count).
 */
async function markLessonVocabularyLearned(userId, vocabIds) {
  if (!vocabIds || vocabIds.length === 0) return;

  const now = new Date();

  await Promise.all(
    vocabIds.map((vocabId) =>
      UserVocabProgress.findOneAndUpdate(
        { userId, vocabId },
        { $set: { learned: true, lastReviewedAt: now }, $inc: { reviewCount: 1 } },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      )
    )
  );

  await User.findByIdAndUpdate(userId, { $addToSet: { wordsLearned: { $each: vocabIds } } });
}

module.exports = { getDashboardSummary, markLessonVocabularyLearned };
