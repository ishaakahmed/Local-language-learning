const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { getProfile, updateProfile } = require('../controllers/userController');
const { authenticate } = require('../middleware/auth');
const validateRequest = require('../middleware/validateRequest');

router.use(authenticate);

router.get('/me', getProfile);

router.put(
  '/me',
  [
    body('name').optional().trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters'),
    body('selectedLanguage').optional().isMongoId().withMessage('selectedLanguage must be a valid language id'),
    body('dailyGoal').optional().isInt({ min: 1 }).withMessage('dailyGoal must be a positive integer'),
  ],
  validateRequest,
  updateProfile
);

module.exports = router;
