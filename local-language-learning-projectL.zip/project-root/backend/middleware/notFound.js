const ApiError = require('../utils/ApiError');

/**
 * Catches any request that didn't match a defined route
 * and forwards a clean 404 to the central error handler.
 */
const notFound = (req, res, next) => {
  next(new ApiError(404, `Route not found: ${req.method} ${req.originalUrl}`));
};

module.exports = notFound;
