import api from './api';

// GET /api/quizzes/:lessonId -> sanitized questions, no correct answers included
export async function fetchQuiz(lessonId) {
  const res = await api.get(`/quizzes/${lessonId}`);
  return res.data.data; // { lessonId, lessonTitle, questionCount, questions }
}

// POST /api/quizzes/submit — backend grades from scratch; client score is never trusted
export async function submitQuiz({ lessonId, answers }) {
  const res = await api.post('/quizzes/submit', { lessonId, answers });
  return res.data.data; // { totalQuestions, correctCount, accuracy, xpEarned, results, user?, newAchievements? }
}
