const { validationResult } = require('express-validator');
const ApiError = require('../utils/ApiError');

/**
 * Runs after express-validator check(...) middlewares on a route.
 * If any validation failed, throws a single 400 with all field messages
 * collected — routes never need their own try/catch for this.
 */
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const messages = errors.array().map((e) => `${e.path}: ${e.msg}`);
    const err = new ApiError(400, 'Validation failed');
    err.details = messages;
    return next(err);
  }
  next();
};

module.exports = validateRequest;
