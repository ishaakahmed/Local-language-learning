import { useCallback, useEffect, useState } from 'react';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import Badge from '../../components/ui/Badge';
import Spinner from '../../components/ui/Spinner';
import ErrorState from '../../components/ui/ErrorState';
import Table from '../../components/admin/Table';
import { fetchUsersForAdmin } from '../../services/adminService';
import { getApiErrorMessage } from '../../utils/apiError';

export default function AdminUsersPage() {
  const [users, setUsers] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1 });
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');

  const load = useCallback(async () => {
    setStatus('loading');
    try {
      const params = { page, limit: 15 };
      if (search.trim()) params.search = search.trim();
      const data = await fetchUsersForAdmin(params);
      setUsers(data.users);
      setPagination(data.pagination);
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load users.'));
      setStatus('error');
    }
  }, [page, search]);

  useEffect(() => {
    load();
  }, [load]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setPage(1);
    load();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Users</h1>
        <p className="text-text-muted mt-1">Read-only overview of registered users.</p>
      </div>

      <form onSubmit={handleSearchSubmit} className="flex gap-3">
        <Input
          id="user-search"
          placeholder="Search by name or email…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          containerClassName="flex-1"
        />
        <Button type="submit">Search</Button>
      </form>

      {status === 'loading' && <Spinner className="py-16" label="Loading users…" />}
      {status === 'error' && <ErrorState message={errorMessage} onRetry={load} />}

      {status === 'ready' && (
        <>
          <Card padded={false} className="p-4 sm:p-6">
            <Table
              columns={[
                { key: 'name', label: 'Name' },
                { key: 'email', label: 'Email' },
                { key: 'role', label: 'Role', render: (row) => <Badge tone={row.role === 'admin' ? 'secondary' : 'muted'}>{row.role}</Badge> },
                { key: 'level', label: 'Level' },
                { key: 'xp', label: 'XP' },
                { key: 'streak', label: 'Streak' },
                { key: 'createdAt', label: 'Joined', render: (row) => new Date(row.createdAt).toLocaleDateString() },
              ]}
              data={users}
              emptyMessage="No users found."
            />
          </Card>

          {pagination.totalPages > 1 && (
            <div className="flex items-center justify-center gap-3">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <span className="text-sm text-text-muted">
                Page {pagination.page} of {pagination.totalPages}
              </span>
              <Button variant="outline" size="sm" disabled={page >= pagination.totalPages} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
