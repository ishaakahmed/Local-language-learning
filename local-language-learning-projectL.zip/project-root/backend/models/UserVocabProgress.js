const mongoose = require('mongoose');

const userVocabProgressSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'userId is required'],
      index: true,
    },
    vocabId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Vocabulary',
      required: [true, 'vocabId is required'],
      index: true,
    },
    learned: {
      type: Boolean,
      default: false,
    },
    reviewCount: {
      type: Number,
      default: 0,
      min: 0,
    },
    lastReviewedAt: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true }
);

// One tracking record per user per word
userVocabProgressSchema.index({ userId: 1, vocabId: 1 }, { unique: true });

module.exports = mongoose.model('UserVocabProgress', userVocabProgressSchema);
