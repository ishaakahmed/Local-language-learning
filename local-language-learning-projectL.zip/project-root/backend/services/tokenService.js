const jwt = require('jsonwebtoken');

/**
 * Signs a JWT for the given user. Keeps the payload minimal (id + role) —
 * anything else needed by the client comes from GET /api/auth/me instead
 * of being baked into the token.
 */
function generateToken(user) {
  return jwt.sign({ id: user._id.toString(), role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
}

module.exports = { generateToken };
