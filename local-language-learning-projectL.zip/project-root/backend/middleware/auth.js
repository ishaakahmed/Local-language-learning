const jwt = require('jsonwebtoken');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const { User } = require('../models');

/**
 * Verifies the Bearer JWT on the request, loads the corresponding user,
 * and attaches it to req.user. Throws 401 for any missing/invalid/expired
 * token or a user that no longer exists.
 */
const authenticate = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization;

  if (!header || !header.startsWith('Bearer ')) {
    throw new ApiError(401, 'Authentication required. Provide a Bearer token in the Authorization header.');
  }

  const token = header.split(' ')[1];

  // jwt.verify throws JsonWebTokenError/TokenExpiredError on failure —
  // both are already translated to a clean 401 by the central error handler.
  const decoded = jwt.verify(token, process.env.JWT_SECRET);

  const user = await User.findById(decoded.id);
  if (!user) {
    throw new ApiError(401, 'The user for this token no longer exists.');
  }

  req.user = user;
  next();
});

/**
 * Must run AFTER authenticate. Restricts the route to users with role 'admin'.
 * NOTE: this project's User model uses role values 'student' | 'admin'
 * (not 'user' | 'admin').
 */
const requireAdmin = (req, res, next) => {
  if (!req.user) {
    throw new ApiError(401, 'Authentication required.');
  }
  if (req.user.role !== 'admin') {
    throw new ApiError(403, 'This action requires administrator privileges.');
  }
  next();
};

/**
 * Like authenticate, but never throws — if a valid token is present, req.user
 * is set; otherwise the request proceeds as anonymous. Used for routes (like
 * quiz submission) that work for guests but unlock extra behavior when logged in.
 */
const optionalAuthenticate = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return next();
  }

  try {
    const token = header.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    if (user) req.user = user;
  } catch (err) {
    // Invalid/expired token on an optional route — just proceed as anonymous
    // rather than failing the whole request.
  }
  next();
});

module.exports = { authenticate, requireAdmin, optionalAuthenticate };
