const mongoose = require('mongoose');

const languageSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Language name is required'],
      trim: true,
    },
    nativeName: {
      type: String,
      required: [true, 'Native name is required'],
      trim: true,
    },
    code: {
      type: String,
      required: [true, 'Language code is required'],
      unique: true,
      lowercase: true,
      trim: true,
      // e.g. 'mr', 'hi', 'gu' — kept short and unique so new languages plug in without code changes
    },
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description cannot exceed 500 characters'],
    },
    script: {
      type: String,
      required: [true, 'Script name is required'],
      trim: true, // e.g. 'Devanagari', 'Gujarati'
    },
    speechLocale: {
      type: String,
      required: [true, 'BCP-47 speech locale is required'],
      trim: true, // e.g. 'mr-IN', used to match a Web Speech API voice
    },
    icon: {
      type: String,
      default: '',
    },
    isActive: {
      type: Boolean,
      default: true, // lets admins stage a language before it's shown to students
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Language', languageSchema);
