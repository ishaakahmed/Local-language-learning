import api from './api';

// GET /api/lessons?languageId=&level=&category=
export async function fetchLessons(params = {}) {
  const res = await api.get('/lessons', { params });
  return res.data.data.lessons;
}

// GET /api/lessons/:id -> fully populated (language + vocabulary)
export async function fetchLessonById(id) {
  const res = await api.get(`/lessons/${id}`);
  return res.data.data.lesson;
}
