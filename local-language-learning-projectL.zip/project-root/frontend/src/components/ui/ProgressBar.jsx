export default function ProgressBar({ value = 0, max = 100, className = '', barClassName = '' }) {
  const pct = max > 0 ? Math.min(100, Math.max(0, (value / max) * 100)) : 0;
  return (
    <div
      className={['h-2.5 rounded-full bg-black/5 overflow-hidden', className].join(' ')}
      role="progressbar"
      aria-valuenow={value}
      aria-valuemin={0}
      aria-valuemax={max}
    >
      <div className={['h-full bg-primary rounded-full transition-all', barClassName].join(' ')} style={{ width: `${pct}%` }} />
    </div>
  );
}
