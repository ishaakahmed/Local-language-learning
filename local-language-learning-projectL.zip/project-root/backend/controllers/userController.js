const { User } = require('../models');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/users/me
const getProfile = asyncHandler(async (req, res) => {
  res.status(200).json({ success: true, data: { user: req.user } });
});

// PUT /api/users/me
// Only a fixed whitelist of fields can ever be updated here — xp, level,
// streak, role, and password are intentionally excluded no matter what the
// request body contains, since those are controlled by backend logic only.
const updateProfile = asyncHandler(async (req, res) => {
  const allowedFields = ['name', 'selectedLanguage', 'dailyGoal'];
  const updates = {};
  for (const field of allowedFields) {
    if (req.body[field] !== undefined) updates[field] = req.body[field];
  }

  const user = await User.findByIdAndUpdate(req.user._id, updates, {
    new: true,
    runValidators: true,
  });

  res.status(200).json({ success: true, data: { user } });
});

// GET /api/admin/users?search=&page=&limit= — admin-only, read-only overview.
// Deliberately no update/delete here: role changes and account deletion
// weren't requested and are sensitive enough to warrant their own review.
const getAllUsersForAdmin = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.search) {
    const regex = new RegExp(req.query.search.trim(), 'i');
    filter.$or = [{ name: regex }, { email: regex }];
  }

  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
  const skip = (page - 1) * limit;

  const [users, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
    User.countDocuments(filter),
  ]);

  res.status(200).json({
    success: true,
    data: { users, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } },
  });
});

module.exports = { getProfile, updateProfile, getAllUsersForAdmin };
