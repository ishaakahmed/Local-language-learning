import { Volume2 } from 'lucide-react';
import usePronunciation from '../hooks/usePronunciation';

export default function PronounceButton({ text, locale, size = 'md', className = '' }) {
  const { speak, speaking, supported } = usePronunciation(locale);

  if (!supported) return null; // never break the page if the browser can't speak

  const dimensions = size === 'sm' ? 'h-8 w-8' : 'h-10 w-10';
  const iconSize = size === 'sm' ? 'h-4 w-4' : 'h-5 w-5';

  return (
    <button
      type="button"
      onClick={() => speak(text)}
      disabled={speaking}
      title="Listen to pronunciation"
      aria-label="Listen to pronunciation"
      className={[
        dimensions,
        'inline-flex items-center justify-center rounded-full bg-primary/10 text-primary',
        'hover:bg-primary/20 transition-colors disabled:opacity-60',
        className,
      ].join(' ')}
    >
      <Volume2 className={[iconSize, speaking ? 'animate-pulse' : ''].join(' ')} aria-hidden="true" />
    </button>
  );
}
