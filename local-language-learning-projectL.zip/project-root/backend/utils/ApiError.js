/**
 * Standard application error carrying an HTTP status code.
 * Controllers/services throw this for expected failure cases
 * (not found, unauthorized, bad input) so the error handler
 * can respond appropriately instead of leaking a generic 500.
 */
class ApiError extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true; // distinguishes expected errors from bugs
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = ApiError;
