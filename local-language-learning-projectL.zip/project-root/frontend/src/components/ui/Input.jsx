export default function Input({ label, id, error, className = '', containerClassName = '', ...rest }) {
  return (
    <div className={containerClassName}>
      {label && (
        <label htmlFor={id} className="block text-sm font-medium text-text mb-1.5">
          {label}
        </label>
      )}
      <input
        id={id}
        className={[
          'w-full rounded-xl border px-4 py-2.5 text-sm text-text placeholder:text-text-muted/70',
          'focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-colors',
          error ? 'border-error' : 'border-black/10',
          className,
        ].join(' ')}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${id}-error` : undefined}
        {...rest}
      />
      {error && (
        <p id={`${id}-error`} className="mt-1.5 text-sm text-error">
          {error}
        </p>
      )}
    </div>
  );
}
