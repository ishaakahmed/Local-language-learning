import { Link } from 'react-router-dom';
import { BookOpen, Volume2, Trophy, TrendingUp } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import useAuth from '../hooks/useAuth';

const FEATURES = [
  {
    icon: BookOpen,
    title: 'Structured Lessons',
    description: 'Learn greetings, numbers, family, food, and colors through bite-sized, well-organized lessons.',
  },
  {
    icon: Volume2,
    title: 'Vocabulary & Pronunciation',
    description: 'Build your word bank with transliteration, example sentences, and spoken pronunciation.',
  },
  {
    icon: TrendingUp,
    title: 'Practice & Quizzes',
    description: 'Reinforce what you learn with varied quiz styles — multiple choice, matching, and more.',
  },
  {
    icon: Trophy,
    title: 'Track Your Progress',
    description: 'Earn XP, build streaks, and unlock achievements as your language skills grow.',
  },
];

export default function HomePage() {
  const { isAuthenticated } = useAuth();

  return (
    <div>
      {/* Hero */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-16 pb-20 sm:pt-24 sm:pb-28 text-center">
        <span className="inline-block text-xs font-semibold tracking-wide uppercase text-primary bg-primary/10 rounded-full px-4 py-1.5 mb-6">
          Marathi · Hindi · Gujarati
        </span>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-text tracking-tight leading-tight">
          Learn Your Local Language.
          <br className="hidden sm:block" /> Connect With Your Culture.
        </h1>
        <p className="mt-6 text-lg text-text-muted max-w-2xl mx-auto">
          Learn vocabulary, phrases, pronunciation, and everyday conversations through interactive lessons
          built around the languages of India.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link to={isAuthenticated ? '/dashboard' : '/register'}>
            <Button size="lg">Start Learning</Button>
          </Link>
          <Link to="/languages">
            <Button variant="outline" size="lg">
              Explore Languages
            </Button>
          </Link>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-24">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {FEATURES.map(({ icon: Icon, title, description }) => (
            <Card key={title} className="text-left">
              <div className="h-11 w-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-4">
                <Icon className="h-5 w-5" aria-hidden="true" />
              </div>
              <h3 className="font-semibold text-text mb-1.5">{title}</h3>
              <p className="text-sm text-text-muted">{description}</p>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
