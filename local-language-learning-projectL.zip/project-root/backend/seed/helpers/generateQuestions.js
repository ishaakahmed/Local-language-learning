/**
 * Generates 5 questions (5 distinct types) for a lesson, derived directly
 * from that lesson's vocabulary array. Deriving questions from vocab data
 * (rather than hand-authoring them separately) guarantees the correct
 * answers always match the vocabulary — no risk of the two drifting apart.
 *
 * Requires at least 10 vocabulary entries (each seed lesson provides 10).
 */
function shuffle(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

/**
 * Finds `needle` inside `haystack` case-insensitively and returns the exact
 * substring as it actually appears (preserving original casing), or null.
 */
function findExactCaseMatch(haystack, needle) {
  const idx = haystack.toLowerCase().indexOf(needle.toLowerCase());
  if (idx === -1) return null;
  return haystack.slice(idx, idx + needle.length);
}

function generateQuestionsForLesson(vocabList) {
  if (vocabList.length < 10) {
    throw new Error('generateQuestionsForLesson requires at least 10 vocabulary entries');
  }

  const questions = [];

  // --- Q1: MCQ — local word/transliteration -> English meaning ---
  const mcqTarget = vocabList[0];
  const mcqDistractors = [vocabList[1].translation, vocabList[2].translation];
  questions.push({
    type: 'mcq',
    prompt: `What does "${mcqTarget.word} (${mcqTarget.transliteration})" mean in English?`,
    payload: {
      options: shuffle([mcqTarget.translation, ...mcqDistractors]),
      correctAnswer: mcqTarget.translation,
    },
    explanation: `"${mcqTarget.word}" (${mcqTarget.transliteration}) means "${mcqTarget.translation}".`,
    difficulty: 'easy',
  });

  // --- Q2: Translate — English meaning -> correct local word ---
  const translateTarget = vocabList[3];
  const translateDistractors = [vocabList[4].word, vocabList[5].word];
  questions.push({
    type: 'translate',
    prompt: `Which word means "${translateTarget.translation}"?`,
    payload: {
      options: shuffle([translateTarget.word, ...translateDistractors]),
      correctAnswer: translateTarget.word,
    },
    explanation: `"${translateTarget.translation}" translates to "${translateTarget.word}" (${translateTarget.transliteration}).`,
    difficulty: 'medium',
  });

  // --- Q3: Fill in the blank — derived from the example sentence ---
  const fillBlankTarget = vocabList[6];
  const matched = findExactCaseMatch(fillBlankTarget.exampleSentenceTranslation, fillBlankTarget.translation);
  if (!matched) {
    throw new Error(
      `exampleSentenceTranslation for "${fillBlankTarget.word}" must contain its translation ("${fillBlankTarget.translation}") for the fill-blank question to be generated.`
    );
  }
  const sentenceWithBlank = fillBlankTarget.exampleSentenceTranslation.replace(matched, '___');
  questions.push({
    type: 'fillBlank',
    prompt: 'Fill in the blank to complete the sentence.',
    payload: {
      sentence: sentenceWithBlank,
      correctAnswer: matched,
    },
    explanation: `The full sentence is: "${fillBlankTarget.exampleSentenceTranslation}"`,
    difficulty: 'medium',
  });

  // --- Q4: Match the word — 3 word/meaning pairs ---
  const matchWords = [vocabList[0], vocabList[3], vocabList[7]];
  questions.push({
    type: 'match',
    prompt: 'Match each word to its correct English meaning.',
    payload: {
      pairs: matchWords.map((v) => ({ left: `${v.word} (${v.transliteration})`, right: v.translation })),
    },
    explanation: 'Each local-language word is matched to its English translation.',
    difficulty: 'medium',
  });

  // --- Q5: Reorder — arrange the English example sentence in order ---
  const reorderTarget = vocabList[9];
  const cleanedSentence = reorderTarget.exampleSentenceTranslation.replace(/[.?!]/g, '').trim();
  const correctOrder = cleanedSentence.split(' ');
  if (correctOrder.length < 2) {
    throw new Error(`exampleSentenceTranslation for "${reorderTarget.word}" is too short to build a reorder question.`);
  }
  questions.push({
    type: 'reorder',
    prompt: `Arrange the words to form a correct sentence about "${reorderTarget.translation}".`,
    payload: {
      words: shuffle(correctOrder),
      correctOrder,
    },
    explanation: `The correct sentence is: "${correctOrder.join(' ')}."`,
    difficulty: 'hard',
  });

  return questions;
}

module.exports = { generateQuestionsForLesson, shuffle, findExactCaseMatch };
