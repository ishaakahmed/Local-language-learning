/**
 * Wraps an async Express route handler so any thrown error / rejected promise
 * is automatically forwarded to next(), reaching the central error handler
 * instead of crashing the process or requiring try/catch in every controller.
 */
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

module.exports = asyncHandler;
