export default function Card({ children, className = '', padded = true, ...rest }) {
  return (
    <div
      className={[
        'bg-surface rounded-2xl border border-black/5 shadow-sm',
        padded ? 'p-6' : '',
        className,
      ].join(' ')}
      {...rest}
    >
      {children}
    </div>
  );
}
