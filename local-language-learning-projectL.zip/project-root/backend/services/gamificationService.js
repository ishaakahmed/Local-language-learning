const { Achievement, UserAchievement, UserProgress } = require('../models');

const XP_PER_CORRECT_ANSWER = 10;
const LESSON_COMPLETION_BONUS_XP = 20;

/**
 * Simple, transparent leveling curve: 100 XP per level.
 */
function calculateLevel(xp) {
  return Math.floor(xp / 100) + 1;
}

/**
 * Updates a user's daily streak based on calendar-day comparison (UTC) of
 * lastActiveDate vs today. Mutates the passed-in user document in place
 * (caller is responsible for saving it). Does NOT save the user itself,
 * so it can be combined with other field updates in a single .save() call.
 */
function updateStreakForToday(user) {
  const now = new Date();
  const todayKey = now.toISOString().slice(0, 10); // 'YYYY-MM-DD'

  if (!user.lastActiveDate) {
    user.streak = 1;
    user.lastActiveDate = now;
    return;
  }

  const lastKey = new Date(user.lastActiveDate).toISOString().slice(0, 10);
  if (lastKey === todayKey) {
    // Already active today — streak unchanged.
    return;
  }

  const yesterday = new Date(now);
  yesterday.setUTCDate(yesterday.getUTCDate() - 1);
  const yesterdayKey = yesterday.toISOString().slice(0, 10);

  if (lastKey === yesterdayKey) {
    user.streak += 1; // consecutive day
  } else {
    user.streak = 1; // streak broken, restart
  }

  user.lastActiveDate = now;
}

/**
 * Evaluates every Achievement definition the user hasn't already earned
 * against their current stats, and awards any newly-met ones.
 *
 * `quizAccuracy` (0-100) is optional and only relevant right after a quiz
 * submission — it's the one stat that isn't a persisted running total.
 *
 * Returns the array of newly-awarded Achievement documents.
 */
async function checkAndAwardAchievements(user, { quizAccuracy } = {}) {
  const [allAchievements, alreadyEarnedIds, lessonsCompletedCount] = await Promise.all([
    Achievement.find({}),
    UserAchievement.find({ userId: user._id }).distinct('achievementId'),
    UserProgress.countDocuments({ userId: user._id, completed: true }),
  ]);

  const earnedSet = new Set(alreadyEarnedIds.map(String));
  const newlyAwarded = [];

  for (const achievement of allAchievements) {
    if (earnedSet.has(String(achievement._id))) continue;

    const { type, value } = achievement.requirement;
    let eligible = false;

    switch (type) {
      case 'streak':
        eligible = user.streak >= value;
        break;
      case 'wordsLearned':
        eligible = user.wordsLearned.length >= value;
        break;
      case 'lessonsCompleted':
        eligible = lessonsCompletedCount >= value;
        break;
      case 'quizScore':
        eligible = typeof quizAccuracy === 'number' && quizAccuracy >= value;
        break;
      default:
        eligible = false;
    }

    if (!eligible) continue;

    try {
      await UserAchievement.create({ userId: user._id, achievementId: achievement._id });
      newlyAwarded.push(achievement);
    } catch (err) {
      // Duplicate key = already awarded concurrently elsewhere; safe to ignore.
      if (err.code !== 11000) throw err;
    }
  }

  return newlyAwarded;
}

module.exports = {
  XP_PER_CORRECT_ANSWER,
  LESSON_COMPLETION_BONUS_XP,
  calculateLevel,
  updateStreakForToday,
  checkAndAwardAchievements,
};
