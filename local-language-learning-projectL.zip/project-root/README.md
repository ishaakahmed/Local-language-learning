# BhashaSetu — Local Language Learning Platform

A full-stack educational platform for learning Marathi, Hindi, and Gujarati through structured lessons, vocabulary, pronunciation, and quizzes — built as a TYBSc Computer Science academic project.

## Purpose

Most local-language learning resources in India are either fragmented (a vocabulary list here, a phrasebook there) or built for a single language with no path to add more. BhashaSetu is **fully data-driven**: every language, lesson, vocabulary word, and quiz question lives in MongoDB. Adding a fourth or fifth language never requires touching application code — only inserting new documents. It also demonstrates a complete, secure, full-stack architecture: JWT auth, server-authoritative quiz grading (the backend recalculates every score from scratch — a client can never submit a fake result), and a real admin panel for content management.

## Main Features

- **Learning module** — browse lessons by language, view vocabulary with transliteration and example sentences, listen to pronunciation via the Web Speech API, mark lessons as read, navigate prev/next
- **Vocabulary** — search, filter by category, paginate, see which words you've already learned
- **Quiz system** — 7 question types (multiple choice, translate, listen-and-select, image-select, fill-in-the-blank, reorder, match-the-word), graded entirely server-side, with a results screen showing per-question correct/incorrect feedback and a retry option
- **Progress & gamification** — XP, levels, daily streaks, per-lesson history, course completion percentage, and an achievement system (6 badges) that unlocks automatically based on real activity
- **Admin panel** — full CRUD for languages, lessons, vocabulary, and quiz questions; a read-only user overview; all protected by role-based authorization on both the frontend (UX) and backend (actual security)

## Technology Stack

| Layer | Technology | Why |
|---|---|---|
| Frontend | React 18 + Vite | Fast dev loop, small bundle, no framework overhead for a project this size |
| Styling | Tailwind CSS | Centralized design tokens (`tailwind.config.js`) instead of scattered inline styles |
| Routing | React Router v6 | Nested layouts + route guards for auth/admin gating |
| Icons | lucide-react | Lightweight, tree-shakeable |
| Backend | Node.js + Express | Simple, well-understood REST architecture |
| Database | MongoDB + Mongoose | Flexible schema suits the variable shape of quiz question payloads |
| Auth | JWT + bcryptjs | Stateless auth, industry-standard password hashing |
| Pronunciation | Web Speech API (native browser) | No paid TTS service needed; degrades gracefully where unsupported |
| Testing | Node's built-in test patterns + supertest | No framework overhead; 41 backend tests run without needing a live database |

## Frontend Architecture

```
frontend/src/
├── components/
│   ├── ui/            Button, Input, Select, Card, Spinner, ErrorState, EmptyState, Badge, ProgressBar
│   ├── layout/        Navbar, Sidebar, Topbar, Footer, Logo (student app)
│   └── admin/         AdminSidebar, AdminTopbar, Table, Modal, ConfirmDialog, AdminStatCard
├── layouts/           MainLayout (public), DashboardLayout (student), AdminLayout (admin)
├── pages/             One file per route; pages/admin/ for the admin panel
├── context/           AuthContext — holds the current user/token, hydrates from
│                      a stored JWT via GET /api/auth/me on load
├── hooks/             useAuth, usePronunciation (Web Speech API wrapper)
├── services/          One file per backend resource (authService, lessonService,
│                      quizService, adminService, etc.) — thin wrappers around
│                      a single shared axios instance (services/api.js)
└── utils/             apiError.js — extracts a clean message from any failed API call
```

**Route guards**: `ProtectedRoute` (must be logged in), `PublicOnlyRoute` (must be logged out — used on `/login`/`/register`), `AdminRoute` (must be logged in **and** `role === 'admin'`). These are a UX convenience only — every admin API call is independently protected by the backend's own `authenticate` + `requireAdmin` middleware, so bypassing the frontend guard could never expose real admin data or actions.

**State management**: React Context (`AuthContext`) for the current user; everything else is local component state fetched directly from the API on mount. No Redux/Zustand — unnecessary at this scale.

## Backend Architecture

```
backend/
├── config/db.js       MongoDB connection (fails fast — 5s timeout — instead
│                       of hanging silently if the database is unreachable)
├── models/            9 Mongoose schemas (see Database section below)
├── controllers/       Request handling + business logic
├── services/          Extracted logic used by controllers: tokenService (JWT),
│                       quizService (grading), gamificationService (XP/streak/
│                       achievements), progressService (dashboard aggregation)
├── middleware/         auth.js (authenticate/requireAdmin/optionalAuthenticate),
│                       validateRequest.js, validateObjectIdParam.js, errorHandler.js
├── routes/             One file per resource, mounted in server.js
├── seed/               Seed data (3 languages × 5 lessons × 10 words = 150
│                       vocabulary, 75 auto-generated quiz questions, 6 achievements)
└── tests/              41 tests: unit tests for quiz grading & gamification logic
                        (no DB needed), smoke tests for validation/auth gating
```

**Layering**: Routes → Controllers → Services → Models. Controllers stay thin; anything with real logic (grading, XP calculation, streak math, achievement rules) lives in `services/`.

## Database

9 MongoDB collections via Mongoose: `User`, `Language`, `Lesson`, `Vocabulary`, `Question`, `UserProgress` (per lesson), `UserVocabProgress` (per word, powers spaced revision), `Achievement`, `UserAchievement`. Lessons reference Vocabulary by ID (not embedded) so a word can be reused across lessons without duplication. Full schema details are in `backend/models/*.js` — each file is commented with its validation rules.

## Authentication

JWT-based. `POST /api/auth/register` and `/login` return a token; the frontend stores it in `localStorage` and attaches it via an axios request interceptor (`services/api.js`). `role` is `'student'` or `'admin'` (not `'user'`) — set directly in the database; there is no self-service way to become an admin, by design.

## API Overview

Base path: `/api`. Summary of every resource:

| Resource | Endpoints |
|---|---|
| Auth | `POST /auth/register`, `POST /auth/login`, `GET /auth/me` |
| Users | `GET /users/me`, `PUT /users/me` |
| Languages | `GET /languages`, `GET /languages/:id` |
| Lessons | `GET /lessons` (filters: languageId, level, category), `GET /lessons/:id` |
| Vocabulary | `GET /vocabulary` (filters: languageId, category, difficulty, search, page, limit), `GET /vocabulary/:id` |
| Quizzes | `GET /quizzes/:lessonId` (sanitized, no answers), `POST /quizzes/submit` (server-graded) |
| Progress | `GET /progress` (own), `GET /progress/:userId` (admin), `POST /progress` |
| Achievements | `GET /achievements` (catalog), `GET /achievements/me` (earned) |
| Admin | Full CRUD: `/admin/languages`, `/admin/lessons`, `/admin/vocabulary`, `/admin/questions`; read-only: `GET /admin/users`, `GET /admin/questions?lessonId=` |

**Security note**: `GET /quizzes/:lessonId` strips correct answers before sending to the client (see `services/quizService.js`'s `sanitizeQuestionForClient`). `POST /quizzes/submit` re-fetches the real questions and re-grades from scratch server-side — a client-submitted score is never trusted.

## Project Structure

```
project-root/
├── backend/     Express API (see Backend Architecture above)
├── frontend/    React/Vite app (see Frontend Architecture above)
├── .env.example Documents required environment variables
└── README.md    This file
```

## Installation

```bash
git clone <repo>
cd project-root
```

### Backend

```bash
cd backend
cp ../.env.example .env   # then fill in real values — see Environment Variables below
npm install
npm run seed               # populates languages/lessons/vocabulary/questions/achievements
npm run dev                 # API on http://localhost:5000
```

### Frontend

```bash
cd frontend
npm install
npm run dev                 # app on http://localhost:5173
```

## Development Commands

| Command | Where | What it does |
|---|---|---|
| `npm run dev` | backend | Starts the API with nodemon (auto-restart) |
| `npm run seed` | backend | Seeds languages/lessons/vocabulary/questions/achievements |
| `npm test` | backend | Runs all 41 tests (unit + smoke; no live DB required) |
| `npm run dev` | frontend | Starts the Vite dev server |
| `npm run build` | frontend | Production build to `frontend/dist/` |
| `npm run lint` | frontend | ESLint across the whole `src/` tree |

## Environment Variables

See `.env.example` at the project root.

| Variable | Where | Description |
|---|---|---|
| `MONGODB_URI` | backend | MongoDB connection string (local or Atlas) |
| `JWT_SECRET` | backend | Long random string used to sign auth tokens |
| `JWT_EXPIRES_IN` | backend | Token lifetime (default `7d`) |
| `CLIENT_URL` | backend | Frontend origin, for CORS (default `http://localhost:5173`) |
| `PORT` | backend | API port (default `5000`) |
| `VITE_API_URL` | frontend | Backend base URL (default `http://localhost:5000/api` — has a hardcoded fallback, so this is optional unless your backend runs somewhere else) |

## Seed Instructions

```bash
cd backend
npm run seed
```

This clears and repopulates only content collections (`Language`, `Vocabulary`, `Lesson`, `Question`, `Achievement`) — it never touches `User` accounts or their progress, so it's safe to re-run against a database with real registered users. To create an admin account, register normally through the app, then manually set that user's `role` field to `'admin'` in MongoDB (there is deliberately no API endpoint for self-promotion to admin).

## Known Limitations

- **Live MongoDB integration testing is still pending.** All backend logic has been validated two ways — (1) 41 automated tests covering grading logic, gamification math, and auth/validation gating, all of which run without a database, and (2) manual code review of every Mongoose query, `populate()` call, and field name against the actual schemas. But end-to-end runs against a real, populated MongoDB instance (register → login → take a quiz → see it reflected in progress, etc.) have **not** been performed in this environment, because no MongoDB instance is reachable from here. This is the top priority for the next phase.
- **No favorites toggle.** The `User` model has a `favorites` field and the original spec mentioned it, but no backend endpoint exists to toggle it. Rather than fake this in the UI, it was left unimplemented — the vocabulary page only shows a real, read-only "learned" indicator (derived from actual quiz completions).
- **Vocabulary images aren't rendered.** The `Vocabulary` model has an `image` field, but seed data never populates it and no UI renders it yet.
- **Admin visibility is limited to active content.** `GET /languages` and `GET /lessons` only return `isActive: true` records (by design, for the student-facing use of those same endpoints), so an admin can't currently see anything they've deactivated. Reasonable for now since nothing in the seed data or admin UI sets `isActive: false`.
- **Frontend `npm audit` shows a few moderate/high advisories** (esbuild dev-server-only issue, a react-router edge case) inherited from pinned dependency versions. Not addressed, since fixing them requires major version bumps (Vite 5→8, React Router 6→7) that would need re-validating the whole app.

## Future Improvements

- Live MongoDB integration pass (see above)
- Favorites toggle (would need one small new backend endpoint)
- Spaced-repetition revision mode using the existing `UserVocabProgress.reviewCount`/`lastReviewedAt` fields (schema already supports it; no UI yet)
- Rule-based conversation-practice module (mentioned in the original spec as an optional Module 5, not built)
- Admin ability to view/reactivate inactive languages and lessons
- Automated end-to-end tests against a real (or in-memory) MongoDB once that's available in the dev/CI environment
