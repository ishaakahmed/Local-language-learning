import { useCallback, useEffect, useMemo, useState } from 'react';
import { Search, Library } from 'lucide-react';
import VocabularyCard from '../components/VocabularyCard';
import Spinner from '../components/ui/Spinner';
import ErrorState from '../components/ui/ErrorState';
import EmptyState from '../components/ui/EmptyState';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { fetchVocabulary } from '../services/vocabularyService';
import { fetchLanguages } from '../services/languageService';
import useAuth from '../hooks/useAuth';
import { getApiErrorMessage } from '../utils/apiError';

const CATEGORIES = ['greetings', 'family', 'food', 'numbers', 'colors'];

export default function VocabularyPage() {
  const { user } = useAuth();
  const selectedLanguageId = user?.selectedLanguage?._id || user?.selectedLanguage || null;

  const [languages, setLanguages] = useState([]);
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1 });
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');

  // languageId -> speechLocale map, since GET /api/vocabulary doesn't populate languageId
  const languageMap = useMemo(() => {
    const map = {};
    for (const lang of languages) map[lang._id] = lang;
    return map;
  }, [languages]);

  useEffect(() => {
    fetchLanguages().then(setLanguages).catch(() => {});
  }, []);

  const load = useCallback(async () => {
    setStatus('loading');
    try {
      const params = { page, limit: 12 };
      if (selectedLanguageId) params.languageId = selectedLanguageId;
      if (category) params.category = category;
      if (search.trim()) params.search = search.trim();

      const data = await fetchVocabulary(params);
      setItems(data.vocabulary);
      setPagination(data.pagination);
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load vocabulary.'));
      setStatus('error');
    }
  }, [page, category, search, selectedLanguageId]);

  useEffect(() => {
    load();
  }, [load]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setPage(1);
    load();
  };

  const wordsLearned = useMemo(() => new Set((user?.wordsLearned || []).map(String)), [user]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Vocabulary</h1>
        <p className="text-text-muted mt-1">Browse, search, and review words you&rsquo;ve encountered.</p>
      </div>

      <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted" aria-hidden="true" />
          <Input
            id="vocab-search"
            placeholder="Search words, meanings, transliteration…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <select
          value={category}
          onChange={(e) => {
            setCategory(e.target.value);
            setPage(1);
          }}
          className="rounded-xl border border-black/10 px-4 py-2.5 text-sm text-text focus:outline-none focus:ring-2 focus:ring-primary/40"
        >
          <option value="">All categories</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c[0].toUpperCase() + c.slice(1)}
            </option>
          ))}
        </select>
        <Button type="submit">Search</Button>
      </form>

      {status === 'loading' && <Spinner className="py-16" label="Loading vocabulary…" />}

      {status === 'error' && <ErrorState message={errorMessage} onRetry={load} />}

      {status === 'ready' && items.length === 0 && (
        <EmptyState icon={Library} title="No words found" message="Try a different search term or category." />
      )}

      {status === 'ready' && items.length > 0 && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {items.map((vocab) => (
              <VocabularyCard
                key={vocab._id}
                vocab={vocab}
                speechLocale={languageMap[vocab.languageId]?.speechLocale}
                learned={wordsLearned.has(String(vocab._id))}
              />
            ))}
          </div>

          {pagination.totalPages > 1 && (
            <div className="flex items-center justify-center gap-3 pt-2">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <span className="text-sm text-text-muted">
                Page {pagination.page} of {pagination.totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= pagination.totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                Next
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
