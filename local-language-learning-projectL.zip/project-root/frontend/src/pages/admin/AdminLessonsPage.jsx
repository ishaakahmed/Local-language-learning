import { useCallback, useEffect, useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import Badge from '../../components/ui/Badge';
import Spinner from '../../components/ui/Spinner';
import ErrorState from '../../components/ui/ErrorState';
import Table from '../../components/admin/Table';
import Modal from '../../components/admin/Modal';
import ConfirmDialog from '../../components/admin/ConfirmDialog';
import { fetchLanguages } from '../../services/languageService';
import { fetchLessons } from '../../services/lessonService';
import { fetchVocabulary } from '../../services/vocabularyService';
import { createLesson, updateLesson, deleteLesson } from '../../services/adminService';
import { getApiErrorMessage } from '../../utils/apiError';

const LEVELS = ['beginner', 'intermediate', 'advanced'];
const EMPTY_FORM = { languageId: '', title: '', description: '', level: 'beginner', category: '', order: 1, vocabulary: [] };

function LessonForm({ initial, languages, onSubmit, onCancel, saving, submitError }) {
  const [form, setForm] = useState(
    initial
      ? {
          languageId: initial.languageId?._id || initial.languageId,
          title: initial.title,
          description: initial.description || '',
          level: initial.level,
          category: initial.category,
          order: initial.order,
          vocabulary: initial.vocabulary?.map((v) => v._id || v) || [],
        }
      : EMPTY_FORM
  );
  const [vocabOptions, setVocabOptions] = useState([]);
  const [loadingVocab, setLoadingVocab] = useState(false);

  useEffect(() => {
    if (!form.languageId) {
      setVocabOptions([]);
      return;
    }
    setLoadingVocab(true);
    fetchVocabulary({ languageId: form.languageId, limit: 100 })
      .then((data) => setVocabOptions(data.vocabulary))
      .catch(() => setVocabOptions([]))
      .finally(() => setLoadingVocab(false));
  }, [form.languageId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: name === 'order' ? Number(value) : value }));
  };

  const toggleVocab = (id) => {
    setForm((prev) => ({
      ...prev,
      vocabulary: prev.vocabulary.includes(id) ? prev.vocabulary.filter((v) => v !== id) : [...prev.vocabulary, id],
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Select id="languageId" name="languageId" label="Language" value={form.languageId} onChange={handleChange} required>
        <option value="">Select a language…</option>
        {languages.map((l) => (
          <option key={l._id} value={l._id}>
            {l.name}
          </option>
        ))}
      </Select>

      <Input id="title" name="title" label="Title" value={form.title} onChange={handleChange} required />

      <div className="grid grid-cols-2 gap-4">
        <Select id="level" name="level" label="Level" value={form.level} onChange={handleChange}>
          {LEVELS.map((l) => (
            <option key={l} value={l}>
              {l}
            </option>
          ))}
        </Select>
        <Input id="order" name="order" type="number" min={0} label="Order" value={form.order} onChange={handleChange} required />
      </div>

      <Input id="category" name="category" label="Category" value={form.category} onChange={handleChange} required />

      <div>
        <label htmlFor="description" className="block text-sm font-medium text-text mb-1.5">
          Description
        </label>
        <textarea
          id="description"
          name="description"
          value={form.description}
          onChange={handleChange}
          rows={2}
          className="w-full rounded-xl border border-black/10 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
        />
      </div>

      <div>
        <p className="block text-sm font-medium text-text mb-1.5">Vocabulary in this lesson</p>
        {!form.languageId ? (
          <p className="text-sm text-text-muted">Choose a language first.</p>
        ) : loadingVocab ? (
          <Spinner label="Loading vocabulary…" />
        ) : vocabOptions.length === 0 ? (
          <p className="text-sm text-text-muted">No vocabulary exists for this language yet.</p>
        ) : (
          <div className="max-h-40 overflow-y-auto border border-black/10 rounded-xl p-3 space-y-1.5">
            {vocabOptions.map((v) => (
              <label key={v._id} className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={form.vocabulary.includes(v._id)} onChange={() => toggleVocab(v._id)} />
                <span>
                  {v.word} <span className="text-text-muted">— {v.translation}</span>
                </span>
              </label>
            ))}
          </div>
        )}
      </div>

      {submitError && <p className="text-sm text-error">{submitError}</p>}

      <div className="flex gap-3 pt-2">
        <Button type="button" variant="ghost" fullWidth onClick={onCancel} disabled={saving}>
          Cancel
        </Button>
        <Button type="submit" fullWidth loading={saving}>
          Save
        </Button>
      </div>
    </form>
  );
}

export default function AdminLessonsPage() {
  const [languages, setLanguages] = useState([]);
  const [languageFilter, setLanguageFilter] = useState('');
  const [lessons, setLessons] = useState([]);
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');

  const [modalMode, setModalMode] = useState(null);
  const [editingLesson, setEditingLesson] = useState(null);
  const [saving, setSaving] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const loadLanguages = useCallback(async () => {
    const data = await fetchLanguages();
    setLanguages(data);
    return data;
  }, []);

  const loadLessons = useCallback(async () => {
    setStatus('loading');
    try {
      const params = languageFilter ? { languageId: languageFilter } : {};
      setLessons(await fetchLessons(params));
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load lessons.'));
      setStatus('error');
    }
  }, [languageFilter]);

  useEffect(() => {
    loadLanguages();
  }, [loadLanguages]);

  useEffect(() => {
    loadLessons();
  }, [loadLessons]);

  const openCreate = () => {
    setEditingLesson(null);
    setSubmitError('');
    setModalMode('create');
  };
  const openEdit = (lesson) => {
    setEditingLesson(lesson);
    setSubmitError('');
    setModalMode('edit');
  };
  const closeModal = () => setModalMode(null);

  const handleSubmit = async (form) => {
    setSaving(true);
    setSubmitError('');
    try {
      if (modalMode === 'edit') {
        await updateLesson(editingLesson._id, form);
      } else {
        await createLesson(form);
      }
      closeModal();
      await loadLessons();
    } catch (err) {
      setSubmitError(getApiErrorMessage(err, 'Could not save this lesson.'));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteLesson(deleteTarget._id);
      setDeleteTarget(null);
      await loadLessons();
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not delete this lesson.'));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-text">Lessons</h1>
          <p className="text-text-muted mt-1">Manage lessons and their vocabulary.</p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add lesson
        </Button>
      </div>

      <select
        value={languageFilter}
        onChange={(e) => setLanguageFilter(e.target.value)}
        className="rounded-xl border border-black/10 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
      >
        <option value="">All languages</option>
        {languages.map((l) => (
          <option key={l._id} value={l._id}>
            {l.name}
          </option>
        ))}
      </select>

      {status === 'loading' && <Spinner className="py-16" label="Loading lessons…" />}
      {status === 'error' && <ErrorState message={errorMessage} onRetry={loadLessons} />}

      {status === 'ready' && (
        <Card padded={false} className="p-4 sm:p-6">
          <Table
            columns={[
              { key: 'title', label: 'Title' },
              { key: 'language', label: 'Language', render: (row) => row.languageId?.name },
              { key: 'category', label: 'Category' },
              { key: 'level', label: 'Level', render: (row) => <Badge tone="muted">{row.level}</Badge> },
              { key: 'order', label: 'Order' },
              { key: 'vocabCount', label: 'Words', render: (row) => row.vocabulary?.length ?? 0 },
            ]}
            data={lessons}
            renderActions={(row) => (
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => openEdit(row)}
                  className="p-1.5 rounded-lg text-text-muted hover:bg-black/5 hover:text-primary"
                  aria-label={`Edit ${row.title}`}
                >
                  <Pencil className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setDeleteTarget(row)}
                  className="p-1.5 rounded-lg text-text-muted hover:bg-black/5 hover:text-error"
                  aria-label={`Delete ${row.title}`}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            )}
            emptyMessage="No lessons found."
          />
        </Card>
      )}

      <Modal open={Boolean(modalMode)} onClose={closeModal} title={modalMode === 'edit' ? 'Edit lesson' : 'Add lesson'}>
        <LessonForm
          initial={editingLesson}
          languages={languages}
          onSubmit={handleSubmit}
          onCancel={closeModal}
          saving={saving}
          submitError={submitError}
        />
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete lesson?"
        message={`This will permanently delete "${deleteTarget?.title}" and all of its quiz questions.`}
      />
    </div>
  );
}
