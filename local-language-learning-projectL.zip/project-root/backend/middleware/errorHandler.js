/**
 * Central error handler. Every error in the app (thrown ApiError, Mongoose
 * validation error, JWT error, or an unexpected bug) ends up here.
 * The client always gets a clean, safe JSON message — never a raw stack trace.
 */
const errorHandler = (err, req, res, next) => {
  let statusCode = err.statusCode || 500;
  let message = err.message || 'Internal server error';
  // Allows any handler (e.g. validateRequest) to attach field-level messages
  // via err.details, in addition to Mongoose's own ValidationError below.
  let details = err.details;

  // Mongoose validation error -> 400 with field-level messages
  if (err.name === 'ValidationError') {
    statusCode = 400;
    details = Object.values(err.errors).map((e) => e.message);
    message = 'Validation failed';
  }

  // Mongoose invalid ObjectId cast -> 400
  if (err.name === 'CastError') {
    statusCode = 400;
    message = `Invalid value for field "${err.path}"`;
  }

  // Mongoose duplicate key error (e.g. email already registered) -> 409
  if (err.code === 11000) {
    statusCode = 409;
    const field = Object.keys(err.keyValue || {})[0] || 'field';
    message = `A record with that ${field} already exists`;
  }

  // JWT errors -> 401
  if (err.name === 'JsonWebTokenError') {
    statusCode = 401;
    message = 'Invalid authentication token';
  }
  if (err.name === 'TokenExpiredError') {
    statusCode = 401;
    message = 'Authentication token has expired';
  }

  // Never leak internals for unexpected (non-operational) errors in production
  if (statusCode === 500 && process.env.NODE_ENV === 'production') {
    message = 'Something went wrong. Please try again later.';
  }

  if (statusCode === 500) {
    // Always log the real error server-side for debugging
    console.error('Unhandled error:', err);
  }

  res.status(statusCode).json({
    success: false,
    message,
    ...(details ? { details } : {}),
    ...(process.env.NODE_ENV !== 'production' && statusCode === 500
      ? { stack: err.stack }
      : {}),
  });
};

module.exports = errorHandler;
