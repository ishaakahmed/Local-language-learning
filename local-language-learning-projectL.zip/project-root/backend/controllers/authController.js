const { User } = require('../models');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const { generateToken } = require('../services/tokenService');

// POST /api/auth/register
const register = asyncHandler(async (req, res) => {
  const { name, email, password, selectedLanguage } = req.body;

  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) {
    throw new ApiError(409, 'An account with that email already exists.');
  }

  const user = await User.create({
    name,
    email,
    password, // hashed by the User model's pre('save') hook
    selectedLanguage: selectedLanguage || null,
  });

  const token = generateToken(user);

  res.status(201).json({
    success: true,
    data: { user, token },
  });
});

// POST /api/auth/login
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // password has `select: false` in the schema — must explicitly request it here
  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user) {
    throw new ApiError(401, 'Invalid email or password.');
  }

  const isMatch = await user.comparePassword(password);
  if (!isMatch) {
    throw new ApiError(401, 'Invalid email or password.');
  }

  const token = generateToken(user);

  res.status(200).json({
    success: true,
    data: { user, token }, // user.toJSON() strips the password automatically
  });
});

// GET /api/auth/me
const getMe = asyncHandler(async (req, res) => {
  res.status(200).json({ success: true, data: { user: req.user } });
});

module.exports = { register, login, getMe };
