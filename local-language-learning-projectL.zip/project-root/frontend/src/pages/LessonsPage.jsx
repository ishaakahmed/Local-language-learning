import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen } from 'lucide-react';
import LessonCard from '../components/LessonCard';
import Spinner from '../components/ui/Spinner';
import ErrorState from '../components/ui/ErrorState';
import EmptyState from '../components/ui/EmptyState';
import Button from '../components/ui/Button';
import { fetchLessons } from '../services/lessonService';
import { fetchMyProgress } from '../services/progressService';
import useAuth from '../hooks/useAuth';
import { getApiErrorMessage } from '../utils/apiError';

export default function LessonsPage() {
  const { user } = useAuth();
  const selectedLanguageId = user?.selectedLanguage?._id || user?.selectedLanguage || null;

  const [lessons, setLessons] = useState([]);
  const [progressByLessonId, setProgressByLessonId] = useState({});
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');

  const load = useCallback(async () => {
    if (!selectedLanguageId) {
      setStatus('no-language');
      return;
    }
    setStatus('loading');
    try {
      const [lessonList, progressData] = await Promise.all([
        fetchLessons({ languageId: selectedLanguageId }),
        fetchMyProgress(),
      ]);
      setLessons(lessonList);

      const map = {};
      for (const p of progressData.lessons) {
        const id = p.lessonId?._id || p.lessonId;
        if (id) map[id] = p;
      }
      setProgressByLessonId(map);
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load lessons.'));
      setStatus('error');
    }
  }, [selectedLanguageId]);

  useEffect(() => {
    load();
  }, [load]);

  const languageName = lessons[0]?.languageId?.name;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Lessons{languageName ? ` · ${languageName}` : ''}</h1>
        <p className="text-text-muted mt-1">Work through each lesson in order to build your vocabulary.</p>
      </div>

      {status === 'loading' && <Spinner className="py-16" label="Loading lessons…" />}

      {status === 'error' && <ErrorState message={errorMessage} onRetry={load} />}

      {status === 'no-language' && (
        <EmptyState
          icon={BookOpen}
          title="Choose a language first"
          message="Pick a language to see its lessons."
          action={
            <Link to="/languages">
              <Button>Choose a language</Button>
            </Link>
          }
        />
      )}

      {status === 'ready' && lessons.length === 0 && (
        <EmptyState icon={BookOpen} title="No lessons yet" message="Lessons for this language haven't been added yet." />
      )}

      {status === 'ready' && lessons.length > 0 && (
        <div className="space-y-3">
          {lessons.map((lesson) => (
            <LessonCard key={lesson._id} lesson={lesson} progress={progressByLessonId[lesson._id]} />
          ))}
        </div>
      )}
    </div>
  );
}
