import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Languages as LanguagesIcon } from 'lucide-react';
import LanguageCard from '../components/LanguageCard';
import Spinner from '../components/ui/Spinner';
import ErrorState from '../components/ui/ErrorState';
import EmptyState from '../components/ui/EmptyState';
import Button from '../components/ui/Button';
import { fetchLanguages } from '../services/languageService';
import { updateProfile } from '../services/userService';
import useAuth from '../hooks/useAuth';
import { getApiErrorMessage } from '../utils/apiError';

export default function LanguageSelectionPage() {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();

  const [languages, setLanguages] = useState([]);
  const [status, setStatus] = useState('loading'); // loading | error | ready
  const [errorMessage, setErrorMessage] = useState('');
  const [selectedId, setSelectedId] = useState(user?.selectedLanguage?._id || user?.selectedLanguage || null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');

  const loadLanguages = useCallback(async () => {
    setStatus('loading');
    try {
      const data = await fetchLanguages();
      setLanguages(data);
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load languages.'));
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    loadLanguages();
  }, [loadLanguages]);

  const handleSelect = async (language) => {
    setSelectedId(language._id);
    setSaveError('');
    setSaving(true);
    try {
      const updatedUser = await updateProfile({ selectedLanguage: language._id });
      updateUser(updatedUser);
      navigate('/dashboard');
    } catch (err) {
      setSaveError(getApiErrorMessage(err, 'Could not save your language choice. Please try again.'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-extrabold text-text">Choose a language to learn</h1>
        <p className="text-text-muted mt-2">You can change this anytime from your profile.</p>
      </div>

      {status === 'loading' && <Spinner className="py-16" label="Loading languages…" />}

      {status === 'error' && <ErrorState message={errorMessage} onRetry={loadLanguages} />}

      {status === 'ready' && languages.length === 0 && (
        <EmptyState
          icon={LanguagesIcon}
          title="No languages available yet"
          message="Languages haven't been added to the platform yet. Please check back soon."
          action={
            <Button variant="outline" onClick={loadLanguages}>
              Refresh
            </Button>
          }
        />
      )}

      {status === 'ready' && languages.length > 0 && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {languages.map((language) => (
              <LanguageCard
                key={language._id}
                language={language}
                selected={selectedId === language._id}
                onSelect={handleSelect}
              />
            ))}
          </div>
          {saving && <Spinner className="mt-6" label="Saving your choice…" />}
          {saveError && (
            <p role="alert" className="mt-6 text-center text-sm text-error">
              {saveError}
            </p>
          )}
        </>
      )}
    </div>
  );
}
