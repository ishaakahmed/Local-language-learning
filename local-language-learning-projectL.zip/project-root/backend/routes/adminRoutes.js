const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { authenticate, requireAdmin } = require('../middleware/auth');
const validateObjectIdParam = require('../middleware/validateObjectIdParam');
const validateRequest = require('../middleware/validateRequest');
const { VALID_CATEGORIES } = require('../models/Vocabulary');
const { QUESTION_TYPES } = require('../models/Question');

const languageController = require('../controllers/languageController');
const lessonController = require('../controllers/lessonController');
const vocabularyController = require('../controllers/vocabularyController');
const questionController = require('../controllers/questionController');
const userController = require('../controllers/userController');

// Every route below requires a logged-in admin.
router.use(authenticate, requireAdmin);

// --- Languages ---
router.post(
  '/languages',
  [
    body('name').trim().notEmpty().withMessage('name is required'),
    body('nativeName').trim().notEmpty().withMessage('nativeName is required'),
    body('code').trim().notEmpty().withMessage('code is required'),
    body('script').trim().notEmpty().withMessage('script is required'),
    body('speechLocale').trim().notEmpty().withMessage('speechLocale is required'),
  ],
  validateRequest,
  languageController.createLanguage
);
router.put('/languages/:id', validateObjectIdParam('id'), languageController.updateLanguage);
router.delete('/languages/:id', validateObjectIdParam('id'), languageController.deleteLanguage);

// --- Lessons ---
router.post(
  '/lessons',
  [
    body('languageId').isMongoId().withMessage('languageId must be a valid id'),
    body('title').trim().notEmpty().withMessage('title is required'),
    body('category').trim().notEmpty().withMessage('category is required'),
    body('order').isInt({ min: 0 }).withMessage('order must be a non-negative integer'),
  ],
  validateRequest,
  lessonController.createLesson
);
router.put('/lessons/:id', validateObjectIdParam('id'), lessonController.updateLesson);
router.delete('/lessons/:id', validateObjectIdParam('id'), lessonController.deleteLesson);

// --- Vocabulary ---
router.post(
  '/vocabulary',
  [
    body('languageId').isMongoId().withMessage('languageId must be a valid id'),
    body('word').trim().notEmpty().withMessage('word is required'),
    body('translation').trim().notEmpty().withMessage('translation is required'),
    body('transliteration').trim().notEmpty().withMessage('transliteration is required'),
    body('category').isIn(VALID_CATEGORIES).withMessage(`category must be one of: ${VALID_CATEGORIES.join(', ')}`),
  ],
  validateRequest,
  vocabularyController.createVocabulary
);
router.put('/vocabulary/:id', validateObjectIdParam('id'), vocabularyController.updateVocabulary);
router.delete('/vocabulary/:id', validateObjectIdParam('id'), vocabularyController.deleteVocabulary);

// --- Questions ---
router.get('/questions', questionController.getQuestionsForAdmin);
router.post(
  '/questions',
  [
    body('lessonId').isMongoId().withMessage('lessonId must be a valid id'),
    body('type').isIn(QUESTION_TYPES).withMessage(`type must be one of: ${QUESTION_TYPES.join(', ')}`),
    body('prompt').trim().notEmpty().withMessage('prompt is required'),
    body('payload').isObject().withMessage('payload is required and must be an object'),
  ],
  validateRequest,
  questionController.createQuestion
);
router.put('/questions/:id', validateObjectIdParam('id'), questionController.updateQuestion);
router.delete('/questions/:id', validateObjectIdParam('id'), questionController.deleteQuestion);

// --- Users (read-only overview) ---
router.get('/users', userController.getAllUsersForAdmin);

module.exports = router;
