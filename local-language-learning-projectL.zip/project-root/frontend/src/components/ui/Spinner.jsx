import { Loader2 } from 'lucide-react';

export default function Spinner({ size = 24, className = '', label = 'Loading…' }) {
  return (
    <div className={['flex flex-col items-center justify-center gap-2 text-text-muted', className].join(' ')} role="status">
      <Loader2 style={{ width: size, height: size }} className="animate-spin text-primary" aria-hidden="true" />
      {label && <span className="text-sm">{label}</span>}
    </div>
  );
}
