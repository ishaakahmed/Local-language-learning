import { useState } from 'react';
import { X } from 'lucide-react';
import PronounceButton from './PronounceButton';

function ChoiceQuestion({ question, value, onChange, speechLocale }) {
  const isListen = question.type === 'listenSelect';
  return (
    <div>
      {isListen && (
        <div className="flex justify-center mb-4">
          <PronounceButton text={question.prompt} locale={speechLocale} />
        </div>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {question.payload.options.map((option) => {
          const selected = value === option;
          return (
            <button
              key={option}
              type="button"
              onClick={() => onChange(option)}
              className={[
                'text-left rounded-xl border-2 px-4 py-3 text-sm font-medium transition-colors',
                selected ? 'border-primary bg-primary/5 text-primary' : 'border-black/10 hover:border-primary/40',
              ].join(' ')}
            >
              {option}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function FillBlankQuestion({ question, value, onChange }) {
  const parts = question.payload.sentence.split('___');
  return (
    <div className="text-lg leading-relaxed text-text">
      {parts[0]}
      <input
        type="text"
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder="type answer"
        className="inline-block mx-2 w-40 border-b-2 border-primary bg-transparent px-2 py-1 text-center font-semibold text-primary focus:outline-none"
      />
      {parts[1]}
    </div>
  );
}

function ReorderQuestion({ question, value, onChange }) {
  const chosen = value || [];
  const remaining = question.payload.words.filter((_, idx) => {
    const countChosen = chosen.filter((w) => w === question.payload.words[idx]).length;
    const occurrenceIndex = question.payload.words.slice(0, idx + 1).filter((w) => w === question.payload.words[idx]).length;
    return occurrenceIndex > countChosen;
  });

  return (
    <div>
      <div className="min-h-[3rem] flex flex-wrap gap-2 border-2 border-dashed border-black/10 rounded-xl p-3 mb-4">
        {chosen.length === 0 && <span className="text-sm text-text-muted">Tap words below in order…</span>}
        {chosen.map((word, i) => (
          <button
            key={`${word}-${i}`}
            type="button"
            onClick={() => onChange(chosen.filter((_, idx) => idx !== i))}
            className="inline-flex items-center gap-1 rounded-lg bg-primary text-white px-3 py-1.5 text-sm font-medium"
          >
            {word}
            <X className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        {remaining.map((word, i) => (
          <button
            key={`${word}-${i}`}
            type="button"
            onClick={() => onChange([...chosen, word])}
            className="rounded-lg border border-black/10 px-3 py-1.5 text-sm font-medium hover:border-primary/40"
          >
            {word}
          </button>
        ))}
      </div>
    </div>
  );
}

function MatchQuestion({ question, value, onChange }) {
  const pairs = value || [];
  const [activeLeft, setActiveLeft] = useState(null);

  const rightForLeft = (left) => pairs.find((p) => p.left === left)?.right;
  const usedRights = new Set(pairs.map((p) => p.right));

  const handleLeftClick = (left) => setActiveLeft(left === activeLeft ? null : left);

  const handleRightClick = (right) => {
    if (!activeLeft) return;
    const next = pairs.filter((p) => p.left !== activeLeft && p.right !== right);
    next.push({ left: activeLeft, right });
    onChange(next);
    setActiveLeft(null);
  };

  return (
    <div className="grid grid-cols-2 gap-6">
      <div className="space-y-2">
        {question.payload.lefts.map((left) => {
          const matched = rightForLeft(left);
          return (
            <button
              key={left}
              type="button"
              onClick={() => handleLeftClick(left)}
              className={[
                'w-full text-left rounded-xl border-2 px-3 py-2.5 text-sm font-medium transition-colors',
                activeLeft === left
                  ? 'border-primary bg-primary/5'
                  : matched
                  ? 'border-success/50 bg-success/5'
                  : 'border-black/10 hover:border-primary/40',
              ].join(' ')}
            >
              {left}
              {matched && <span className="block text-xs text-success mt-0.5">→ {matched}</span>}
            </button>
          );
        })}
      </div>
      <div className="space-y-2">
        {question.payload.rights.map((right) => (
          <button
            key={right}
            type="button"
            disabled={!activeLeft && !usedRights.has(right)}
            onClick={() => handleRightClick(right)}
            className={[
              'w-full text-left rounded-xl border-2 px-3 py-2.5 text-sm font-medium transition-colors',
              usedRights.has(right) ? 'border-success/50 bg-success/5' : 'border-black/10 hover:border-primary/40',
              !activeLeft && !usedRights.has(right) ? 'opacity-50 cursor-not-allowed' : '',
            ].join(' ')}
          >
            {right}
          </button>
        ))}
      </div>
    </div>
  );
}

/**
 * `value` shape by type (mirrors backend/services/quizService.js gradeSingleAnswer):
 *  mcq/translate/listenSelect/imageSelect -> string
 *  fillBlank -> string
 *  reorder -> string[]
 *  match -> Array<{ left, right }>
 */
export default function QuizQuestionRenderer({ question, value, onChange, speechLocale }) {
  switch (question.type) {
    case 'mcq':
    case 'translate':
    case 'listenSelect':
    case 'imageSelect':
      return <ChoiceQuestion question={question} value={value} onChange={onChange} speechLocale={speechLocale} />;
    case 'fillBlank':
      return <FillBlankQuestion question={question} value={value} onChange={onChange} />;
    case 'reorder':
      return <ReorderQuestion question={question} value={value} onChange={onChange} />;
    case 'match':
      return <MatchQuestion question={question} value={value} onChange={onChange} />;
    default:
      return <p className="text-text-muted text-sm">Unsupported question type.</p>;
  }
}
