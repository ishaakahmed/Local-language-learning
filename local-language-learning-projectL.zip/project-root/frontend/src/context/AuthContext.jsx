import { createContext, useCallback, useEffect, useState } from 'react';
import { registerUser, loginUser, fetchCurrentUser } from '../services/authService';

export const AuthContext = createContext(null);

const TOKEN_KEY = 'token';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem(TOKEN_KEY));
  // `initializing` covers the one-time startup check (validate any stored
  // token against GET /api/auth/me) — separate from `authLoading`, which
  // covers in-flight login/register form submissions.
  const [initializing, setInitializing] = useState(true);
  const [authLoading, setAuthLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function hydrate() {
      if (!token) {
        setInitializing(false);
        return;
      }
      try {
        const freshUser = await fetchCurrentUser();
        if (!cancelled) setUser(freshUser);
      } catch (err) {
        // Stored token is invalid/expired — clear it rather than leave the
        // app thinking it's authenticated when the backend disagrees.
        if (!cancelled) {
          localStorage.removeItem(TOKEN_KEY);
          setToken(null);
          setUser(null);
        }
      } finally {
        if (!cancelled) setInitializing(false);
      }
    }

    hydrate();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // only ever run once on app load, intentionally

  const login = useCallback(async (credentials) => {
    setAuthLoading(true);
    try {
      const { user: loggedInUser, token: newToken } = await loginUser(credentials);
      localStorage.setItem(TOKEN_KEY, newToken);
      setToken(newToken);
      setUser(loggedInUser);
      return loggedInUser;
    } finally {
      setAuthLoading(false);
    }
  }, []);

  const register = useCallback(async (payload) => {
    setAuthLoading(true);
    try {
      const { user: newUser, token: newToken } = await registerUser(payload);
      localStorage.setItem(TOKEN_KEY, newToken);
      setToken(newToken);
      setUser(newUser);
      return newUser;
    } finally {
      setAuthLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    setToken(null);
    setUser(null);
  }, []);

  // Lets a page (e.g. language selection, future profile edits) update the
  // locally-held user after a successful PUT /api/users/me, without a refetch.
  const updateUser = useCallback((partial) => {
    setUser((prev) => (prev ? { ...prev, ...partial } : prev));
  }, []);

  const value = {
    user,
    token,
    isAuthenticated: Boolean(token && user),
    initializing,
    authLoading,
    login,
    register,
    logout,
    updateUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
