const express = require('express');
const router = express.Router();

const { getLanguages, getLanguageById } = require('../controllers/languageController');
const validateObjectIdParam = require('../middleware/validateObjectIdParam');

router.get('/', getLanguages);
router.get('/:id', validateObjectIdParam('id'), getLanguageById);

module.exports = router;
