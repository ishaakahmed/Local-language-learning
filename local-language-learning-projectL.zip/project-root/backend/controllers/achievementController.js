const { Achievement, UserAchievement } = require('../models');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/achievements — public catalog of all possible badges
const getAllAchievements = asyncHandler(async (req, res) => {
  const achievements = await Achievement.find({}).sort({ 'requirement.value': 1 });
  res.status(200).json({ success: true, data: { achievements } });
});

// GET /api/achievements/me — badges the authenticated user has actually earned
const getMyAchievements = asyncHandler(async (req, res) => {
  const earned = await UserAchievement.find({ userId: req.user._id })
    .populate('achievementId')
    .sort({ earnedAt: -1 });

  res.status(200).json({ success: true, data: { achievements: earned } });
});

module.exports = { getAllAchievements, getMyAchievements };
