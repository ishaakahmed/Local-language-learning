const mongoose = require('mongoose');

const QUESTION_TYPES = [
  'mcq', // multiple choice
  'match', // match the word (pairs)
  'translate', // select the correct translation
  'fillBlank', // fill in the blank
  'reorder', // arrange words in correct order
  'listenSelect', // listen and select
  'imageSelect', // image-based vocabulary question
];

const questionSchema = new mongoose.Schema(
  {
    lessonId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Lesson',
      required: [true, 'lessonId is required'],
      index: true,
    },
    type: {
      type: String,
      required: [true, 'Question type is required'],
      enum: {
        values: QUESTION_TYPES,
        message: 'Type must be one of: ' + QUESTION_TYPES.join(', '),
      },
    },
    prompt: {
      type: String,
      required: [true, 'Question prompt is required'],
      trim: true,
    },
    // Shape of `payload` depends on `type`:
    //  mcq / translate / listenSelect / imageSelect:
    //     { options: [String], correctAnswer: String }
    //  match:
    //     { pairs: [{ left: String, right: String }] }
    //  fillBlank:
    //     { sentence: String (contains "___"), correctAnswer: String }
    //  reorder:
    //     { words: [String], correctOrder: [String] }
    payload: {
      type: mongoose.Schema.Types.Mixed,
      required: [true, 'Question payload is required'],
    },
    explanation: {
      type: String,
      trim: true,
    },
    difficulty: {
      type: String,
      enum: ['easy', 'medium', 'hard'],
      default: 'easy',
    },
  },
  { timestamps: true }
);

/**
 * Validates that the payload contains the fields required for its declared type.
 * This keeps question data trustworthy without needing a separate schema per type.
 */
questionSchema.pre('validate', function validatePayloadShape(next) {
  const p = this.payload || {};
  const fail = (msg) => next(new Error(msg));

  switch (this.type) {
    case 'mcq':
    case 'translate':
    case 'listenSelect':
    case 'imageSelect':
      if (!Array.isArray(p.options) || p.options.length < 2) {
        return fail(`"${this.type}" questions require at least 2 options`);
      }
      if (!p.correctAnswer || !p.options.includes(p.correctAnswer)) {
        return fail(`"${this.type}" questions require a correctAnswer that is one of the options`);
      }
      break;

    case 'match':
      if (!Array.isArray(p.pairs) || p.pairs.length < 2) {
        return fail('"match" questions require at least 2 pairs');
      }
      for (const pair of p.pairs) {
        if (!pair.left || !pair.right) {
          return fail('Each match pair requires both "left" and "right" values');
        }
      }
      break;

    case 'fillBlank':
      if (!p.sentence || !p.sentence.includes('___')) {
        return fail('"fillBlank" questions require a sentence containing "___"');
      }
      if (!p.correctAnswer) {
        return fail('"fillBlank" questions require a correctAnswer');
      }
      break;

    case 'reorder':
      if (!Array.isArray(p.words) || p.words.length < 2) {
        return fail('"reorder" questions require at least 2 words');
      }
      if (!Array.isArray(p.correctOrder) || p.correctOrder.length !== p.words.length) {
        return fail('"reorder" questions require a correctOrder matching the word count');
      }
      break;

    default:
      return fail(`Unknown question type: ${this.type}`);
  }

  next();
});

module.exports = mongoose.model('Question', questionSchema);
module.exports.QUESTION_TYPES = QUESTION_TYPES;
