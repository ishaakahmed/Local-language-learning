import { NavLink, Link } from 'react-router-dom';
import { LayoutDashboard, Languages, BookOpen, Library, ClipboardList, Users, ArrowLeftCircle } from 'lucide-react';

const NAV_ITEMS = [
  { label: 'Overview', to: '/admin', icon: LayoutDashboard, end: true },
  { label: 'Languages', to: '/admin/languages', icon: Languages },
  { label: 'Lessons', to: '/admin/lessons', icon: BookOpen },
  { label: 'Vocabulary', to: '/admin/vocabulary', icon: Library },
  { label: 'Quizzes', to: '/admin/quizzes', icon: ClipboardList },
  { label: 'Users', to: '/admin/users', icon: Users },
];

export default function AdminSidebar() {
  return (
    <aside className="hidden md:flex md:flex-col md:w-64 md:shrink-0 bg-text text-white min-h-screen sticky top-0">
      <div className="h-16 flex items-center px-5 border-b border-white/10">
        <span className="font-extrabold tracking-tight">
          Bhasha<span className="text-secondary">Setu</span>
          <span className="ml-2 text-xs font-semibold text-white/60 uppercase tracking-wide">Admin</span>
        </span>
      </div>
      <nav className="flex flex-col gap-1 px-3 py-4 flex-1">
        {NAV_ITEMS.map(({ label, to, icon: Icon, end }) => (
          <NavLink
            key={label}
            to={to}
            end={end}
            className={({ isActive }) =>
              [
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors',
                isActive ? 'bg-white/10 text-white' : 'text-white/70 hover:bg-white/5 hover:text-white',
              ].join(' ')
            }
          >
            <Icon className="h-5 w-5" aria-hidden="true" />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="p-3 border-t border-white/10">
        <Link
          to="/dashboard"
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-white/70 hover:bg-white/5 hover:text-white transition-colors"
        >
          <ArrowLeftCircle className="h-5 w-5" aria-hidden="true" />
          Back to app
        </Link>
      </div>
    </aside>
  );
}

export { NAV_ITEMS };
