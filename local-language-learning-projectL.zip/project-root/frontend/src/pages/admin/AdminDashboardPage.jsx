import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Languages, BookOpen, Library, Users, Award, ArrowRight } from 'lucide-react';
import Card from '../../components/ui/Card';
import Spinner from '../../components/ui/Spinner';
import ErrorState from '../../components/ui/ErrorState';
import AdminStatCard from '../../components/admin/AdminStatCard';
import { fetchLanguages } from '../../services/languageService';
import { fetchLessons } from '../../services/lessonService';
import { fetchVocabulary } from '../../services/vocabularyService';
import { fetchAllAchievements } from '../../services/achievementService';
import { fetchUsersForAdmin } from '../../services/adminService';
import { getApiErrorMessage } from '../../utils/apiError';

const QUICK_LINKS = [
  { label: 'Manage Languages', to: '/admin/languages', icon: Languages },
  { label: 'Manage Lessons', to: '/admin/lessons', icon: BookOpen },
  { label: 'Manage Vocabulary', to: '/admin/vocabulary', icon: Library },
  { label: 'Manage Quizzes', to: '/admin/quizzes', icon: BookOpen },
];

export default function AdminDashboardPage() {
  const [stats, setStats] = useState(null);
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');

  const load = useCallback(async () => {
    setStatus('loading');
    try {
      const [languages, lessons, vocab, achievements, users] = await Promise.all([
        fetchLanguages(),
        fetchLessons(),
        fetchVocabulary({ limit: 1 }), // only need pagination.total
        fetchAllAchievements(),
        fetchUsersForAdmin({ limit: 1 }),
      ]);
      setStats({
        languages: languages.length,
        lessons: lessons.length,
        vocabulary: vocab.pagination.total,
        achievements: achievements.length,
        users: users.pagination.total,
      });
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load admin overview.'));
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (status === 'loading') return <Spinner className="py-16" label="Loading overview…" />;
  if (status === 'error') return <ErrorState message={errorMessage} onRetry={load} />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Admin Overview</h1>
        <p className="text-text-muted mt-1">A snapshot of everything on the platform.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <AdminStatCard icon={Languages} label="Languages" value={stats.languages} />
        <AdminStatCard icon={BookOpen} label="Lessons" value={stats.lessons} />
        <AdminStatCard icon={Library} label="Vocabulary" value={stats.vocabulary} />
        <AdminStatCard icon={Award} label="Achievements" value={stats.achievements} />
        <AdminStatCard icon={Users} label="Users" value={stats.users} />
      </div>

      <div>
        <h2 className="font-semibold text-text mb-3">Quick actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {QUICK_LINKS.map(({ label, to, icon: Icon }) => (
            <Link key={label} to={to}>
              <Card className="flex items-center justify-between hover:shadow-md hover:-translate-y-0.5 transition-all">
                <span className="flex items-center gap-3 font-medium text-text">
                  <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                  {label}
                </span>
                <ArrowRight className="h-4 w-4 text-text-muted" aria-hidden="true" />
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
