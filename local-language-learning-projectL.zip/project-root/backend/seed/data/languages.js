// Adding a 4th language later means adding one more object here (plus its
// vocabulary/lesson/question data file) — no application code changes needed.
module.exports = [
  {
    name: 'Marathi',
    nativeName: 'मराठी',
    code: 'mr',
    description: 'Marathi is spoken primarily in Maharashtra and is one of the classical languages of India, written in the Devanagari script.',
    script: 'Devanagari',
    speechLocale: 'mr-IN',
    icon: 'म',
    isActive: true,
  },
  {
    name: 'Hindi',
    nativeName: 'हिन्दी',
    code: 'hi',
    description: 'Hindi is one of the official languages of India, widely spoken across North India and written in the Devanagari script.',
    script: 'Devanagari',
    speechLocale: 'hi-IN',
    icon: 'हि',
    isActive: true,
  },
  {
    name: 'Gujarati',
    nativeName: 'ગુજરાતી',
    code: 'gu',
    description: 'Gujarati is the primary language of Gujarat state, written in its own script derived from Devanagari.',
    script: 'Gujarati',
    speechLocale: 'gu-IN',
    icon: 'ગુ',
    isActive: true,
  },
];
