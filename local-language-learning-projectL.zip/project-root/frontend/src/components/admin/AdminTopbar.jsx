import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { NavLink, Link } from 'react-router-dom';
import { NAV_ITEMS } from './AdminSidebar';
import useAuth from '../../hooks/useAuth';

export default function AdminTopbar() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-20 bg-surface/90 backdrop-blur border-b border-black/5">
      <div className="h-16 px-4 sm:px-6 flex items-center justify-between gap-4">
        <button
          type="button"
          className="md:hidden p-2 -ml-2 text-text"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? 'Close admin menu' : 'Open admin menu'}
          aria-expanded={open}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
        <span className="md:hidden font-extrabold text-text">
          Bhasha<span className="text-primary">Setu</span> <span className="text-xs text-text-muted">Admin</span>
        </span>
        <div className="ml-auto text-sm text-text-muted">
          Signed in as <span className="font-medium text-text">{user?.name}</span>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-black/5 bg-surface py-3 px-3 flex flex-col gap-1">
          {NAV_ITEMS.map(({ label, to, icon: Icon, end }) => (
            <NavLink
              key={label}
              to={to}
              end={end}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                [
                  'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors',
                  isActive ? 'bg-primary/10 text-primary' : 'text-text hover:bg-black/5',
                ].join(' ')
              }
            >
              <Icon className="h-5 w-5" aria-hidden="true" />
              {label}
            </NavLink>
          ))}
          <Link
            to="/dashboard"
            onClick={() => setOpen(false)}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-text-muted hover:bg-black/5"
          >
            Back to app
          </Link>
        </div>
      )}
    </header>
  );
}
