import { Link } from 'react-router-dom';
import { Languages } from 'lucide-react';

export default function Logo({ className = '' }) {
  return (
    <Link to="/" className={['inline-flex items-center gap-2 font-extrabold text-text', className].join(' ')}>
      <span className="h-9 w-9 rounded-xl bg-primary text-white flex items-center justify-center">
        <Languages className="h-5 w-5" aria-hidden="true" />
      </span>
      <span className="text-lg tracking-tight">
        Bhasha<span className="text-primary">Setu</span>
      </span>
    </Link>
  );
}
