import { AlertTriangle } from 'lucide-react';
import Button from './Button';

export default function ErrorState({
  title = 'Something went wrong',
  message = "We couldn't load this right now. Please try again.",
  onRetry,
  className = '',
}) {
  return (
    <div className={['flex flex-col items-center justify-center text-center py-12 px-4', className].join(' ')}>
      <div className="h-12 w-12 rounded-full bg-error/10 flex items-center justify-center mb-4">
        <AlertTriangle className="h-6 w-6 text-error" aria-hidden="true" />
      </div>
      <h3 className="text-lg font-semibold text-text mb-1">{title}</h3>
      <p className="text-sm text-text-muted max-w-sm mb-4">{message}</p>
      {onRetry && (
        <Button variant="outline" size="sm" onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  );
}
