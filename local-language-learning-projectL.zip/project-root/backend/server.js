require('dotenv').config();

const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const mongoose = require('mongoose');
const connectDB = require('./config/db');
const notFound = require('./middleware/notFound');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// --- Core middleware ---
app.use(
  cors({
    origin: process.env.CLIENT_URL || 'http://localhost:5173',
    credentials: true,
  })
);
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev'));
}

// --- Health check (useful for confirming the server + DB are alive) ---
app.get('/api/health', (req, res) => {
  const dbStates = ['disconnected', 'connected', 'connecting', 'disconnecting'];
  res.status(200).json({
    success: true,
    message: 'API is running',
    database: dbStates[mongoose.connection.readyState] || 'unknown',
  });
});

// --- Feature routes (Phase 3) ---
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/users', require('./routes/userRoutes'));
app.use('/api/languages', require('./routes/languageRoutes'));
app.use('/api/lessons', require('./routes/lessonRoutes'));
app.use('/api/vocabulary', require('./routes/vocabularyRoutes'));
app.use('/api/quizzes', require('./routes/quizRoutes'));
app.use('/api/progress', require('./routes/progressRoutes'));
app.use('/api/achievements', require('./routes/achievementRoutes'));
app.use('/api/admin', require('./routes/adminRoutes'));

// --- 404 + central error handler (must be registered last) ---
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
  });
};

// Only auto-connect-and-listen when this file is run directly (`node server.js`
// or `npm run dev`). When it's `require()`d instead — e.g. by a test file that
// wants the Express `app` for supertest — nothing starts automatically, so
// tests can run without needing a live MongoDB connection just to import the app.
if (require.main === module) {
  startServer();
}

module.exports = app;
