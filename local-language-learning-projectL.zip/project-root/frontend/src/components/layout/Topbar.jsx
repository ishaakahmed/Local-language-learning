import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu, X, Flame, Star, LogOut } from 'lucide-react';
import Badge from '../ui/Badge';
import Logo from './Logo';
import { SidebarLinks } from './Sidebar';
import useAuth from '../../hooks/useAuth';

export default function Topbar() {
  const { user, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-20 bg-surface/90 backdrop-blur border-b border-black/5">
      <div className="h-16 px-4 sm:px-6 flex items-center justify-between gap-4">
        <button
          type="button"
          className="md:hidden p-2 -ml-2 text-text"
          onClick={() => setMobileOpen((v) => !v)}
          aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={mobileOpen}
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>

        <div className="md:hidden">
          <Logo />
        </div>

        <div className="ml-auto flex items-center gap-2 sm:gap-3">
          <Badge tone="secondary" icon={Flame}>
            {user?.streak ?? 0} day streak
          </Badge>
          <Badge tone="primary" icon={Star}>
            {user?.xp ?? 0} XP
          </Badge>
          <button
            type="button"
            onClick={handleLogout}
            className="p-2 rounded-xl text-text-muted hover:bg-black/5 hover:text-text transition-colors"
            aria-label="Log out"
            title="Log out"
          >
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Mobile off-canvas nav */}
      {mobileOpen && (
        <div className="md:hidden border-t border-black/5 bg-surface py-3">
          <SidebarLinks onNavigate={() => setMobileOpen(false)} />
        </div>
      )}
    </header>
  );
}
