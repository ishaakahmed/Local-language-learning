require('dotenv').config();
const mongoose = require('mongoose');

const { Language, Vocabulary, Lesson, Question, Achievement } = require('../models');
const languageDefs = require('./data/languages');
const achievementDefs = require('./data/achievements');
const languageContent = {
  mr: require('./data/marathi'),
  hi: require('./data/hindi'),
  gu: require('./data/gujarati'),
};
const { generateQuestionsForLesson } = require('./helpers/generateQuestions');

const summary = {
  languages: 0,
  lessons: 0,
  vocabulary: 0,
  questions: 0,
  achievements: 0,
};

async function clearContentCollections() {
  // Only content collections are wiped — User accounts and their progress
  // are intentionally left untouched so re-running the seed never deletes
  // real registered users.
  await Promise.all([
    Language.deleteMany({}),
    Vocabulary.deleteMany({}),
    Lesson.deleteMany({}),
    Question.deleteMany({}),
    Achievement.deleteMany({}),
  ]);
  console.log('Cleared existing content collections (Language, Vocabulary, Lesson, Question, Achievement).');
}

async function seedLanguage(languageDef) {
  const language = await Language.create(languageDef);
  summary.languages += 1;

  const content = languageContent[language.code];
  if (!content) {
    throw new Error(`No seed content file found for language code "${language.code}"`);
  }

  for (const lessonDef of content.lessons) {
    // 1. Insert vocabulary for this lesson first (lesson needs their IDs)
    const vocabDocs = await Vocabulary.insertMany(
      lessonDef.vocabulary.map((v) => ({ ...v, languageId: language._id }))
    );
    summary.vocabulary += vocabDocs.length;

    // 2. Insert the lesson, referencing the vocabulary just created
    const lesson = await Lesson.create({
      languageId: language._id,
      title: lessonDef.title,
      description: lessonDef.description,
      level: lessonDef.level,
      category: lessonDef.category,
      order: lessonDef.order,
      vocabulary: vocabDocs.map((v) => v._id),
      isActive: true,
    });
    summary.lessons += 1;

    // 3. Generate and insert questions for this lesson, derived from its vocabulary
    const plainVocab = vocabDocs.map((v) => v.toObject());
    const generatedQuestions = generateQuestionsForLesson(plainVocab);
    const questionDocs = await Question.insertMany(
      generatedQuestions.map((q) => ({ ...q, lessonId: lesson._id }))
    );
    summary.questions += questionDocs.length;

    console.log(
      `  [${language.name}] Lesson "${lesson.title}" — ${vocabDocs.length} words, ${questionDocs.length} questions`
    );
  }
}

async function seedAchievements() {
  const docs = await Achievement.insertMany(achievementDefs);
  summary.achievements = docs.length;
}

async function run() {
  try {
    await mongoose.connect(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 5000 });
    console.log(`Connected to MongoDB: ${mongoose.connection.name}\n`);

    await clearContentCollections();

    console.log('\nSeeding languages, lessons, vocabulary, and questions...');
    for (const languageDef of languageDefs) {
      await seedLanguage(languageDef);
    }

    console.log('\nSeeding achievements...');
    await seedAchievements();

    console.log('\n--- Seed complete ---');
    console.log(`Languages:   ${summary.languages}`);
    console.log(`Lessons:     ${summary.lessons}`);
    console.log(`Vocabulary:  ${summary.vocabulary}`);
    console.log(`Questions:   ${summary.questions}`);
    console.log(`Achievements: ${summary.achievements}`);

    process.exit(0);
  } catch (error) {
    console.error('\nSeed script failed:', error.message);
    console.error(error);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
  }
}

run();
