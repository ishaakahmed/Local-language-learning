export default function Footer() {
  return (
    <footer className="border-t border-black/5 bg-surface">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-text-muted">
        <p>© {new Date().getFullYear()} BhashaSetu. An academic project for local language learning.</p>
        <p>Built to help you connect with your language and culture.</p>
      </div>
    </footer>
  );
}
