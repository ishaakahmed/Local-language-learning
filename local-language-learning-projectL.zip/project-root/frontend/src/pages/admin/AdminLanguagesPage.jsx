import { useCallback, useEffect, useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Badge from '../../components/ui/Badge';
import Spinner from '../../components/ui/Spinner';
import ErrorState from '../../components/ui/ErrorState';
import Table from '../../components/admin/Table';
import Modal from '../../components/admin/Modal';
import ConfirmDialog from '../../components/admin/ConfirmDialog';
import { fetchLanguages } from '../../services/languageService';
import { createLanguage, updateLanguage, deleteLanguage } from '../../services/adminService';
import { getApiErrorMessage } from '../../utils/apiError';

const EMPTY_FORM = { name: '', nativeName: '', code: '', script: '', speechLocale: '', description: '', icon: '' };

function LanguageForm({ initial, onSubmit, onCancel, saving, submitError }) {
  const [form, setForm] = useState(initial || EMPTY_FORM);

  const handleChange = (e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input id="name" name="name" label="Name" value={form.name} onChange={handleChange} required />
      <Input id="nativeName" name="nativeName" label="Native name" value={form.nativeName} onChange={handleChange} required />
      <div className="grid grid-cols-2 gap-4">
        <Input id="code" name="code" label="Code (e.g. mr)" value={form.code} onChange={handleChange} required />
        <Input id="script" name="script" label="Script" value={form.script} onChange={handleChange} required />
      </div>
      <Input
        id="speechLocale"
        name="speechLocale"
        label="Speech locale (e.g. mr-IN)"
        value={form.speechLocale}
        onChange={handleChange}
        required
      />
      <Input id="icon" name="icon" label="Icon (short text, optional)" value={form.icon} onChange={handleChange} />
      <div>
        <label htmlFor="description" className="block text-sm font-medium text-text mb-1.5">
          Description
        </label>
        <textarea
          id="description"
          name="description"
          value={form.description}
          onChange={handleChange}
          rows={3}
          className="w-full rounded-xl border border-black/10 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
        />
      </div>

      {submitError && <p className="text-sm text-error">{submitError}</p>}

      <div className="flex gap-3 pt-2">
        <Button type="button" variant="ghost" fullWidth onClick={onCancel} disabled={saving}>
          Cancel
        </Button>
        <Button type="submit" fullWidth loading={saving}>
          Save
        </Button>
      </div>
    </form>
  );
}

export default function AdminLanguagesPage() {
  const [languages, setLanguages] = useState([]);
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');

  const [modalMode, setModalMode] = useState(null); // 'create' | 'edit' | null
  const [editingLanguage, setEditingLanguage] = useState(null);
  const [saving, setSaving] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    setStatus('loading');
    try {
      setLanguages(await fetchLanguages());
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load languages.'));
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openCreate = () => {
    setEditingLanguage(null);
    setSubmitError('');
    setModalMode('create');
  };
  const openEdit = (lang) => {
    setEditingLanguage(lang);
    setSubmitError('');
    setModalMode('edit');
  };
  const closeModal = () => setModalMode(null);

  const handleSubmit = async (form) => {
    setSaving(true);
    setSubmitError('');
    try {
      if (modalMode === 'edit') {
        await updateLanguage(editingLanguage._id, form);
      } else {
        await createLanguage(form);
      }
      closeModal();
      await load();
    } catch (err) {
      setSubmitError(getApiErrorMessage(err, 'Could not save this language.'));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteLanguage(deleteTarget._id);
      setDeleteTarget(null);
      await load();
    } catch (err) {
      // Backend returns 409 with lesson/vocab counts if content still references it
      setErrorMessage(getApiErrorMessage(err, 'Could not delete this language.'));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-text">Languages</h1>
          <p className="text-text-muted mt-1">Manage the languages available on the platform.</p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add language
        </Button>
      </div>

      {status === 'loading' && <Spinner className="py-16" label="Loading languages…" />}
      {status === 'error' && <ErrorState message={errorMessage} onRetry={load} />}

      {status === 'ready' && (
        <Card padded={false} className="p-4 sm:p-6">
          <Table
            columns={[
              { key: 'name', label: 'Name' },
              { key: 'nativeName', label: 'Native name' },
              { key: 'code', label: 'Code' },
              { key: 'script', label: 'Script' },
              {
                key: 'isActive',
                label: 'Status',
                render: (row) => <Badge tone={row.isActive ? 'success' : 'muted'}>{row.isActive ? 'Active' : 'Inactive'}</Badge>,
              },
            ]}
            data={languages}
            renderActions={(row) => (
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => openEdit(row)}
                  className="p-1.5 rounded-lg text-text-muted hover:bg-black/5 hover:text-primary"
                  aria-label={`Edit ${row.name}`}
                >
                  <Pencil className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setDeleteTarget(row)}
                  className="p-1.5 rounded-lg text-text-muted hover:bg-black/5 hover:text-error"
                  aria-label={`Delete ${row.name}`}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            )}
            emptyMessage="No languages yet. Add one to get started."
          />
        </Card>
      )}

      <Modal open={Boolean(modalMode)} onClose={closeModal} title={modalMode === 'edit' ? 'Edit language' : 'Add language'}>
        <LanguageForm
          initial={editingLanguage}
          onSubmit={handleSubmit}
          onCancel={closeModal}
          saving={saving}
          submitError={submitError}
        />
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete language?"
        message={`This will permanently delete "${deleteTarget?.name}". If lessons or vocabulary still reference it, the deletion will be blocked.`}
      />
    </div>
  );
}
