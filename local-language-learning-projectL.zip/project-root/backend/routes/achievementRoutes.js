const express = require('express');
const router = express.Router();

const { getAllAchievements, getMyAchievements } = require('../controllers/achievementController');
const { authenticate } = require('../middleware/auth');

router.get('/', getAllAchievements);
router.get('/me', authenticate, getMyAchievements);

module.exports = router;
