import api from './api';

// GET /api/vocabulary?languageId=&category=&difficulty=&search=&page=&limit=
export async function fetchVocabulary(params = {}) {
  const res = await api.get('/vocabulary', { params });
  return res.data.data; // { vocabulary, pagination }
}

export async function fetchVocabularyById(id) {
  const res = await api.get(`/vocabulary/${id}`);
  return res.data.data.vocabulary;
}
