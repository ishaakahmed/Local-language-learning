import Card from './ui/Card';

export default function AchievementBadge({ achievement, earned = false, earnedAt }) {
  return (
    <Card className={['text-center', earned ? '' : 'opacity-50 grayscale'].join(' ')}>
      <div className="text-4xl mb-2">{achievement.icon}</div>
      <h3 className="font-semibold text-text text-sm">{achievement.name}</h3>
      <p className="text-xs text-text-muted mt-1">{achievement.description}</p>
      {earned && earnedAt && (
        <p className="text-xs text-success mt-2 font-medium">
          Earned {new Date(earnedAt).toLocaleDateString()}
        </p>
      )}
      {!earned && <p className="text-xs text-text-muted mt-2">Locked</p>}
    </Card>
  );
}
