import { Link } from 'react-router-dom';
import { CheckCircle2, ChevronRight } from 'lucide-react';
import Card from './ui/Card';
import Badge from './ui/Badge';

const LEVEL_TONE = { beginner: 'success', intermediate: 'secondary', advanced: 'primary' };

export default function LessonCard({ lesson, progress }) {
  const completed = Boolean(progress?.completed);

  return (
    <Link to={`/lessons/${lesson._id}`}>
      <Card className="hover:shadow-md hover:-translate-y-0.5 transition-all flex items-center justify-between gap-4">
        <div className="flex items-center gap-4 min-w-0">
          <div
            className={[
              'h-11 w-11 shrink-0 rounded-xl flex items-center justify-center font-bold',
              completed ? 'bg-success/10 text-success' : 'bg-primary/10 text-primary',
            ].join(' ')}
          >
            {completed ? <CheckCircle2 className="h-6 w-6" aria-hidden="true" /> : lesson.order}
          </div>
          <div className="min-w-0">
            <h3 className="font-semibold text-text truncate">{lesson.title}</h3>
            {lesson.description && <p className="text-sm text-text-muted truncate">{lesson.description}</p>}
            <div className="flex items-center gap-2 mt-1.5">
              <Badge tone={LEVEL_TONE[lesson.level] || 'muted'}>{lesson.level}</Badge>
              {completed && (
                <Badge tone="success" icon={CheckCircle2}>
                  Completed{typeof progress.accuracy === 'number' ? ` · ${progress.accuracy}%` : ''}
                </Badge>
              )}
            </div>
          </div>
        </div>
        <ChevronRight className="h-5 w-5 text-text-muted shrink-0" aria-hidden="true" />
      </Card>
    </Link>
  );
}
