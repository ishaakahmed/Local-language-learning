const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { getQuizForLesson, submitQuiz } = require('../controllers/quizController');
const { optionalAuthenticate } = require('../middleware/auth');
const validateObjectIdParam = require('../middleware/validateObjectIdParam');
const validateRequest = require('../middleware/validateRequest');

router.get('/:lessonId', validateObjectIdParam('lessonId'), getQuizForLesson);

router.post(
  '/submit',
  [
    body('lessonId').isMongoId().withMessage('lessonId must be a valid id'),
    body('answers').isArray({ min: 1 }).withMessage('answers must be a non-empty array'),
    body('answers.*.questionId').isMongoId().withMessage('Each answer needs a valid questionId'),
  ],
  validateRequest,
  optionalAuthenticate,
  submitQuiz
);

module.exports = router;
