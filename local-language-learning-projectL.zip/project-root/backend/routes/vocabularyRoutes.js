const express = require('express');
const { query } = require('express-validator');
const router = express.Router();

const { getVocabulary, getVocabularyById } = require('../controllers/vocabularyController');
const validateObjectIdParam = require('../middleware/validateObjectIdParam');
const validateRequest = require('../middleware/validateRequest');

router.get(
  '/',
  [
    query('languageId').optional().isMongoId().withMessage('languageId must be a valid id'),
    query('difficulty').optional().isIn(['easy', 'medium', 'hard']).withMessage('Invalid difficulty'),
    query('page').optional().isInt({ min: 1 }).withMessage('page must be a positive integer'),
    query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('limit must be 1-100'),
  ],
  validateRequest,
  getVocabulary
);

router.get('/:id', validateObjectIdParam('id'), getVocabularyById);

module.exports = router;
