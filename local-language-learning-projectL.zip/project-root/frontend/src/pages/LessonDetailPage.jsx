import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, CheckCircle2, ClipboardCheck } from 'lucide-react';
import Spinner from '../components/ui/Spinner';
import ErrorState from '../components/ui/ErrorState';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import VocabularyCard from '../components/VocabularyCard';
import { fetchLessonById, fetchLessons } from '../services/lessonService';
import { fetchMyProgress, markLessonProgress } from '../services/progressService';
import { getApiErrorMessage } from '../utils/apiError';

export default function LessonDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [lesson, setLesson] = useState(null);
  const [siblingLessons, setSiblingLessons] = useState([]);
  const [completed, setCompleted] = useState(false);
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');
  const [marking, setMarking] = useState(false);
  const [markError, setMarkError] = useState('');

  const load = useCallback(async () => {
    setStatus('loading');
    try {
      const lessonData = await fetchLessonById(id);
      setLesson(lessonData);

      const [siblings, progressData] = await Promise.all([
        fetchLessons({ languageId: lessonData.languageId._id }),
        fetchMyProgress(),
      ]);
      setSiblingLessons(siblings);

      const thisProgress = progressData.lessons.find((p) => (p.lessonId?._id || p.lessonId) === lessonData._id);
      setCompleted(Boolean(thisProgress?.completed));

      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load this lesson.'));
      setStatus('error');
    }
  }, [id]);

  useEffect(() => {
    load();
    window.scrollTo(0, 0);
  }, [load]);

  const handleMarkComplete = async () => {
    setMarking(true);
    setMarkError('');
    try {
      await markLessonProgress({ lessonId: id, completed: true });
      setCompleted(true);
    } catch (err) {
      setMarkError(getApiErrorMessage(err, 'Could not save your progress.'));
    } finally {
      setMarking(false);
    }
  };

  if (status === 'loading') return <Spinner className="py-16" label="Loading lesson…" />;
  if (status === 'error') return <ErrorState message={errorMessage} onRetry={load} />;
  if (!lesson) return null;

  const currentIndex = siblingLessons.findIndex((l) => l._id === lesson._id);
  const prevLesson = currentIndex > 0 ? siblingLessons[currentIndex - 1] : null;
  const nextLesson = currentIndex >= 0 && currentIndex < siblingLessons.length - 1 ? siblingLessons[currentIndex + 1] : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <p className="text-sm text-text-muted">{lesson.languageId?.name}</p>
          <h1 className="text-2xl font-bold text-text">{lesson.title}</h1>
          {lesson.description && <p className="text-text-muted mt-1">{lesson.description}</p>}
        </div>
        {completed && (
          <Badge tone="success" icon={CheckCircle2}>
            Lesson completed
          </Badge>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {lesson.vocabulary.map((vocab) => (
          <VocabularyCard key={vocab._id} vocab={vocab} speechLocale={lesson.languageId?.speechLocale} />
        ))}
      </div>

      {markError && <p className="text-sm text-error">{markError}</p>}

      <Card className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {!completed ? (
            <Button variant="outline" onClick={handleMarkComplete} loading={marking}>
              <CheckCircle2 className="h-4 w-4" /> Mark lesson as read
            </Button>
          ) : (
            <span className="text-sm text-success font-medium flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4" /> You&rsquo;ve marked this lesson as read
            </span>
          )}
        </div>
        <Link to={`/quiz/${lesson._id}`}>
          <Button>
            <ClipboardCheck className="h-4 w-4" /> Take the quiz
          </Button>
        </Link>
      </Card>

      <div className="flex items-center justify-between pt-2">
        <Button
          variant="ghost"
          disabled={!prevLesson}
          onClick={() => prevLesson && navigate(`/lessons/${prevLesson._id}`)}
        >
          <ArrowLeft className="h-4 w-4" /> {prevLesson ? prevLesson.title : 'No previous lesson'}
        </Button>
        <Button
          variant="ghost"
          disabled={!nextLesson}
          onClick={() => nextLesson && navigate(`/lessons/${nextLesson._id}`)}
        >
          {nextLesson ? nextLesson.title : 'No next lesson'} <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
