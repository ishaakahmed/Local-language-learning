const mongoose = require('mongoose');

const lessonSchema = new mongoose.Schema(
  {
    languageId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Language',
      required: [true, 'languageId is required'],
      index: true,
    },
    title: {
      type: String,
      required: [true, 'Lesson title is required'],
      trim: true,
    },
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description cannot exceed 500 characters'],
    },
    level: {
      type: String,
      enum: ['beginner', 'intermediate', 'advanced'],
      default: 'beginner',
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      trim: true,
    },
    order: {
      type: Number,
      required: [true, 'Lesson order is required'],
      min: 0,
    },
    // References, not embedded documents — a word can be reused across lessons
    // without duplicating its data (see Vocabulary model).
    vocabulary: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Vocabulary',
      },
    ],
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

lessonSchema.index({ languageId: 1, order: 1 });

module.exports = mongoose.model('Lesson', lessonSchema);
