const { Question, Lesson } = require('../models');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');

// GET /api/admin/questions?lessonId=... (admin-only — includes correct answers,
// unlike GET /api/quizzes/:lessonId which is sanitized for students)
const getQuestionsForAdmin = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.lessonId) filter.lessonId = req.query.lessonId;

  const questions = await Question.find(filter).sort({ createdAt: 1 });
  res.status(200).json({ success: true, data: { questions } });
});

// POST /api/admin/questions
const createQuestion = asyncHandler(async (req, res) => {
  const lesson = await Lesson.findById(req.body.lessonId);
  if (!lesson) throw new ApiError(400, 'lessonId does not reference an existing lesson.');

  // Question.js's own pre('validate') hook checks the payload shape matches `type`
  const question = await Question.create(req.body);
  res.status(201).json({ success: true, data: { question } });
});

// PUT /api/admin/questions/:id
const updateQuestion = asyncHandler(async (req, res) => {
  const existing = await Question.findById(req.params.id);
  if (!existing) throw new ApiError(404, 'Question not found.');

  Object.assign(existing, req.body);
  await existing.save(); // .save() (not findByIdAndUpdate) so the pre('validate') payload-shape hook actually runs

  res.status(200).json({ success: true, data: { question: existing } });
});

// DELETE /api/admin/questions/:id
const deleteQuestion = asyncHandler(async (req, res) => {
  const question = await Question.findByIdAndDelete(req.params.id);
  if (!question) throw new ApiError(404, 'Question not found.');
  res.status(200).json({ success: true, data: {} });
});

module.exports = { getQuestionsForAdmin, createQuestion, updateQuestion, deleteQuestion };
