import api from './api';

// GET /api/languages -> { success, data: { languages: [...] } }
export async function fetchLanguages() {
  const res = await api.get('/languages');
  return res.data.data.languages;
}

export async function fetchLanguageById(id) {
  const res = await api.get(`/languages/${id}`);
  return res.data.data.language;
}
