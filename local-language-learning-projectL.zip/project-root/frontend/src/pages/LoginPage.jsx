import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import Logo from '../components/layout/Logo';
import useAuth from '../hooks/useAuth';
import { getApiErrorMessage } from '../utils/apiError';

export default function LoginPage() {
  const { login, authLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [form, setForm] = useState({ email: '', password: '' });
  const [formError, setFormError] = useState('');

  const redirectTo = location.state?.from?.pathname || '/dashboard';

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!form.email || !form.password) {
      setFormError('Please enter both your email and password.');
      return;
    }

    try {
      await login(form);
      navigate(redirectTo, { replace: true });
    } catch (err) {
      setFormError(getApiErrorMessage(err, 'Invalid email or password.'));
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-8">
          <Logo />
        </div>
        <Card>
          <h1 className="text-xl font-bold text-text mb-1">Welcome back</h1>
          <p className="text-sm text-text-muted mb-6">Log in to continue your learning streak.</p>

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <Input
              id="email"
              name="email"
              type="email"
              label="Email"
              autoComplete="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={handleChange}
            />
            <Input
              id="password"
              name="password"
              type="password"
              label="Password"
              autoComplete="current-password"
              placeholder="••••••••"
              value={form.password}
              onChange={handleChange}
            />

            {formError && (
              <p role="alert" className="text-sm text-error bg-error/5 border border-error/20 rounded-xl px-3 py-2">
                {formError}
              </p>
            )}

            <Button type="submit" fullWidth loading={authLoading}>
              Log in
            </Button>
          </form>

          <p className="mt-6 text-sm text-text-muted text-center">
            Don&apos;t have an account?{' '}
            <Link to="/register" className="text-primary font-semibold hover:underline">
              Sign up
            </Link>
          </p>
        </Card>
      </div>
    </div>
  );
}
