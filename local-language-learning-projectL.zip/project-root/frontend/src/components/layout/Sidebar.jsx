import { NavLink, Link } from 'react-router-dom';
import { LayoutDashboard, BookOpen, Library, TrendingUp, Award, ShieldCheck } from 'lucide-react';
import Logo from './Logo';
import useAuth from '../../hooks/useAuth';

const NAV_ITEMS = [
  { label: 'Dashboard', to: '/dashboard', icon: LayoutDashboard, enabled: true },
  { label: 'Lessons', to: '/lessons', icon: BookOpen, enabled: true },
  { label: 'Vocabulary', to: '/vocabulary', icon: Library, enabled: true },
  { label: 'Progress', to: '/progress', icon: TrendingUp, enabled: true },
  { label: 'Achievements', to: '/achievements', icon: Award, enabled: true },
];

function SidebarLinks({ onNavigate }) {
  const { user } = useAuth();
  return (
    <nav className="flex flex-col gap-1 px-3">
      {NAV_ITEMS.map(({ label, to, icon: Icon }) => (
        <NavLink
          key={label}
          to={to}
          onClick={onNavigate}
          className={({ isActive }) =>
            [
              'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors',
              isActive ? 'bg-primary/10 text-primary' : 'text-text hover:bg-black/5',
            ].join(' ')
          }
        >
          <Icon className="h-5 w-5" aria-hidden="true" />
          {label}
        </NavLink>
      ))}

      {user?.role === 'admin' && (
        <Link
          to="/admin"
          onClick={onNavigate}
          className="flex items-center gap-3 px-3 py-2.5 mt-2 rounded-xl text-sm font-medium text-secondary-dark bg-secondary/10 hover:bg-secondary/20 transition-colors"
        >
          <ShieldCheck className="h-5 w-5" aria-hidden="true" />
          Admin Panel
        </Link>
      )}
    </nav>
  );
}

export default function Sidebar() {
  return (
    <aside className="hidden md:flex md:flex-col md:w-64 md:shrink-0 border-r border-black/5 bg-surface min-h-screen sticky top-0">
      <div className="h-16 flex items-center px-5 border-b border-black/5">
        <Logo />
      </div>
      <div className="py-4 flex-1">
        <SidebarLinks />
      </div>
    </aside>
  );
}

export { SidebarLinks, NAV_ITEMS };
