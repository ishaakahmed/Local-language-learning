import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';
import Button from '../components/ui/Button';

export default function NotFoundPage() {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center text-center px-4">
      <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-6">
        <Compass className="h-8 w-8 text-primary" aria-hidden="true" />
      </div>
      <h1 className="text-3xl font-extrabold text-text">Page not found</h1>
      <p className="text-text-muted mt-2 max-w-sm">
        The page you&rsquo;re looking for doesn&apos;t exist or may have been moved.
      </p>
      <Link to="/" className="mt-6">
        <Button>Back to home</Button>
      </Link>
    </div>
  );
}
