import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import Logo from '../components/layout/Logo';
import useAuth from '../hooks/useAuth';
import { getApiErrorMessage } from '../utils/apiError';

const EMAIL_RE = /^\S+@\S+\.\S+$/;

function validate(form) {
  const errors = {};
  if (form.name.trim().length < 2) errors.name = 'Name must be at least 2 characters.';
  if (!EMAIL_RE.test(form.email)) errors.email = 'Please enter a valid email address.';
  if (form.password.length < 6) errors.password = 'Password must be at least 6 characters.';
  if (form.confirmPassword !== form.password) errors.confirmPassword = 'Passwords do not match.';
  return errors;
}

export default function RegisterPage() {
  const { register, authLoading } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [fieldErrors, setFieldErrors] = useState({});
  const [formError, setFormError] = useState('');

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError('');

    const errors = validate(form);
    setFieldErrors(errors);
    if (Object.keys(errors).length > 0) return;

    try {
      await register({ name: form.name.trim(), email: form.email.trim(), password: form.password });
      // New accounts have no selectedLanguage yet — send them to pick one.
      navigate('/languages', { replace: true });
    } catch (err) {
      setFormError(getApiErrorMessage(err, 'Could not create your account. Please try again.'));
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-8">
          <Logo />
        </div>
        <Card>
          <h1 className="text-xl font-bold text-text mb-1">Create your account</h1>
          <p className="text-sm text-text-muted mb-6">Start learning a language rooted in your culture.</p>

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <Input
              id="name"
              name="name"
              label="Full name"
              autoComplete="name"
              placeholder="Asha Patil"
              value={form.name}
              onChange={handleChange}
              error={fieldErrors.name}
            />
            <Input
              id="email"
              name="email"
              type="email"
              label="Email"
              autoComplete="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={handleChange}
              error={fieldErrors.email}
            />
            <Input
              id="password"
              name="password"
              type="password"
              label="Password"
              autoComplete="new-password"
              placeholder="At least 6 characters"
              value={form.password}
              onChange={handleChange}
              error={fieldErrors.password}
            />
            <Input
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              label="Confirm password"
              autoComplete="new-password"
              placeholder="Re-enter your password"
              value={form.confirmPassword}
              onChange={handleChange}
              error={fieldErrors.confirmPassword}
            />

            {formError && (
              <p role="alert" className="text-sm text-error bg-error/5 border border-error/20 rounded-xl px-3 py-2">
                {formError}
              </p>
            )}

            <Button type="submit" fullWidth loading={authLoading}>
              Create account
            </Button>
          </form>

          <p className="mt-6 text-sm text-text-muted text-center">
            Already have an account?{' '}
            <Link to="/login" className="text-primary font-semibold hover:underline">
              Log in
            </Link>
          </p>
        </Card>
      </div>
    </div>
  );
}
