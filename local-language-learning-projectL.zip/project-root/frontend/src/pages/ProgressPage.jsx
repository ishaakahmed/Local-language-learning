import { useCallback, useEffect, useState } from 'react';
import { Star, Award, Flame, Target, TrendingUp, CheckCircle2, Circle } from 'lucide-react';
import Card from '../components/ui/Card';
import ProgressBar from '../components/ui/ProgressBar';
import Spinner from '../components/ui/Spinner';
import ErrorState from '../components/ui/ErrorState';
import EmptyState from '../components/ui/EmptyState';
import { fetchMyProgress } from '../services/progressService';
import { fetchLessons as fetchLessonsForLanguage } from '../services/lessonService';
import useAuth from '../hooks/useAuth';
import { getApiErrorMessage } from '../utils/apiError';

export default function ProgressPage() {
  const { user } = useAuth();
  const selectedLanguageId = user?.selectedLanguage?._id || user?.selectedLanguage || null;

  const [data, setData] = useState(null);
  const [totalLessons, setTotalLessons] = useState(null);
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');

  const load = useCallback(async () => {
    setStatus('loading');
    try {
      const progress = await fetchMyProgress();
      setData(progress);

      if (selectedLanguageId) {
        const lessons = await fetchLessonsForLanguage({ languageId: selectedLanguageId });
        setTotalLessons(lessons.length);
      }
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load your progress.'));
      setStatus('error');
    }
  }, [selectedLanguageId]);

  useEffect(() => {
    load();
  }, [load]);

  if (status === 'loading') return <Spinner className="py-16" label="Loading your progress…" />;
  if (status === 'error') return <ErrorState message={errorMessage} onRetry={load} />;
  if (!data) return null;

  const { summary, lessons } = data;
  const completionPct = totalLessons ? Math.round((summary.lessonsCompletedCount / totalLessons) * 100) : null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Your Progress</h1>
        <p className="text-text-muted mt-1">A full picture of how far you&rsquo;ve come.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="text-center">
          <Star className="h-5 w-5 text-primary mx-auto mb-2" aria-hidden="true" />
          <p className="text-2xl font-bold text-text">{summary.xp}</p>
          <p className="text-xs text-text-muted mt-1">Total XP</p>
        </Card>
        <Card className="text-center">
          <Award className="h-5 w-5 text-primary mx-auto mb-2" aria-hidden="true" />
          <p className="text-2xl font-bold text-text">{summary.level}</p>
          <p className="text-xs text-text-muted mt-1">Level</p>
        </Card>
        <Card className="text-center">
          <Flame className="h-5 w-5 text-secondary mx-auto mb-2" aria-hidden="true" />
          <p className="text-2xl font-bold text-text">{summary.streak}</p>
          <p className="text-xs text-text-muted mt-1">Day streak</p>
        </Card>
        <Card className="text-center">
          <Target className="h-5 w-5 text-primary mx-auto mb-2" aria-hidden="true" />
          <p className="text-2xl font-bold text-text">{summary.wordsLearnedCount}</p>
          <p className="text-xs text-text-muted mt-1">Words learned</p>
        </Card>
      </div>

      {completionPct !== null && (
        <Card>
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-semibold text-text flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" aria-hidden="true" /> Course completion
            </h2>
            <span className="text-sm font-medium text-text-muted">
              {summary.lessonsCompletedCount} / {totalLessons} lessons
            </span>
          </div>
          <ProgressBar value={summary.lessonsCompletedCount} max={totalLessons} />
          <p className="text-xs text-text-muted mt-2">{completionPct}% complete</p>
        </Card>
      )}

      <div>
        <h2 className="font-semibold text-text mb-3">Lesson history</h2>
        {lessons.length === 0 ? (
          <EmptyState title="No lessons attempted yet" message="Complete a lesson or quiz to see your history here." />
        ) : (
          <div className="space-y-2">
            {lessons.map((p) => (
              <Card key={p._id} className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  {p.completed ? (
                    <CheckCircle2 className="h-5 w-5 text-success shrink-0" aria-hidden="true" />
                  ) : (
                    <Circle className="h-5 w-5 text-text-muted shrink-0" aria-hidden="true" />
                  )}
                  <div className="min-w-0">
                    <p className="font-medium text-text truncate">{p.lessonId?.title || 'Lesson'}</p>
                    <p className="text-xs text-text-muted">
                      {p.completedAt ? new Date(p.completedAt).toLocaleDateString() : 'Not completed yet'}
                    </p>
                  </div>
                </div>
                {typeof p.accuracy === 'number' && (
                  <span className="text-sm font-semibold text-text shrink-0">{p.accuracy}%</span>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
