const { Vocabulary, Language, Lesson } = require('../models');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');

// GET /api/vocabulary?languageId=&category=&difficulty=&search=&page=&limit=
const getVocabulary = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.languageId) filter.languageId = req.query.languageId;
  if (req.query.category) filter.category = req.query.category;
  if (req.query.difficulty) filter.difficulty = req.query.difficulty;
  if (req.query.search) {
    const regex = new RegExp(req.query.search.trim(), 'i');
    filter.$or = [{ word: regex }, { translation: regex }, { transliteration: regex }];
  }

  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
  const skip = (page - 1) * limit;

  const [items, total] = await Promise.all([
    Vocabulary.find(filter).sort({ category: 1, word: 1 }).skip(skip).limit(limit),
    Vocabulary.countDocuments(filter),
  ]);

  res.status(200).json({
    success: true,
    data: {
      vocabulary: items,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    },
  });
});

// GET /api/vocabulary/:id
const getVocabularyById = asyncHandler(async (req, res) => {
  const vocab = await Vocabulary.findById(req.params.id);
  if (!vocab) throw new ApiError(404, 'Vocabulary word not found.');
  res.status(200).json({ success: true, data: { vocabulary: vocab } });
});

// POST /api/admin/vocabulary
const createVocabulary = asyncHandler(async (req, res) => {
  const language = await Language.findById(req.body.languageId);
  if (!language) throw new ApiError(400, 'languageId does not reference an existing language.');

  const vocab = await Vocabulary.create(req.body);
  res.status(201).json({ success: true, data: { vocabulary: vocab } });
});

// PUT /api/admin/vocabulary/:id
const updateVocabulary = asyncHandler(async (req, res) => {
  const vocab = await Vocabulary.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!vocab) throw new ApiError(404, 'Vocabulary word not found.');
  res.status(200).json({ success: true, data: { vocabulary: vocab } });
});

// DELETE /api/admin/vocabulary/:id
// Also pulls this word out of any Lesson.vocabulary arrays that reference it,
// so lessons never end up pointing at a deleted word.
const deleteVocabulary = asyncHandler(async (req, res) => {
  const vocab = await Vocabulary.findById(req.params.id);
  if (!vocab) throw new ApiError(404, 'Vocabulary word not found.');

  await Promise.all([
    Lesson.updateMany({ vocabulary: vocab._id }, { $pull: { vocabulary: vocab._id } }),
    vocab.deleteOne(),
  ]);

  res.status(200).json({ success: true, data: {} });
});

module.exports = { getVocabulary, getVocabularyById, createVocabulary, updateVocabulary, deleteVocabulary };
