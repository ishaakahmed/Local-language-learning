import api from './api';

// PUT /api/users/me — backend whitelists only name, selectedLanguage, dailyGoal;
// anything else sent is silently ignored server-side (see userController.js).
export async function updateProfile(updates) {
  const res = await api.put('/users/me', updates);
  return res.data.data.user;
}
