import { useCallback, useEffect, useState } from 'react';
import { Award } from 'lucide-react';
import AchievementBadge from '../components/AchievementBadge';
import Spinner from '../components/ui/Spinner';
import ErrorState from '../components/ui/ErrorState';
import EmptyState from '../components/ui/EmptyState';
import { fetchAllAchievements, fetchMyAchievements } from '../services/achievementService';
import { getApiErrorMessage } from '../utils/apiError';

export default function AchievementsPage() {
  const [all, setAll] = useState([]);
  const [earned, setEarned] = useState([]);
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');

  const load = useCallback(async () => {
    setStatus('loading');
    try {
      const [allAchievements, myAchievements] = await Promise.all([fetchAllAchievements(), fetchMyAchievements()]);
      setAll(allAchievements);
      setEarned(myAchievements);
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load achievements.'));
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (status === 'loading') return <Spinner className="py-16" label="Loading achievements…" />;
  if (status === 'error') return <ErrorState message={errorMessage} onRetry={load} />;

  const earnedMap = new Map(earned.map((e) => [e.achievementId?._id, e.earnedAt]));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Achievements</h1>
        <p className="text-text-muted mt-1">
          {earned.length} of {all.length} badges unlocked
        </p>
      </div>

      {all.length === 0 ? (
        <EmptyState icon={Award} title="No achievements available yet" />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {all.map((achievement) => (
            <AchievementBadge
              key={achievement._id}
              achievement={achievement}
              earned={earnedMap.has(achievement._id)}
              earnedAt={earnedMap.get(achievement._id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
