const mongoose = require('mongoose');

const VALID_CATEGORIES = [
  'greetings',
  'family',
  'food',
  'travel',
  'numbers',
  'colors',
  'animals',
  'places',
  'daily-conversation',
  'education',
  'shopping',
];

const vocabularySchema = new mongoose.Schema(
  {
    languageId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Language',
      required: [true, 'languageId is required'],
      index: true,
    },
    word: {
      type: String,
      required: [true, 'Word (local script) is required'],
      trim: true,
    },
    translation: {
      type: String,
      required: [true, 'English translation is required'],
      trim: true,
    },
    transliteration: {
      type: String,
      required: [true, 'Transliteration is required'],
      trim: true,
    },
    pronunciation: {
      type: String,
      trim: true,
      // Defaults to the local-script word itself; kept separate in case
      // a cleaner phonetic string is ever needed for the TTS engine.
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      enum: {
        values: VALID_CATEGORIES,
        message: 'Category must be one of: ' + VALID_CATEGORIES.join(', '),
      },
    },
    exampleSentence: {
      type: String,
      trim: true,
    },
    exampleSentenceTranslation: {
      type: String,
      trim: true,
    },
    image: {
      type: String,
      default: '',
    },
    difficulty: {
      type: String,
      enum: ['easy', 'medium', 'hard'],
      default: 'easy',
    },
  },
  { timestamps: true }
);

// Default pronunciation field to the word itself if not explicitly provided
vocabularySchema.pre('validate', function setDefaultPronunciation(next) {
  if (!this.pronunciation) {
    this.pronunciation = this.word;
  }
  next();
});

vocabularySchema.index({ languageId: 1, category: 1 });

module.exports = mongoose.model('Vocabulary', vocabularySchema);
module.exports.VALID_CATEGORIES = VALID_CATEGORIES;
