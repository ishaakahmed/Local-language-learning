const mongoose = require('mongoose');
const ApiError = require('../utils/ApiError');

/**
 * Returns middleware that 400s cleanly if req.params[paramName] isn't a
 * valid ObjectId, instead of letting it fall through to a Mongoose CastError
 * deeper in the query.
 */
const validateObjectIdParam = (paramName) => (req, res, next) => {
  const value = req.params[paramName];
  if (!mongoose.Types.ObjectId.isValid(value)) {
    throw new ApiError(400, `"${value}" is not a valid ${paramName}`);
  }
  next();
};

module.exports = validateObjectIdParam;
