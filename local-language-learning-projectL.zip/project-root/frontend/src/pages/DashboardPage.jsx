import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Flame, Star, Target, BookOpen, Library, TrendingUp, Award, ArrowRight } from 'lucide-react';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import ProgressBar from '../components/ui/ProgressBar';
import Spinner from '../components/ui/Spinner';
import { fetchLessons } from '../services/lessonService';
import { fetchMyProgress } from '../services/progressService';
import { fetchMyAchievements } from '../services/achievementService';
import useAuth from '../hooks/useAuth';

const QUICK_ACTIONS = [
  { label: 'Lessons', to: '/lessons', icon: BookOpen },
  { label: 'Vocabulary', to: '/vocabulary', icon: Library },
  { label: 'Progress', to: '/progress', icon: TrendingUp },
  { label: 'Achievements', to: '/achievements', icon: Award },
];

export default function DashboardPage() {
  const { user } = useAuth();
  const firstName = user?.name?.split(' ')[0];
  const dailyGoal = user?.dailyGoal ?? 20;
  const xpIntoLevel = (user?.xp ?? 0) % 100;
  const selectedLanguageId = user?.selectedLanguage?._id || user?.selectedLanguage || null;

  const [continueLesson, setContinueLesson] = useState(null);
  const [recentAchievements, setRecentAchievements] = useState([]);
  const [loadingExtras, setLoadingExtras] = useState(true);

  const loadExtras = useCallback(async () => {
    setLoadingExtras(true);
    try {
      const achievementsPromise = fetchMyAchievements().catch(() => []);

      if (selectedLanguageId) {
        const [lessons, progress] = await Promise.all([
          fetchLessons({ languageId: selectedLanguageId }),
          fetchMyProgress().catch(() => ({ lessons: [] })),
        ]);
        const completedIds = new Set(
          progress.lessons.filter((p) => p.completed).map((p) => p.lessonId?._id || p.lessonId)
        );
        const nextLesson = lessons.find((l) => !completedIds.has(l._id)) || lessons[0] || null;
        setContinueLesson(nextLesson);
      }

      setRecentAchievements((await achievementsPromise).slice(0, 3));
    } finally {
      setLoadingExtras(false);
    }
  }, [selectedLanguageId]);

  useEffect(() => {
    loadExtras();
  }, [loadExtras]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Welcome back, {firstName} 👋</h1>
        <p className="text-text-muted mt-1">Here&rsquo;s where your learning picks back up.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="text-center">
          <Star className="h-5 w-5 text-primary mx-auto mb-2" aria-hidden="true" />
          <p className="text-2xl font-bold text-text">{user?.xp ?? 0}</p>
          <p className="text-xs text-text-muted mt-1">Total XP</p>
        </Card>
        <Card className="text-center">
          <Award className="h-5 w-5 text-primary mx-auto mb-2" aria-hidden="true" />
          <p className="text-2xl font-bold text-text">{user?.level ?? 1}</p>
          <p className="text-xs text-text-muted mt-1">Level</p>
        </Card>
        <Card className="text-center">
          <Flame className="h-5 w-5 text-secondary mx-auto mb-2" aria-hidden="true" />
          <p className="text-2xl font-bold text-text">{user?.streak ?? 0}</p>
          <p className="text-xs text-text-muted mt-1">Day streak</p>
        </Card>
        <Card className="text-center">
          <Target className="h-5 w-5 text-primary mx-auto mb-2" aria-hidden="true" />
          <p className="text-2xl font-bold text-text">{user?.wordsLearned?.length ?? 0}</p>
          <p className="text-xs text-text-muted mt-1">Words learned</p>
        </Card>
      </div>

      {/* Continue learning */}
      {selectedLanguageId ? (
        <Card>
          <h2 className="font-semibold text-text mb-3">Continue learning</h2>
          {loadingExtras ? (
            <Spinner label="Loading…" />
          ) : continueLesson ? (
            <Link
              to={`/lessons/${continueLesson._id}`}
              className="flex items-center justify-between gap-4 rounded-xl border border-black/10 p-4 hover:border-primary/40 transition-colors"
            >
              <div>
                <p className="text-xs text-text-muted uppercase tracking-wide">{continueLesson.category}</p>
                <p className="font-semibold text-text">{continueLesson.title}</p>
              </div>
              <ArrowRight className="h-5 w-5 text-primary shrink-0" aria-hidden="true" />
            </Link>
          ) : (
            <p className="text-sm text-text-muted">No lessons available for your language yet.</p>
          )}
        </Card>
      ) : (
        <Card className="bg-primary/5 border-primary/20">
          <p className="text-sm text-text-muted">
            You haven&rsquo;t chosen a language yet.{' '}
            <Link to="/languages" className="text-primary font-semibold hover:underline">
              Pick one to start learning
            </Link>
            .
          </p>
        </Card>
      )}

      {/* Level progress */}
      <Card>
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-text">Progress to next level</h2>
          <Badge tone="primary">{xpIntoLevel} / 100 XP</Badge>
        </div>
        <ProgressBar value={xpIntoLevel} max={100} />
        <p className="text-xs text-text-muted mt-2">Daily goal: {dailyGoal} XP</p>
      </Card>

      {/* Quick actions */}
      <div>
        <h2 className="font-semibold text-text mb-3">Quick actions</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {QUICK_ACTIONS.map(({ label, to, icon: Icon }) => (
            <Link key={label} to={to}>
              <Card className="text-center hover:shadow-md hover:-translate-y-0.5 transition-all">
                <Icon className="h-6 w-6 text-primary mx-auto mb-2" aria-hidden="true" />
                <p className="text-sm font-medium text-text">{label}</p>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent achievements */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-text">Recent achievements</h2>
          <Link to="/achievements" className="text-sm text-primary font-medium hover:underline">
            View all
          </Link>
        </div>
        {loadingExtras ? (
          <Spinner label="Loading…" />
        ) : recentAchievements.length === 0 ? (
          <Card>
            <p className="text-sm text-text-muted">Complete lessons and quizzes to start earning achievements.</p>
          </Card>
        ) : (
          <div className="grid grid-cols-3 gap-4">
            {recentAchievements.map((ua) => (
              <Card key={ua._id} className="text-center">
                <div className="text-3xl mb-1">{ua.achievementId?.icon}</div>
                <p className="text-xs font-medium text-text">{ua.achievementId?.name}</p>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
