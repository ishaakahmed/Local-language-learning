export default function EmptyState({ icon: Icon, title, message, action, className = '' }) {
  return (
    <div className={['flex flex-col items-center justify-center text-center py-12 px-4', className].join(' ')}>
      {Icon && (
        <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
          <Icon className="h-6 w-6 text-primary" aria-hidden="true" />
        </div>
      )}
      <h3 className="text-lg font-semibold text-text mb-1">{title}</h3>
      {message && <p className="text-sm text-text-muted max-w-sm mb-4">{message}</p>}
      {action}
    </div>
  );
}
