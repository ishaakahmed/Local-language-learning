const { Lesson, Question, UserProgress } = require('../models');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const { sanitizeQuestionForClient, gradeQuizSubmission } = require('../services/quizService');
const gamification = require('../services/gamificationService');
const { markLessonVocabularyLearned } = require('../services/progressService');

// GET /api/quizzes/:lessonId
// Returns questions WITHOUT correct answers — see quizService.sanitizeQuestionForClient.
const getQuizForLesson = asyncHandler(async (req, res) => {
  const lesson = await Lesson.findById(req.params.lessonId);
  if (!lesson) throw new ApiError(404, 'Lesson not found.');

  const questions = await Question.find({ lessonId: lesson._id });
  if (questions.length === 0) {
    throw new ApiError(404, 'No quiz questions exist for this lesson yet.');
  }

  const sanitized = questions.map(sanitizeQuestionForClient);

  res.status(200).json({
    success: true,
    data: {
      lessonId: lesson._id,
      lessonTitle: lesson.title,
      questionCount: sanitized.length,
      questions: sanitized,
    },
  });
});

// POST /api/quizzes/submit
// Body: { lessonId, answers: [{ questionId, answer }] }
// The backend re-fetches the real questions and grades from scratch —
// nothing about correctness/score is ever trusted from the request body.
const submitQuiz = asyncHandler(async (req, res) => {
  const { lessonId, answers } = req.body;

  const lesson = await Lesson.findById(lessonId);
  if (!lesson) throw new ApiError(404, 'Lesson not found.');

  const questions = await Question.find({ lessonId });
  if (questions.length === 0) {
    throw new ApiError(404, 'No quiz questions exist for this lesson yet.');
  }

  const { results, totalQuestions, correctCount, accuracy } = gradeQuizSubmission(questions, answers);
  const xpEarned = correctCount * gamification.XP_PER_CORRECT_ANSWER;

  const responseBody = {
    lessonId: lesson._id,
    totalQuestions,
    correctCount,
    accuracy,
    xpEarned,
    results,
  };

  // Everything below only applies to authenticated users — an anonymous
  // visitor can still take a quiz and see their grade, they just don't get
  // progress/XP/achievements persisted.
  if (!req.user) {
    return res.status(200).json({ success: true, data: responseBody });
  }

  const user = req.user;
  const wasAlreadyCompleted = await UserProgress.exists({ userId: user._id, lessonId, completed: true });
  const bonusXp = wasAlreadyCompleted ? 0 : gamification.LESSON_COMPLETION_BONUS_XP;
  const totalXpThisAttempt = xpEarned + bonusXp;

  await UserProgress.findOneAndUpdate(
    { userId: user._id, lessonId },
    {
      $set: { completed: true, score: correctCount, accuracy, completedAt: new Date() },
      $inc: { xpEarned: totalXpThisAttempt },
    },
    { upsert: true, setDefaultsOnInsert: true }
  );

  user.xp += totalXpThisAttempt;
  user.level = gamification.calculateLevel(user.xp);
  gamification.updateStreakForToday(user);
  await user.save();

  await markLessonVocabularyLearned(user._id, lesson.vocabulary);

  const newAchievements = await gamification.checkAndAwardAchievements(user, { quizAccuracy: accuracy });

  res.status(200).json({
    success: true,
    data: {
      ...responseBody,
      xpEarned: totalXpThisAttempt,
      bonusXp,
      user: { xp: user.xp, level: user.level, streak: user.streak },
      newAchievements,
    },
  });
});

module.exports = { getQuizForLesson, submitQuiz };
