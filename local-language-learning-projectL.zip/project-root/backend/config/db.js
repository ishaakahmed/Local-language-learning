const mongoose = require('mongoose');

/**
 * Establishes connection to MongoDB using the URI from environment variables.
 * Exits the process on failure so the app never runs silently without a DB.
 */
const connectDB = async () => {
  const uri = process.env.MONGODB_URI;

  if (!uri) {
    console.error('FATAL ERROR: MONGODB_URI is not defined in environment variables.');
    process.exit(1);
  }

  try {
    // serverSelectionTimeoutMS keeps failures fast and visible instead of
    // hanging silently for Mongoose's ~30s default when MongoDB is unreachable.
    const conn = await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log(`MongoDB connected: ${conn.connection.host}/${conn.connection.name}`);
  } catch (error) {
    console.error(`MongoDB connection failed: ${error.message}`);
    process.exit(1);
  }

  mongoose.connection.on('disconnected', () => {
    console.warn('MongoDB disconnected. Attempting to reconnect is handled by the driver.');
  });

  mongoose.connection.on('error', (err) => {
    console.error(`MongoDB connection error: ${err.message}`);
  });
};

module.exports = connectDB;
