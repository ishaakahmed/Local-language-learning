import { useCallback, useMemo, useState } from 'react';

const isSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

/**
 * Speaks `text` using the given BCP-47 locale (e.g. 'mr-IN'). Never throws —
 * if the API is unsupported or speech fails, `speak` just no-ops and
 * `supported` tells the caller to disable/hide the pronunciation button.
 */
export default function usePronunciation(locale) {
  const [speaking, setSpeaking] = useState(false);

  const speak = useCallback(
    (text) => {
      if (!isSupported || !text) return;
      try {
        window.speechSynthesis.cancel(); // stop any previous utterance first
        const utterance = new SpeechSynthesisUtterance(text);
        if (locale) utterance.lang = locale;
        utterance.onstart = () => setSpeaking(true);
        utterance.onend = () => setSpeaking(false);
        utterance.onerror = () => setSpeaking(false);
        window.speechSynthesis.speak(utterance);
      } catch (err) {
        setSpeaking(false);
      }
    },
    [locale]
  );

  return useMemo(() => ({ speak, speaking, supported: isSupported }), [speak, speaking]);
}
