import api from './api';

// Matches the exact response shape from backend/controllers/authController.js:
// { success, data: { user, token } } for register/login, { success, data: { user } } for me.

export async function registerUser({ name, email, password, selectedLanguage }) {
  const res = await api.post('/auth/register', { name, email, password, selectedLanguage });
  return res.data.data; // { user, token }
}

export async function loginUser({ email, password }) {
  const res = await api.post('/auth/login', { email, password });
  return res.data.data; // { user, token }
}

export async function fetchCurrentUser() {
  const res = await api.get('/auth/me');
  return res.data.data.user;
}
