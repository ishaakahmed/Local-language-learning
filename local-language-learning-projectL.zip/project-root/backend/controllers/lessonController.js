const { Lesson, Language, Vocabulary, Question } = require('../models');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');

// GET /api/lessons?languageId=...&level=...&category=...
const getLessons = asyncHandler(async (req, res) => {
  const filter = { isActive: true };
  if (req.query.languageId) filter.languageId = req.query.languageId;
  if (req.query.level) filter.level = req.query.level;
  if (req.query.category) filter.category = req.query.category;

  const lessons = await Lesson.find(filter)
    .populate({ path: 'languageId', select: 'name nativeName code' })
    .sort({ languageId: 1, order: 1 });

  res.status(200).json({ success: true, data: { lessons } });
});

// GET /api/lessons/:id
const getLessonById = asyncHandler(async (req, res) => {
  const lesson = await Lesson.findById(req.params.id)
    .populate({ path: 'languageId', select: 'name nativeName code speechLocale' })
    .populate({ path: 'vocabulary' });

  if (!lesson) throw new ApiError(404, 'Lesson not found.');
  res.status(200).json({ success: true, data: { lesson } });
});

// POST /api/admin/lessons
const createLesson = asyncHandler(async (req, res) => {
  const { languageId, vocabulary } = req.body;

  const language = await Language.findById(languageId);
  if (!language) throw new ApiError(400, 'languageId does not reference an existing language.');

  if (vocabulary && vocabulary.length > 0) {
    const count = await Vocabulary.countDocuments({ _id: { $in: vocabulary }, languageId });
    if (count !== vocabulary.length) {
      throw new ApiError(400, 'One or more vocabulary IDs are invalid or belong to a different language.');
    }
  }

  const lesson = await Lesson.create(req.body);
  res.status(201).json({ success: true, data: { lesson } });
});

// PUT /api/admin/lessons/:id
const updateLesson = asyncHandler(async (req, res) => {
  const lesson = await Lesson.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!lesson) throw new ApiError(404, 'Lesson not found.');
  res.status(200).json({ success: true, data: { lesson } });
});

// DELETE /api/admin/lessons/:id
// Cascades to delete this lesson's Questions (they're meaningless without
// their lesson), but leaves Vocabulary documents intact since words can be
// shared across lessons.
const deleteLesson = asyncHandler(async (req, res) => {
  const lesson = await Lesson.findById(req.params.id);
  if (!lesson) throw new ApiError(404, 'Lesson not found.');

  await Promise.all([Question.deleteMany({ lessonId: lesson._id }), lesson.deleteOne()]);

  res.status(200).json({ success: true, data: {} });
});

module.exports = { getLessons, getLessonById, createLesson, updateLesson, deleteLesson };
