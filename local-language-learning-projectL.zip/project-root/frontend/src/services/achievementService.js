import api from './api';

// GET /api/achievements -> full catalog (public)
export async function fetchAllAchievements() {
  const res = await api.get('/achievements');
  return res.data.data.achievements;
}

// GET /api/achievements/me -> UserAchievement docs populated with achievementId
export async function fetchMyAchievements() {
  const res = await api.get('/achievements/me');
  return res.data.data.achievements;
}
