const { shuffle } = require('../seed/helpers/generateQuestions');

/**
 * Strips a Question document down to only what the client needs to RENDER
 * the question — never the correct answer. Shape depends on `type`, mirroring
 * the payload shapes documented in models/Question.js.
 */
function sanitizeQuestionForClient(question) {
  const { _id, type, prompt, difficulty, payload } = question;
  let safePayload;

  switch (type) {
    case 'mcq':
    case 'translate':
    case 'listenSelect':
    case 'imageSelect':
      safePayload = { options: payload.options };
      break;

    case 'fillBlank':
      safePayload = { sentence: payload.sentence };
      break;

    case 'reorder':
      // payload.words is already the shuffled/scrambled tile order from seeding —
      // that IS the safe-to-send prompt. correctOrder is withheld.
      safePayload = { words: payload.words };
      break;

    case 'match':
      // Send lefts and a re-shuffled list of rights, with the left<->right
      // association removed — that association is the answer.
      safePayload = {
        lefts: payload.pairs.map((p) => p.left),
        rights: shuffle(payload.pairs.map((p) => p.right)),
      };
      break;

    default:
      safePayload = {};
  }

  return { id: _id, type, prompt, difficulty, payload: safePayload };
}

/**
 * Grades a single submitted answer against its question's real payload.
 * Expected shape of `submittedAnswer` by type:
 *  - mcq / translate / listenSelect / imageSelect: string (chosen option)
 *  - fillBlank: string (free text, compared case-insensitively, trimmed)
 *  - reorder: string[] (the words in the order the user arranged them)
 *  - match: Array<{ left: string, right: string }> (the pairs the user made)
 */
function gradeSingleAnswer(question, submittedAnswer) {
  const { type, payload } = question;

  switch (type) {
    case 'mcq':
    case 'translate':
    case 'listenSelect':
    case 'imageSelect':
      return submittedAnswer === payload.correctAnswer;

    case 'fillBlank':
      if (typeof submittedAnswer !== 'string') return false;
      return submittedAnswer.trim().toLowerCase() === payload.correctAnswer.trim().toLowerCase();

    case 'reorder':
      if (!Array.isArray(submittedAnswer)) return false;
      if (submittedAnswer.length !== payload.correctOrder.length) return false;
      return submittedAnswer.every((word, i) => word === payload.correctOrder[i]);

    case 'match':
      if (!Array.isArray(submittedAnswer)) return false;
      if (submittedAnswer.length !== payload.pairs.length) return false;
      return payload.pairs.every((correctPair) => {
        const submittedPair = submittedAnswer.find((p) => p && p.left === correctPair.left);
        return submittedPair && submittedPair.right === correctPair.right;
      });

    default:
      return false;
  }
}

/**
 * Grades a full quiz submission. `questions` are the REAL Question documents
 * (with correct answers) fetched server-side; `answers` is the client's
 * submitted [{ questionId, answer }]. The client's own score/accuracy, if
 * sent, is ignored entirely — everything here is recomputed from scratch.
 */
function gradeQuizSubmission(questions, answers) {
  const answerMap = new Map(answers.map((a) => [String(a.questionId), a.answer]));

  const results = questions.map((question) => {
    const submitted = answerMap.has(String(question._id)) ? answerMap.get(String(question._id)) : undefined;
    const correct = submitted !== undefined ? gradeSingleAnswer(question, submitted) : false;

    return {
      questionId: question._id,
      type: question.type,
      correct,
      submittedAnswer: submitted !== undefined ? submitted : null,
      correctAnswer: extractDisplayableCorrectAnswer(question),
      explanation: question.explanation || null,
    };
  });

  const totalQuestions = questions.length;
  const correctCount = results.filter((r) => r.correct).length;
  const accuracy = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;

  return { results, totalQuestions, correctCount, accuracy };
}

/**
 * After grading, it's safe (and expected) to reveal the correct answer for
 * review — this only ever runs post-submission, never in the GET quiz payload.
 */
function extractDisplayableCorrectAnswer(question) {
  const { type, payload } = question;
  switch (type) {
    case 'mcq':
    case 'translate':
    case 'listenSelect':
    case 'imageSelect':
      return payload.correctAnswer;
    case 'fillBlank':
      return payload.correctAnswer;
    case 'reorder':
      return payload.correctOrder;
    case 'match':
      return payload.pairs;
    default:
      return null;
  }
}

module.exports = { sanitizeQuestionForClient, gradeQuizSubmission };
