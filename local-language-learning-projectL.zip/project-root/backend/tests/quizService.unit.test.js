const assert = require('assert');
const { sanitizeQuestionForClient, gradeQuizSubmission } = require('../services/quizService');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`PASS: ${name}`);
  } catch (err) {
    failed += 1;
    console.log(`FAIL: ${name}`);
    console.log(`      ${err.message}`);
  }
}

console.log('--- Quiz service unit tests ---\n');

// --- sanitizeQuestionForClient: must never leak correct answers ---

test('sanitize mcq: strips correctAnswer, keeps options', () => {
  const q = {
    _id: 'q1',
    type: 'mcq',
    prompt: 'What is "नमस्कार"?',
    difficulty: 'easy',
    payload: { options: ['Hello', 'Goodbye', 'Thanks'], correctAnswer: 'Hello' },
  };
  const safe = sanitizeQuestionForClient(q);
  assert.deepStrictEqual(safe.payload.options, ['Hello', 'Goodbye', 'Thanks']);
  assert.strictEqual(safe.payload.correctAnswer, undefined);
  assert.strictEqual(JSON.stringify(safe).includes('correctAnswer'), false);
});

test('sanitize fillBlank: strips correctAnswer, keeps sentence', () => {
  const q = {
    _id: 'q2',
    type: 'fillBlank',
    prompt: 'Fill in the blank',
    difficulty: 'medium',
    payload: { sentence: 'The ___ is red.', correctAnswer: 'apple' },
  };
  const safe = sanitizeQuestionForClient(q);
  assert.strictEqual(safe.payload.sentence, 'The ___ is red.');
  assert.strictEqual(JSON.stringify(safe).includes('apple'), false);
});

test('sanitize reorder: strips correctOrder, keeps scrambled words', () => {
  const q = {
    _id: 'q3',
    type: 'reorder',
    prompt: 'Arrange the words',
    difficulty: 'hard',
    payload: { words: ['my', 'friend', 'Hello'], correctOrder: ['Hello', 'my', 'friend'] },
  };
  const safe = sanitizeQuestionForClient(q);
  assert.deepStrictEqual(safe.payload.words, ['my', 'friend', 'Hello']);
  assert.strictEqual(safe.payload.correctOrder, undefined);
});

test('sanitize match: strips left<->right association', () => {
  const q = {
    _id: 'q4',
    type: 'match',
    prompt: 'Match the words',
    difficulty: 'medium',
    payload: {
      pairs: [
        { left: 'नमस्कार', right: 'Hello' },
        { left: 'धन्यवाद', right: 'Thank you' },
      ],
    },
  };
  const safe = sanitizeQuestionForClient(q);
  assert.deepStrictEqual(safe.payload.lefts, ['नमस्कार', 'धन्यवाद']);
  // rights should contain the same values, just no longer paired with lefts
  assert.deepStrictEqual([...safe.payload.rights].sort(), ['Hello', 'Thank you']);
  assert.strictEqual(safe.payload.pairs, undefined);
});

// --- gradeQuizSubmission: must grade correctly and never trust client score ---

test('grades mcq correct and incorrect answers accurately', () => {
  const questions = [
    { _id: 'q1', type: 'mcq', payload: { options: ['Hello', 'Bye'], correctAnswer: 'Hello' }, explanation: '' },
    { _id: 'q2', type: 'mcq', payload: { options: ['Red', 'Blue'], correctAnswer: 'Red' }, explanation: '' },
  ];
  const answers = [
    { questionId: 'q1', answer: 'Hello' }, // correct
    { questionId: 'q2', answer: 'Blue' }, // incorrect
  ];
  const result = gradeQuizSubmission(questions, answers);
  assert.strictEqual(result.correctCount, 1);
  assert.strictEqual(result.totalQuestions, 2);
  assert.strictEqual(result.accuracy, 50);
});

test('fillBlank grading is case-insensitive and trims whitespace', () => {
  const questions = [{ _id: 'q1', type: 'fillBlank', payload: { sentence: '___', correctAnswer: 'Hello' } }];
  const answers = [{ questionId: 'q1', answer: '  hello  ' }];
  const result = gradeQuizSubmission(questions, answers);
  assert.strictEqual(result.results[0].correct, true);
});

test('reorder grading requires exact order match', () => {
  const questions = [
    { _id: 'q1', type: 'reorder', payload: { words: ['a', 'b'], correctOrder: ['Hello', 'my', 'friend'] } },
  ];
  const wrongOrder = [{ questionId: 'q1', answer: ['my', 'Hello', 'friend'] }];
  const rightOrder = [{ questionId: 'q1', answer: ['Hello', 'my', 'friend'] }];
  assert.strictEqual(gradeQuizSubmission(questions, wrongOrder).results[0].correct, false);
  assert.strictEqual(gradeQuizSubmission(questions, rightOrder).results[0].correct, true);
});

test('match grading checks every pair regardless of submitted order', () => {
  const questions = [
    {
      _id: 'q1',
      type: 'match',
      payload: {
        pairs: [
          { left: 'नमस्कार', right: 'Hello' },
          { left: 'धन्यवाद', right: 'Thank you' },
        ],
      },
    },
  ];
  // submitted in reverse order but with correct pairings — should still be correct
  const correctButReversed = [
    {
      questionId: 'q1',
      answer: [
        { left: 'धन्यवाद', right: 'Thank you' },
        { left: 'नमस्कार', right: 'Hello' },
      ],
    },
  ];
  const wrongPairing = [
    {
      questionId: 'q1',
      answer: [
        { left: 'नमस्कार', right: 'Thank you' },
        { left: 'धन्यवाद', right: 'Hello' },
      ],
    },
  ];
  assert.strictEqual(gradeQuizSubmission(questions, correctButReversed).results[0].correct, true);
  assert.strictEqual(gradeQuizSubmission(questions, wrongPairing).results[0].correct, false);
});

test('missing/unanswered questions are graded as incorrect, not skipped', () => {
  const questions = [
    { _id: 'q1', type: 'mcq', payload: { options: ['A', 'B'], correctAnswer: 'A' } },
    { _id: 'q2', type: 'mcq', payload: { options: ['A', 'B'], correctAnswer: 'B' } },
  ];
  const answers = [{ questionId: 'q1', answer: 'A' }]; // q2 never answered
  const result = gradeQuizSubmission(questions, answers);
  assert.strictEqual(result.totalQuestions, 2);
  assert.strictEqual(result.correctCount, 1);
  assert.strictEqual(result.results.find((r) => r.questionId === 'q2').correct, false);
});

test('a maliciously large client-submitted "score" field is simply ignored (grading recomputes from scratch)', () => {
  const questions = [{ _id: 'q1', type: 'mcq', payload: { options: ['A', 'B'], correctAnswer: 'A' } }];
  const answers = [{ questionId: 'q1', answer: 'B', score: 9999, accuracy: 100 }]; // extra fields client might try to inject
  const result = gradeQuizSubmission(questions, answers);
  assert.strictEqual(result.correctCount, 0);
  assert.strictEqual(result.accuracy, 0);
});

console.log('\n--- Results ---');
console.log(`Passed: ${passed}`);
console.log(`Failed: ${failed}`);
process.exit(failed > 0 ? 1 : 0);
