import { Check } from 'lucide-react';

export default function LanguageCard({ language, selected = false, onSelect }) {
  return (
    <button
      type="button"
      onClick={() => onSelect?.(language)}
      className={[
        'relative w-full text-left rounded-2xl border-2 p-6 transition-all bg-surface',
        'hover:shadow-md hover:-translate-y-0.5',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40',
        selected ? 'border-primary shadow-md' : 'border-black/5',
      ].join(' ')}
    >
      {selected && (
        <span className="absolute top-4 right-4 h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center">
          <Check className="h-4 w-4" aria-hidden="true" />
        </span>
      )}
      <div className="h-14 w-14 rounded-xl bg-primary/10 text-primary flex items-center justify-center text-2xl font-bold mb-4">
        {language.icon || language.nativeName?.[0]}
      </div>
      <h3 className="text-lg font-semibold text-text">{language.name}</h3>
      <p className="text-2xl mt-1" lang="und">
        {language.nativeName}
      </p>
      <p className="text-sm text-text-muted mt-2">{language.script} script</p>
      {language.description && (
        <p className="text-sm text-text-muted mt-3 line-clamp-2">{language.description}</p>
      )}
    </button>
  );
}
