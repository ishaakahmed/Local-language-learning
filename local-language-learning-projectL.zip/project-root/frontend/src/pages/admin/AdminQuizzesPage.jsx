import { useCallback, useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, X } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import Badge from '../../components/ui/Badge';
import Spinner from '../../components/ui/Spinner';
import ErrorState from '../../components/ui/ErrorState';
import EmptyState from '../../components/ui/EmptyState';
import Modal from '../../components/admin/Modal';
import ConfirmDialog from '../../components/admin/ConfirmDialog';
import { fetchLanguages } from '../../services/languageService';
import { fetchLessons } from '../../services/lessonService';
import { fetchQuestionsForAdmin, createQuestion, updateQuestion, deleteQuestion } from '../../services/adminService';
import { getApiErrorMessage } from '../../utils/apiError';

const QUESTION_TYPES = ['mcq', 'translate', 'listenSelect', 'imageSelect', 'fillBlank', 'reorder', 'match'];
const DIFFICULTIES = ['easy', 'medium', 'hard'];
const CHOICE_TYPES = ['mcq', 'translate', 'listenSelect', 'imageSelect'];

function buildInitialPayload(type, existingPayload) {
  if (existingPayload) {
    if (CHOICE_TYPES.includes(type)) return { options: existingPayload.options || ['', ''], correctAnswer: existingPayload.correctAnswer || '' };
    if (type === 'fillBlank') return { sentence: existingPayload.sentence || '', correctAnswer: existingPayload.correctAnswer || '' };
    if (type === 'reorder') return { words: (existingPayload.words || []).join(', '), correctOrder: (existingPayload.correctOrder || []).join(', ') };
    if (type === 'match') return { pairs: existingPayload.pairs?.length ? existingPayload.pairs : [{ left: '', right: '' }] };
  }
  if (CHOICE_TYPES.includes(type)) return { options: ['', ''], correctAnswer: '' };
  if (type === 'fillBlank') return { sentence: '', correctAnswer: '' };
  if (type === 'reorder') return { words: '', correctOrder: '' };
  if (type === 'match') return { pairs: [{ left: '', right: '' }] };
  return {};
}

function QuestionForm({ initial, lessonId, onSubmit, onCancel, saving, submitError }) {
  const [type, setType] = useState(initial?.type || 'mcq');
  const [prompt, setPrompt] = useState(initial?.prompt || '');
  const [explanation, setExplanation] = useState(initial?.explanation || '');
  const [difficulty, setDifficulty] = useState(initial?.difficulty || 'easy');
  const [payload, setPayload] = useState(buildInitialPayload(initial?.type || 'mcq', initial?.payload));
  const [localError, setLocalError] = useState('');

  const handleTypeChange = (newType) => {
    setType(newType);
    setPayload(buildInitialPayload(newType));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLocalError('');

    let finalPayload;
    if (CHOICE_TYPES.includes(type)) {
      const options = payload.options.map((o) => o.trim()).filter(Boolean);
      if (options.length < 2) return setLocalError('Provide at least 2 options.');
      if (!options.includes(payload.correctAnswer)) return setLocalError('Correct answer must match one of the options exactly.');
      finalPayload = { options, correctAnswer: payload.correctAnswer };
    } else if (type === 'fillBlank') {
      if (!payload.sentence.includes('___')) return setLocalError('Sentence must contain "___" for the blank.');
      if (!payload.correctAnswer.trim()) return setLocalError('Correct answer is required.');
      finalPayload = { sentence: payload.sentence, correctAnswer: payload.correctAnswer.trim() };
    } else if (type === 'reorder') {
      const words = payload.words.split(',').map((w) => w.trim()).filter(Boolean);
      const correctOrder = payload.correctOrder.split(',').map((w) => w.trim()).filter(Boolean);
      if (words.length < 2) return setLocalError('Provide at least 2 words.');
      if (correctOrder.length !== words.length) return setLocalError('Correct order must have the same number of words.');
      finalPayload = { words, correctOrder };
    } else if (type === 'match') {
      const pairs = payload.pairs.filter((p) => p.left.trim() && p.right.trim());
      if (pairs.length < 2) return setLocalError('Provide at least 2 complete pairs.');
      finalPayload = { pairs };
    }

    onSubmit({ lessonId, type, prompt, explanation, difficulty, payload: finalPayload });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Select id="type" label="Question type" value={type} onChange={(e) => handleTypeChange(e.target.value)}>
        {QUESTION_TYPES.map((t) => (
          <option key={t} value={t}>
            {t}
          </option>
        ))}
      </Select>

      <Input id="prompt" label="Prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} required />

      {CHOICE_TYPES.includes(type) && (
        <div>
          <p className="block text-sm font-medium text-text mb-1.5">Options</p>
          <div className="space-y-2">
            {payload.options.map((opt, i) => (
              <div key={i} className="flex gap-2">
                <input
                  value={opt}
                  onChange={(e) => {
                    const next = [...payload.options];
                    next[i] = e.target.value;
                    setPayload({ ...payload, options: next });
                  }}
                  aria-label={`Option ${i + 1}`}
                  className="flex-1 rounded-xl border border-black/10 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                  placeholder={`Option ${i + 1}`}
                />
                <button
                  type="button"
                  onClick={() => setPayload({ ...payload, options: payload.options.filter((_, idx) => idx !== i) })}
                  className="p-2 text-text-muted hover:text-error"
                  aria-label="Remove option"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setPayload({ ...payload, options: [...payload.options, ''] })}
            className="text-sm text-primary font-medium mt-2"
          >
            + Add option
          </button>

          <div className="mt-3">
            <Select
              id="correctAnswer"
              label="Correct answer"
              value={payload.correctAnswer}
              onChange={(e) => setPayload({ ...payload, correctAnswer: e.target.value })}
            >
              <option value="">Select the correct option…</option>
              {payload.options.filter(Boolean).map((opt, i) => (
                <option key={i} value={opt}>
                  {opt}
                </option>
              ))}
            </Select>
          </div>
        </div>
      )}

      {type === 'fillBlank' && (
        <>
          <Input
            id="sentence"
            label='Sentence (use "___" for the blank)'
            value={payload.sentence}
            onChange={(e) => setPayload({ ...payload, sentence: e.target.value })}
            required
          />
          <Input
            id="fb-correctAnswer"
            label="Correct answer"
            value={payload.correctAnswer}
            onChange={(e) => setPayload({ ...payload, correctAnswer: e.target.value })}
            required
          />
        </>
      )}

      {type === 'reorder' && (
        <>
          <Input
            id="words"
            label="Words (comma-separated, shown scrambled to the student)"
            value={payload.words}
            onChange={(e) => setPayload({ ...payload, words: e.target.value })}
            required
          />
          <Input
            id="correctOrder"
            label="Correct order (comma-separated, same words)"
            value={payload.correctOrder}
            onChange={(e) => setPayload({ ...payload, correctOrder: e.target.value })}
            required
          />
        </>
      )}

      {type === 'match' && (
        <div>
          <p className="block text-sm font-medium text-text mb-1.5">Pairs</p>
          <div className="space-y-2">
            {payload.pairs.map((pair, i) => (
              <div key={i} className="flex gap-2">
                <input
                  value={pair.left}
                  onChange={(e) => {
                    const next = [...payload.pairs];
                    next[i] = { ...next[i], left: e.target.value };
                    setPayload({ ...payload, pairs: next });
                  }}
                  placeholder="Left (word)"
                  aria-label={`Pair ${i + 1} left value`}
                  className="flex-1 rounded-xl border border-black/10 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
                <input
                  value={pair.right}
                  onChange={(e) => {
                    const next = [...payload.pairs];
                    next[i] = { ...next[i], right: e.target.value };
                    setPayload({ ...payload, pairs: next });
                  }}
                  placeholder="Right (meaning)"
                  aria-label={`Pair ${i + 1} right value`}
                  className="flex-1 rounded-xl border border-black/10 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
                <button
                  type="button"
                  onClick={() => setPayload({ ...payload, pairs: payload.pairs.filter((_, idx) => idx !== i) })}
                  className="p-2 text-text-muted hover:text-error"
                  aria-label="Remove pair"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setPayload({ ...payload, pairs: [...payload.pairs, { left: '', right: '' }] })}
            className="text-sm text-primary font-medium mt-2"
          >
            + Add pair
          </button>
        </div>
      )}

      <Input id="explanation" label="Explanation (optional)" value={explanation} onChange={(e) => setExplanation(e.target.value)} />

      <Select id="difficulty" label="Difficulty" value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
        {DIFFICULTIES.map((d) => (
          <option key={d} value={d}>
            {d}
          </option>
        ))}
      </Select>

      {(localError || submitError) && <p className="text-sm text-error">{localError || submitError}</p>}

      <div className="flex gap-3 pt-2">
        <Button type="button" variant="ghost" fullWidth onClick={onCancel} disabled={saving}>
          Cancel
        </Button>
        <Button type="submit" fullWidth loading={saving}>
          Save
        </Button>
      </div>
    </form>
  );
}

export default function AdminQuizzesPage() {
  const [languages, setLanguages] = useState([]);
  const [languageId, setLanguageId] = useState('');
  const [lessons, setLessons] = useState([]);
  const [lessonId, setLessonId] = useState('');
  const [questions, setQuestions] = useState([]);
  const [status, setStatus] = useState('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const [modalMode, setModalMode] = useState(null);
  const [editingQuestion, setEditingQuestion] = useState(null);
  const [saving, setSaving] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchLanguages().then(setLanguages).catch(() => {});
  }, []);

  useEffect(() => {
    setLessonId('');
    setQuestions([]);
    if (!languageId) {
      setLessons([]);
      return;
    }
    fetchLessons({ languageId }).then(setLessons).catch(() => setLessons([]));
  }, [languageId]);

  const loadQuestions = useCallback(async () => {
    if (!lessonId) return;
    setStatus('loading');
    try {
      setQuestions(await fetchQuestionsForAdmin(lessonId));
      setStatus('ready');
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not load questions.'));
      setStatus('error');
    }
  }, [lessonId]);

  useEffect(() => {
    loadQuestions();
  }, [loadQuestions]);

  const openCreate = () => {
    setEditingQuestion(null);
    setSubmitError('');
    setModalMode('create');
  };
  const openEdit = (q) => {
    setEditingQuestion(q);
    setSubmitError('');
    setModalMode('edit');
  };
  const closeModal = () => setModalMode(null);

  const handleSubmit = async (form) => {
    setSaving(true);
    setSubmitError('');
    try {
      if (modalMode === 'edit') {
        await updateQuestion(editingQuestion._id, form);
      } else {
        await createQuestion(form);
      }
      closeModal();
      await loadQuestions();
    } catch (err) {
      setSubmitError(getApiErrorMessage(err, 'Could not save this question.'));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteQuestion(deleteTarget._id);
      setDeleteTarget(null);
      await loadQuestions();
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Could not delete this question.'));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Quizzes</h1>
        <p className="text-text-muted mt-1">Select a lesson to manage its quiz questions.</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <select
          value={languageId}
          onChange={(e) => setLanguageId(e.target.value)}
          className="rounded-xl border border-black/10 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
        >
          <option value="">Select a language…</option>
          {languages.map((l) => (
            <option key={l._id} value={l._id}>
              {l.name}
            </option>
          ))}
        </select>
        <select
          value={lessonId}
          onChange={(e) => setLessonId(e.target.value)}
          disabled={!languageId}
          className="rounded-xl border border-black/10 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 disabled:opacity-50"
        >
          <option value="">Select a lesson…</option>
          {lessons.map((l) => (
            <option key={l._id} value={l._id}>
              {l.title}
            </option>
          ))}
        </select>
        {lessonId && (
          <Button onClick={openCreate} className="sm:ml-auto">
            <Plus className="h-4 w-4" /> Add question
          </Button>
        )}
      </div>

      {!lessonId && (
        <EmptyState title="Choose a lesson" message="Select a language and lesson above to view and manage its questions." />
      )}

      {lessonId && status === 'loading' && <Spinner className="py-16" label="Loading questions…" />}
      {lessonId && status === 'error' && <ErrorState message={errorMessage} onRetry={loadQuestions} />}

      {lessonId && status === 'ready' && questions.length === 0 && (
        <EmptyState title="No questions yet" message="Add the first question for this lesson." />
      )}

      {lessonId && status === 'ready' && questions.length > 0 && (
        <div className="space-y-3">
          {questions.map((q) => (
            <Card key={q._id}>
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1.5">
                    <Badge tone="primary">{q.type}</Badge>
                    <Badge tone="muted">{q.difficulty}</Badge>
                  </div>
                  <p className="font-medium text-text">{q.prompt}</p>
                  <p className="text-sm text-text-muted mt-1 break-words">
                    Payload: <code className="text-xs">{JSON.stringify(q.payload)}</code>
                  </p>
                </div>
                <div className="flex gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => openEdit(q)}
                    className="p-1.5 rounded-lg text-text-muted hover:bg-black/5 hover:text-primary"
                    aria-label="Edit question"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(q)}
                    className="p-1.5 rounded-lg text-text-muted hover:bg-black/5 hover:text-error"
                    aria-label="Delete question"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={Boolean(modalMode)}
        onClose={closeModal}
        title={modalMode === 'edit' ? 'Edit question' : 'Add question'}
        maxWidth="max-w-xl"
      >
        <QuestionForm
          initial={editingQuestion}
          lessonId={lessonId}
          onSubmit={handleSubmit}
          onCancel={closeModal}
          saving={saving}
          submitError={submitError}
        />
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete question?"
        message="This will permanently delete this quiz question."
      />
    </div>
  );
}
