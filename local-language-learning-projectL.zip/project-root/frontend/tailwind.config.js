/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Centralized design-system palette — components should reference
        // these tokens (e.g. bg-primary) rather than raw Tailwind colors,
        // so the whole app's look can be changed from this one file.
        primary: {
          DEFAULT: '#1E7A63', // deep teal-green — "growth/learning"
          light: '#2FA382',
          dark: '#155C4A',
        },
        secondary: {
          DEFAULT: '#F2A93B', // warm amber — accents, XP, streaks
          light: '#F7C56E',
          dark: '#C6841F',
        },
        background: '#F7F9F8',
        surface: '#FFFFFF',
        text: {
          DEFAULT: '#1F2937',
          muted: '#6B7280',
        },
        success: '#22A06B',
        warning: '#E0A800',
        error: '#D64545',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        xl: '1rem',
        '2xl': '1.5rem',
      },
    },
  },
  plugins: [],
};
