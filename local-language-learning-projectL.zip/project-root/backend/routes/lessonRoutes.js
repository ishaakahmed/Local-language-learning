const express = require('express');
const { query } = require('express-validator');
const router = express.Router();

const { getLessons, getLessonById } = require('../controllers/lessonController');
const validateObjectIdParam = require('../middleware/validateObjectIdParam');
const validateRequest = require('../middleware/validateRequest');

router.get(
  '/',
  [
    query('languageId').optional().isMongoId().withMessage('languageId must be a valid id'),
    query('level').optional().isIn(['beginner', 'intermediate', 'advanced']).withMessage('Invalid level'),
  ],
  validateRequest,
  getLessons
);

router.get('/:id', validateObjectIdParam('id'), getLessonById);

module.exports = router;
