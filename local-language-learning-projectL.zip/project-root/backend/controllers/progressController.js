const { UserProgress, Lesson } = require('../models');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const { getDashboardSummary } = require('../services/progressService');

// GET /api/progress — always the AUTHENTICATED user's own progress.
// A normal user has no way to pass a different id here; there simply isn't
// a userId parameter on this route, so there's nothing to spoof.
const getMyProgress = asyncHandler(async (req, res) => {
  const data = await getDashboardSummary(req.user._id);
  res.status(200).json({ success: true, data });
});

// GET /api/progress/:userId — admin-only, for viewing any user's progress.
const getUserProgressById = asyncHandler(async (req, res) => {
  const data = await getDashboardSummary(req.params.userId);
  res.status(200).json({ success: true, data });
});

// POST /api/progress
// Manually marks a lesson as complete without going through the quiz flow —
// e.g. a "vocabulary-only" lesson the user has just read through. Awards a
// small flat XP bonus, but only the first time (repeat calls are no-ops for XP).
const upsertProgress = asyncHandler(async (req, res) => {
  const { lessonId, completed } = req.body;

  const lesson = await Lesson.findById(lessonId);
  if (!lesson) throw new ApiError(404, 'Lesson not found.');

  const existing = await UserProgress.findOne({ userId: req.user._id, lessonId });

  if (existing) {
    if (completed !== undefined) existing.completed = completed;
    if (completed && !existing.completedAt) existing.completedAt = new Date();
    await existing.save();
    return res.status(200).json({ success: true, data: { progress: existing } });
  }

  const FLAT_COMPLETION_XP = 5;
  const progress = await UserProgress.create({
    userId: req.user._id,
    lessonId,
    completed: !!completed,
    completedAt: completed ? new Date() : null,
    xpEarned: completed ? FLAT_COMPLETION_XP : 0,
  });

  if (completed) {
    req.user.xp += FLAT_COMPLETION_XP;
    await req.user.save();
  }

  res.status(201).json({ success: true, data: { progress } });
});

module.exports = { getMyProgress, getUserProgressById, upsertProgress };
