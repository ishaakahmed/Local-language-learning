import { Navigate, Outlet } from 'react-router-dom';
import useAuth from '../hooks/useAuth';
import Spinner from './ui/Spinner';

/**
 * Frontend gating is a UX convenience only — every admin API call is still
 * independently protected by the backend's `authenticate` + `requireAdmin`
 * middleware. A user could never reach real admin data just by bypassing
 * this component.
 */
export default function AdminRoute() {
  const { isAuthenticated, initializing, user } = useAuth();

  if (initializing) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Spinner label="Loading…" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (user?.role !== 'admin') {
    return <Navigate to="/dashboard" replace />;
  }

  return <Outlet />;
}
